#!/bin/bash
# Weekly base-OS maintenance window (the "reboot window"), run by
# timetracking-maintenance.timer. Applies Debian *security* patches (the
# unattended-upgrades Allowed-Origins is restricted to -security) and reboots so
# kernel/firmware fixes take effect.
#
# It shares the writable-boot machinery in lib-update.sh: on a locked device it
# raises the apt flag and requests a writable boot; apply-on-boot.sh then runs the
# apt upgrade while root is writable, re-locks the overlay, and reboots back. When
# the overlay is off it patches inline.
set -uo pipefail

LOG_TAG="tt-maintenance"
TT_ROOT="/opt/timetracking"
# shellcheck source=lib-update.sh
. "$TT_ROOT/scripts/lib-update.sh"

# Same guard as update-all.sh: on a mis-provisioned overlay device the apt flag
# and writable-boot markers live on the tmpfs and vanish on reboot, so refuse.
overlay_persist_guard || exit 1

if overlay_on; then
  # Only pay for a maintenance boot if something is actually pending.
  apt-get update -qq || llog "apt-get update failed (continuing)"
  DRY="$(unattended-upgrade --dry-run 2>&1 || true)"
  if printf '%s' "$DRY" | grep -qiE 'No packages found that can be upgraded'; then
    llog "No pending security updates - skipping maintenance boot"
    exit 0
  fi
  mkdir -p "$TT_MAINT_DIR"
  : > "$TT_APT_FLAG"
  llog "Security updates pending - requesting writable boot"
  request_writable_boot     # sets $TT_PENDING, disables overlay, reboots
else
  llog "Overlay off - applying security updates inline"
  export DEBIAN_FRONTEND=noninteractive
  apt-get update -qq || llog "apt-get update failed (continuing)"
  if command -v unattended-upgrade >/dev/null 2>&1; then
    unattended-upgrade -v || llog "unattended-upgrade returned non-zero"
  fi
  apt-get -y autoremove --purge -qq || true
  apt-get clean || true
  if [ -f /var/run/reboot-required ]; then
    llog "Reboot required by updates - rebooting"
    systemctl reboot
  else
    llog "Maintenance complete - no reboot needed"
  fi
fi

#!/bin/bash
# Runs once on first boot via timetracking-firstboot.service.
set -euo pipefail

LOG_TAG="tt-provision"
log() { logger -t "$LOG_TAG" "$1"; echo "$1"; }

# --- Expand root filesystem to fill the SD card ---
# rpi-resize is not in the Bookworm RPi repo; use raspi-config instead.
# This is safe to re-run: raspi-config checks if the partition already fills the disk.
raspi-config nonint do_expand_rootfs 2>/dev/null || true
log "Root filesystem expansion scheduled"

# --- Create the dedicated kiosk service user if it doesn't exist ---
# The 'input' group lets cage/libinput read the NFC daemon's virtual keyboard
# (/dev/uinput -> /dev/input/event*); video+render are for the DSI panel/DRM.
if ! id -u ttkiosk >/dev/null 2>&1; then
  useradd --system --create-home --shell /usr/sbin/nologin \
    --groups video,input,render ttkiosk
  log "Created ttkiosk service user"
fi

# --- Ensure writable data dir exists (persists outside the overlay root) ---
mkdir -p /var/lib/timetracking
chown ttkiosk:ttkiosk /var/lib/timetracking

# --- Hostname based on the Pi's unique CPU serial for easy identification in
#     NinjaOne. Test images get a 'test' prefix so they're obvious in the fleet.
#     Backend pairing is done in-app (device key on the Setup screen), so there
#     is no API token to provision here. ---
ENV_NAME=$(cat /opt/timetracking/ENVIRONMENT 2>/dev/null || echo production)
PREFIX="tt-kiosk"
[ "$ENV_NAME" = "test" ] && PREFIX="tt-kiosk-test"
SERIAL=$(awk '/Serial/ {print $3}' /proc/cpuinfo)
NEW_HOSTNAME="${PREFIX}-${SERIAL: -6}"
hostnamectl set-hostname "$NEW_HOSTNAME" || true
log "Set hostname to ${NEW_HOSTNAME} (env: ${ENV_NAME})"

log "First-boot provisioning complete"

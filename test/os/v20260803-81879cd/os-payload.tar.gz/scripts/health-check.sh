#!/bin/bash
# Basic health check for the kiosk stack.
#
# Usage: health-check.sh [version_dir]
#   If version_dir is given, sanity-checks that release's built SPA exists
#   (pre-switch check). Otherwise checks the live running services and that the
#   file server actually serves the app (post-switch check).
set -uo pipefail

TARGET="${1:-}"

fail() { echo "HEALTH CHECK FAILED: $1" >&2; exit 1; }

if [ -n "$TARGET" ]; then
  # Pre-switch: confirm the new release contains a usable SPA build without
  # touching live services.
  [ -f "${TARGET}/web/index.html" ] || fail "web/index.html missing in ${TARGET}"
  ls "${TARGET}"/web/assets/*.js >/dev/null 2>&1 || fail "no JS assets in ${TARGET}/web/assets"
  echo "Pre-switch check OK for ${TARGET}"
  exit 0
fi

# Post-switch: check the live services are up and the kiosk server serves the app.
systemctl is-active --quiet timetracking-kiosk.service || fail "timetracking-kiosk.service not active"
systemctl is-active --quiet timetracking-nfc.service || fail "timetracking-nfc.service not active"

HTTP_CODE=$(curl -s -o /dev/null -w '%{http_code}' http://localhost:8080/ || echo "000")
[ "$HTTP_CODE" = "200" ] || fail "kiosk UI returned HTTP ${HTTP_CODE}"

echo "Post-switch check OK"
exit 0

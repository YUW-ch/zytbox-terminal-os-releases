#!/bin/bash
# Temporarily disable the read-only overlay for maintenance (apt installs,
# config edits, debugging). Re-run scripts/03-enable-readonly-overlay.sh
# and reboot when you're done.
set -euo pipefail
raspi-config nonint disable_overlayfs
echo "Overlay disabled. Root will be writable again after 'sudo reboot'."

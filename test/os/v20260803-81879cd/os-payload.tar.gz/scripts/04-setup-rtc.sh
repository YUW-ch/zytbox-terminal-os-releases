#!/bin/bash
# Wires up the battery-backed RTC module. Assumes the i2c-rtc overlay from
# pi-gen/stage-timetracking/files/boot/config-additions.txt is already active
# (requires a reboot after image flash before this can succeed - the i2c bus
# device won't exist until the overlay has loaded).
set -euo pipefail

LOG_TAG="tt-rtc"
log() { logger -t "$LOG_TAG" "$1"; echo "$1"; }

if ! ls /dev/rtc0 >/dev/null 2>&1; then
  log "No /dev/rtc0 found yet - overlay may not have loaded (needs a reboot after first flash). Skipping for now, will retry next boot."
  exit 0
fi

# Sync system clock FROM the RTC on boot (RTC is source of truth when offline)
hwclock -s || log "Failed to read RTC - check wiring/battery"

# Confirm drift is sane
DRIFT=$(( $(date +%s) - $(hwclock -r --utc | date -f - +%s 2>/dev/null || echo 0) ))
log "RTC sync complete. Approx drift: ${DRIFT}s"

# Make sure the RTC gets updated FROM system time on clean shutdown too
# (fake-hwclock is removed via 00-packages, so this is the real hwclock path)
systemctl enable hwclock.sh 2>/dev/null || true

log "RTC setup complete"

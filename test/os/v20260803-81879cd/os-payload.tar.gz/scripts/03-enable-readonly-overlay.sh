#!/bin/bash
# Enables Raspberry Pi OS's built-in overlayfs (read-only root + tmpfs overlay)
# and hardens logging so the device does minimal writes to the SD/eMMC.
#
# RUN THIS ONLY AFTER you've fully validated the device (see MANUAL.md
# checklist, section 8). Once enabled, most filesystem changes are
# discarded on reboot until you run scripts/disable-readonly-overlay.sh.
set -euo pipefail

echo "This will make the root filesystem read-only on next boot."
echo "Persistent data will ONLY survive at /var/lib/timetracking."
read -rp "Continue? [y/N] " confirm
[ "$confirm" = "y" ] || { echo "Aborted."; exit 1; }

# Guard: refuse to lock the filesystem read-only unless /var/lib/timetracking is
# a genuinely separate persistent mount. Under overlayfs everything on / is
# tmpfs-backed and discarded on reboot, so if this path is just a directory on
# the (now read-only) root, the device silently loses the Chromium profile on
# every boot — that means the terminal un-pairs AND drops any queued offline
# punches (both the pairing key in localStorage and the punch queue in IndexedDB
# live in this profile). Fail loudly here instead of losing data in production.
if ! mountpoint -q /var/lib/timetracking; then
  cat >&2 <<'ERR'
REFUSING to enable the read-only overlay:
  /var/lib/timetracking is not a separate persistent mount.

  Under overlayfs it would be RAM-backed and wiped on every reboot, which
  un-pairs the terminal and discards any unsynced offline punches.

  Back it with a dedicated partition (or a bind-mount from persistent storage),
  add it to /etc/fstab, mount it, then re-run this script. Verify with:
    mountpoint /var/lib/timetracking
    mount | grep timetracking
ERR
  exit 1
fi

# Built-in Raspberry Pi OS overlay toggle
raspi-config nonint enable_overlayfs

# Disable swap entirely - swapping to SD/eMMC is both slow and wears flash
dphys-swapfile swapoff || true
systemctl disable dphys-swapfile 2>/dev/null || true

# journald: RAM-only, capped size, no disk persistence
mkdir -p /etc/systemd/journald.conf.d
cat > /etc/systemd/journald.conf.d/timetracking-volatile.conf <<'EOF'
[Journal]
Storage=volatile
RuntimeMaxUse=32M
EOF

# /var/lib/timetracking must stay a genuinely persistent, writable mount under
# overlayfs: it holds the Chromium profile (--user-data-dir) where the SPA's
# pairing key (localStorage) AND the offline punch queue (IndexedDB) live, so if
# it doesn't persist the terminal un-pairs and loses unsynced punches on every
# reboot. The guard above enforces this; the mkdir just ensures the profile dir
# exists on that persistent mount.
mkdir -p /var/lib/timetracking/chromium-profile

echo "Overlay filesystem will be active after reboot. Run 'sudo reboot' when ready."

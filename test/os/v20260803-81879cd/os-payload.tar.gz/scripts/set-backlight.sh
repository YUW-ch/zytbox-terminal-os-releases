#!/bin/bash
# Set / persist the DSI panel backlight brightness.
#
#   set-backlight.sh            -> apply the saved level (or DEFAULT_PERCENT)
#   set-backlight.sh <0-100>    -> set to <percent>, apply now AND persist it
#
# The Waveshare 10.1-DSI-TOUCH-A exposes its backlight MCU as a standard sysfs
# backlight device (/sys/class/backlight/<n>-0045). The kernel resets brightness
# to max on every boot, so timetracking-backlight.service re-applies the saved
# level on each boot by running this script with no argument.
#
# The chosen percentage is stored in the persistent data dir (survives reboots
# AND the read-only overlay), so an admin can `sudo set-backlight.sh 50` over SSH
# and have it stick. Run as root - writing sysfs brightness needs it.
set -euo pipefail

# Build-time default, used until someone overrides it at runtime.
DEFAULT_PERCENT=40

STATE_DIR="/var/lib/timetracking"
STATE_FILE="$STATE_DIR/brightness"
LOG_TAG="tt-backlight"
log() { logger -t "$LOG_TAG" "$1" 2>/dev/null || true; echo "$1"; }

# --- locate the backlight device (wait briefly for the driver to probe) ---
BL=""
for _ in $(seq 1 20); do          # up to ~10s on a cold boot
  for d in /sys/class/backlight/*/; do
    [ -e "$d/brightness" ] && { BL="${d%/}"; break; }
  done
  [ -n "$BL" ] && break
  sleep 0.5
done
if [ -z "$BL" ]; then
  log "No backlight device under /sys/class/backlight - is the DSI panel connected?"
  exit 1
fi
MAX=$(cat "$BL/max_brightness")

# --- resolve the target percentage ---
if [ $# -ge 1 ]; then
  PERCENT="$1"
  case "$PERCENT" in
    ''|*[!0-9]*) echo "usage: $(basename "$0") [0-100]" >&2; exit 2 ;;
  esac
  [ "$PERCENT" -gt 100 ] && { echo "percent must be 0-100" >&2; exit 2; }
  PERSIST=1
else
  PERCENT="$(cat "$STATE_FILE" 2>/dev/null || echo "$DEFAULT_PERCENT")"
  # Guard against a corrupt state file.
  case "$PERCENT" in ''|*[!0-9]*) PERCENT="$DEFAULT_PERCENT" ;; esac
  [ "$PERCENT" -gt 100 ] && PERCENT="$DEFAULT_PERCENT"
  PERSIST=0
fi

# --- compute + apply (round to nearest raw step) ---
RAW=$(( (PERCENT * MAX + 50) / 100 ))
echo "$RAW" > "$BL/brightness"
log "Backlight ${PERCENT}% (raw ${RAW}/${MAX}) on $(basename "$BL")"

# --- persist an explicit change so it survives reboots ---
if [ "$PERSIST" -eq 1 ]; then
  mkdir -p "$STATE_DIR"
  echo "$PERCENT" > "$STATE_FILE"
fi

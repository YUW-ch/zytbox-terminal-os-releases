#!/bin/bash
# Writable-boot worker. Runs early on every boot but does nothing unless a
# writable boot was requested (the $TT_PENDING marker exists). That marker is set
# by update-all.sh (staged OTA to apply) or os-maintenance.sh (security patches
# to apply) after they disabled the overlay and rebooted — so on this boot root
# is WRITABLE. Apply everything pending, re-enable the overlay, reboot back.
set -uo pipefail

LOG_TAG="tt-apply-boot"
TT_ROOT="/opt/timetracking"
# shellcheck source=lib-update.sh
. "$TT_ROOT/scripts/lib-update.sh"

[ -f "$TT_PENDING" ] || exit 0   # no writable boot requested; normal boot

# Safety: if root is somehow still read-only, don't loop — clear + bail so the
# device still boots normally.
PROBE="/.tt-rw-probe"
if ! (touch "$PROBE" 2>/dev/null); then
  llog "Writable boot requested but root is still read-only - clearing markers to avoid a loop"
  rm -f "$TT_PENDING" "$TT_APT_FLAG"
  exit 1
fi
rm -f "$PROBE"

# --- apply staged OTA (os first, so fixed logic/units land before web) ---
if [ -d "$TT_STAGE_DIR/os" ]; then
  llog "Applying staged OS payload $(cat "$TT_STAGE_DIR/os.tag" 2>/dev/null || echo '?')"
  apply_os "$TT_STAGE_DIR/os" "$(cat "$TT_STAGE_DIR/os.build" 2>/dev/null || echo 0)" \
    || llog "OS apply failed (rolled back)"
fi
if [ -d "$TT_STAGE_DIR/web" ]; then
  llog "Applying staged web build $(cat "$TT_STAGE_DIR/web.tag" 2>/dev/null || echo '?')"
  apply_web "$TT_STAGE_DIR/web" \
    "$(cat "$TT_STAGE_DIR/web.tag" 2>/dev/null || echo unknown)" \
    "$(cat "$TT_STAGE_DIR/web.build" 2>/dev/null || echo 0)" \
    || llog "web apply failed (rolled back)"
fi

# --- apply base-OS security patches if requested (os-maintenance.sh) ---
if [ -f "$TT_APT_FLAG" ]; then
  llog "Applying base-OS security updates"
  export DEBIAN_FRONTEND=noninteractive
  apt-get update -qq || llog "apt-get update failed (continuing)"
  if command -v unattended-upgrade >/dev/null 2>&1; then
    unattended-upgrade -v || llog "unattended-upgrade returned non-zero"
  fi
  apt-get -y autoremove --purge -qq || true
  apt-get clean || true
fi

# --- clean up, re-lock, reboot back into the read-only state ---
rm -rf "${TT_STAGE_DIR:?}/"* 2>/dev/null || true
rm -f "$TT_PENDING" "$TT_APT_FLAG"
raspi-config nonint enable_overlayfs
llog "All pending changes applied and overlay re-locked - rebooting"
systemctl reboot

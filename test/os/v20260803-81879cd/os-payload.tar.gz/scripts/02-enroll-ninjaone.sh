#!/bin/bash
# Downloads and silently installs the NinjaOne Linux agent (Raspberry Pi 64-bit),
# then makes its state survive the read-only overlay.
#
# The installer URL is NOT hardcoded here (it embeds an org-scoped secret token).
# build-image.sh injects it per environment into /opt/timetracking/config/ninja.env
# from NINJA_INSTALLER_URL_PROD / NINJA_INSTALLER_URL_TEST at build time. Get the
# URL from: NinjaOne console -> Administration -> Apps -> Installer -> Linux,
# architecture "Raspberry Pi (64-bit)", for the target org/location.
set -euo pipefail

LOG_TAG="tt-ninjaone"
log() { logger -t "$LOG_TAG" "$1"; echo "$1"; }

NINJA_ENV_FILE="/opt/timetracking/config/ninja.env"
NINJA_INSTALLER_FILE=""
NINJA_INSTALLER_URL=""
# shellcheck source=/dev/null
[ -f "$NINJA_ENV_FILE" ] && . "$NINJA_ENV_FILE"

if [ -z "${NINJA_INSTALLER_FILE:-}" ] && [ -z "${NINJA_INSTALLER_URL:-}" ]; then
  log "No NinjaOne installer baked (${NINJA_ENV_FILE} missing/empty) - skipping enrollment. Bundle secrets/ninja-<env>.sh|.deb or set NINJA_INSTALLER_URL_* at build time."
  exit 0
fi

if systemctl is-active --quiet ninjarmm-agent 2>/dev/null; then
  log "NinjaOne agent already installed and running - skipping install"
elif [ -n "${NINJA_INSTALLER_FILE:-}" ] && [ -f "${NINJA_INSTALLER_FILE}" ]; then
  # Preferred: install from the bundled installer (no runtime token fetch).
  log "Installing NinjaOne agent from bundled installer ${NINJA_INSTALLER_FILE}..."
  case "$NINJA_INSTALLER_FILE" in
    *.deb)
      apt-get install -y "$NINJA_INSTALLER_FILE" \
        || { dpkg -i "$NINJA_INSTALLER_FILE" || true; apt-get -y -f install || true; } ;;
    *)
      chmod +x "$NINJA_INSTALLER_FILE"
      "$NINJA_INSTALLER_FILE" -y || log "NinjaOne installer exited non-zero - check /var/log for details" ;;
  esac
else
  # Fallback: download the tokenised installer from NinjaOne.
  TMP_INSTALLER="/tmp/ninjaone-installer.sh"
  curl -fsSL "$NINJA_INSTALLER_URL" -o "$TMP_INSTALLER"
  chmod +x "$TMP_INSTALLER"
  log "Installing NinjaOne agent from URL..."
  "$TMP_INSTALLER" -y || log "NinjaOne installer exited non-zero - check /var/log for details"
  rm -f "$TMP_INSTALLER"
fi

# --- Persist agent state across the read-only overlay ---
# Once scripts/03-enable-readonly-overlay.sh is on, root writes are discarded on
# reboot; bind the agent's writable data dir onto the persistent partition so
# enrollment/identity/state survive. This runs on first boot (overlay still off)
# so the fstab entry is baked into the read-only root and re-applies each boot.
# VERIFY NINJA_DATA_DIR matches your agent version on first hardware bring-up.
NINJA_DATA_DIR="${NINJA_DATA_DIR:-/opt/NinjaRMMAgent/programdata}"
PERSIST_DIR="/var/lib/timetracking/ninjarmm"
if [ -d "$(dirname "$NINJA_DATA_DIR")" ]; then
  systemctl stop ninjarmm-agent 2>/dev/null || true
  mkdir -p "$PERSIST_DIR"
  if [ -d "$NINJA_DATA_DIR" ] && [ ! -e "$PERSIST_DIR/.migrated" ]; then
    cp -a "$NINJA_DATA_DIR/." "$PERSIST_DIR/" 2>/dev/null || true
  fi
  touch "$PERSIST_DIR/.migrated"
  mkdir -p "$NINJA_DATA_DIR"
  if ! grep -qs " ${NINJA_DATA_DIR} " /etc/fstab; then
    echo "${PERSIST_DIR} ${NINJA_DATA_DIR} none bind 0 0" >> /etc/fstab
    log "Added persistent bind mount for NinjaOne data dir (${NINJA_DATA_DIR})"
  fi
  mount --bind "$PERSIST_DIR" "$NINJA_DATA_DIR" 2>/dev/null || true
  systemctl start ninjarmm-agent 2>/dev/null || true
else
  log "NinjaOne agent dir not found under $(dirname "$NINJA_DATA_DIR") - skipping persistence bind (verify NINJA_DATA_DIR)"
fi

log "NinjaOne enrollment step complete"

#!/bin/bash
# Shared helpers for the on-device OTA + maintenance flow. Sourced, not executed.
#
# Persistence model (this is the crux): with the read-only overlay enabled, / is
# RAM-backed and the raspi-config overlay toggle only takes effect on the NEXT
# boot. So we NEVER mutate the locked root in-place. Instead:
#   1. "prepare" (update-app.sh / update-os.sh) downloads + verifies + stages the
#      payload under /var/lib/timetracking (a separate PERSISTENT mount that stays
#      writable even under the overlay);
#   2. if the overlay is off we apply immediately; if it's on we request a
#      "writable boot" (marker + disable overlay + reboot);
#   3. apply-on-boot.sh applies the staged payloads on that writable boot, then
#      re-locks the overlay and reboots back.
#
# Security model: every artifact ships a minisign signature whose *trusted*
# (signed) comment carries "build=<epoch>". We verify against the baked-in public
# key (fail-closed) and refuse anything not validly signed or not strictly newer
# than what's installed (anti-downgrade).

TT_ROOT="${TT_ROOT:-/opt/timetracking}"
TT_PUBKEY="${TT_PUBKEY:-$TT_ROOT/config/minisign.pub}"
TT_PERSIST="${TT_PERSIST:-/var/lib/timetracking}"
TT_STATE_DIR="${TT_STATE_DIR:-$TT_PERSIST/update-state}"
TT_BAKED_BUILD_FILE="${TT_BAKED_BUILD_FILE:-$TT_ROOT/config/baked-build}"
TT_STAGE_DIR="${TT_STAGE_DIR:-$TT_PERSIST/staged}"      # verified payloads (persistent)
TT_MAINT_DIR="${TT_MAINT_DIR:-$TT_PERSIST/maintenance}"
TT_PENDING="${TT_PENDING:-$TT_MAINT_DIR/pending}"        # a writable boot is requested
TT_APT_FLAG="${TT_APT_FLAG:-$TT_MAINT_DIR/apt}"          # run apt security upgrade on it
UNIT_DIR="${UNIT_DIR:-/etc/systemd/system}"
RUNTIME_SERVICES="${RUNTIME_SERVICES:-timetracking-nfc.service timetracking-kiosk.service}"

llog() { logger -t "${LOG_TAG:-tt-update}" "$1"; echo "$1"; }

# --- signature verification + build tracking -------------------------------

# verify_artifact <file> <sigfile> -> prints signed build epoch on success (0),
# else prints a reason to stderr and returns non-zero. Fail-closed.
verify_artifact() {
  local file="$1" sig="$2" out build
  command -v minisign >/dev/null 2>&1 || { echo "minisign not installed" >&2; return 1; }
  [ -f "$TT_PUBKEY" ] || { echo "no public key at $TT_PUBKEY (fail-closed)" >&2; return 1; }
  [ -f "$file" ] && [ -f "$sig" ] || { echo "artifact or signature missing" >&2; return 1; }
  out="$(minisign -Vm "$file" -x "$sig" -p "$TT_PUBKEY" 2>&1)" \
    || { echo "signature INVALID: $out" >&2; return 1; }
  build="$(printf '%s\n' "$out" | sed -n 's/.*[Tt]rusted comment:.*build=\([0-9][0-9]*\).*/\1/p')"
  [ -n "$build" ] || { echo "no build number in signed comment" >&2; return 1; }
  printf '%s\n' "$build"
}

current_build() {  # <channel: web|os>
  local f="$TT_STATE_DIR/$1.build"
  if [ -f "$f" ]; then cat "$f"; return; fi
  [ -f "$TT_BAKED_BUILD_FILE" ] && cat "$TT_BAKED_BUILD_FILE" || echo 0
}
set_build() { mkdir -p "$TT_STATE_DIR"; printf '%s\n' "$2" > "$TT_STATE_DIR/$1.build"; }

# --- overlay / writable-boot request ---------------------------------------

overlay_on() { raspi-config nonint get_overlay_now 2>/dev/null | grep -q 1; }

# request_writable_boot: mark that a writable boot is needed, disable the overlay
# (effective next boot), and reboot. apply-on-boot.sh takes over on that boot.
request_writable_boot() {
  mkdir -p "$TT_MAINT_DIR"
  : > "$TT_PENDING"
  raspi-config nonint disable_overlayfs
  llog "Requesting writable boot (overlay off + reboot)"
  systemctl reboot
}

# --- apply (mutates the root; caller must ensure it is writable) ------------

# apply_web <staged_web_dir> <tag> <build>  — install a staged SPA build, flip the
# symlink, health-check, roll back on failure. Returns 0 on success.
apply_web() {
  local staged="$1" tag="$2" build="$3"
  local versions="$TT_ROOT/releases" cur="$TT_ROOT/current" newdir
  newdir="$versions/$tag"
  mkdir -p "$versions"
  rm -rf "$newdir"; mkdir -p "$newdir/web"
  cp -a "$staged/." "$newdir/web/"
  if ! "$TT_ROOT/scripts/health-check.sh" "$newdir"; then
    llog "web pre-switch health check failed for $tag - discarding"
    rm -rf "$newdir"; return 1
  fi
  local prev; prev="$(readlink -f "$cur" 2>/dev/null || echo "")"
  ln -sfn "$newdir" "$cur"
  systemctl restart timetracking-kiosk.service
  sleep 5
  if "$TT_ROOT/scripts/health-check.sh"; then
    set_build web "$build"
    llog "web update $tag applied"
    ls -1dt "$versions"/v*/ 2>/dev/null | tail -n +4 | xargs -r rm -rf
    return 0
  fi
  llog "web post-switch health check failed - rolling back"
  [ -n "$prev" ] && { ln -sfn "$prev" "$cur"; systemctl restart timetracking-kiosk.service; }
  rm -rf "$newdir"; return 1
}

# apply_os <staged_os_dir> <build>  — install a staged OS payload (app/scripts +
# systemd units) with backup + rollback. Returns 0 on success.
apply_os() {
  local staged="$1" build="$2" bdir units s u
  [ -d "$staged/app" ] && [ -d "$staged/scripts" ] || { llog "bad os payload - skipping"; return 1; }
  for s in "$staged/scripts/"*.sh; do
    bash -n "$s" || { llog "syntax error in $(basename "$s") - refusing os apply"; return 1; }
  done
  bdir="$(mktemp -d)"
  tar -czf "$bdir/tt.tgz" -C "$TT_ROOT" app scripts
  units="$(cd "$UNIT_DIR" && ls timetracking-*.service timetracking-*.timer 2>/dev/null || true)"
  # shellcheck disable=SC2086
  [ -n "$units" ] && tar -czf "$bdir/units.tgz" -C "$UNIT_DIR" $units
  # rsync replaces each file via temp+rename, safe even for the running scripts.
  rsync -a "$staged/app/"     "$TT_ROOT/app/"
  rsync -a "$staged/scripts/" "$TT_ROOT/scripts/"
  chmod +x "$TT_ROOT/scripts/"*.sh 2>/dev/null || true
  if [ -d "$staged/systemd" ]; then
    cp "$staged/systemd/"*.service "$UNIT_DIR/" 2>/dev/null || true
    cp "$staged/systemd/"*.timer   "$UNIT_DIR/" 2>/dev/null || true
  fi
  systemctl daemon-reload
  if [ -d "$staged/systemd" ]; then
    for u in $(cd "$staged/systemd" && ls ./*.service ./*.timer 2>/dev/null | sed 's#^\./##'); do
      systemctl enable "$u" >/dev/null 2>&1 || true
    done
  fi
  # shellcheck disable=SC2086
  systemctl restart $RUNTIME_SERVICES || true
  sleep 5
  if "$TT_ROOT/scripts/health-check.sh"; then
    set_build os "$build"; llog "os update applied"; rm -rf "$bdir"; return 0
  fi
  llog "os post-apply health check failed - rolling back"
  tar -xzf "$bdir/tt.tgz" -C "$TT_ROOT"
  [ -f "$bdir/units.tgz" ] && tar -xzf "$bdir/units.tgz" -C "$UNIT_DIR"
  systemctl daemon-reload
  # shellcheck disable=SC2086
  systemctl restart $RUNTIME_SERVICES || true
  rm -rf "$bdir"; return 1
}

#!/usr/bin/env python3
"""
Screen sleep daemon.

Blanks the DSI panel after SLEEP_AFTER seconds of no user activity and wakes it
again on the next touch or NFC badge tap.

"Sleep" here means the panel BACKLIGHT is powered down (bl_power=1) while cage
keeps rendering underneath. We deliberately do NOT use DPMS / a DRM modeset: the
Waveshare 10.1-DSI-TOUCH-A is slow to re-initialise, so a real power-off would
make wake sluggish and flaky. Cutting just the backlight is instant to wake and
saves almost all the panel's power (the LED backlight is the dominant draw). The
brightness *level* is preserved, so the panel wakes at whatever set-backlight.sh
last configured.

Activity comes from two independent sources, either of which wakes the panel and
resets the idle timer:
  - Touch: input events from the Goodix touchscreen, read directly via evdev.
  - NFC:   nfc_reader touches /run/timetracking/last_nfc_tap on every badge read.

Runs as root: writing bl_power needs root (the brightness node is video-group
writable but bl_power is not), and reading the touch evdev node needs the input
group. The NFC daemon already runs as root for the same reasons.
"""

import glob
import logging
import os
import select
import time

import evdev

SLEEP_AFTER   = 60         # seconds of inactivity before the panel sleeps
TAP_FILE      = "/run/timetracking/last_nfc_tap"
POLL          = 1.0        # max seconds to block in select() between idle checks
RESCAN_EVERY  = 10.0       # seconds between touch-device rescans (hotplug safety)

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("screen-manager")


def find_backlight() -> str | None:
    """First /sys/class/backlight device that exposes a bl_power control."""
    for d in sorted(glob.glob("/sys/class/backlight/*")):
        if os.path.exists(os.path.join(d, "bl_power")):
            return d
    return None


def set_power(bl: str, on: bool):
    # bl_power follows the FB_BLANK convention: 0 = unblank (on), 1 = powerdown.
    try:
        with open(os.path.join(bl, "bl_power"), "w") as f:
            f.write("0" if on else "1")
        log.info("Panel %s", "ON" if on else "OFF")
    except OSError as exc:
        log.error("Failed to set bl_power: %s", exc)


def open_touch_devices() -> dict:
    """Open every touchscreen (EV_ABS) input device, keyed by file descriptor."""
    devs = {}
    for path in evdev.list_devices():
        try:
            dev = evdev.InputDevice(path)
        except OSError:
            continue
        # A touchscreen reports absolute axes; this cleanly selects the Goodix
        # panel and excludes the HDMI-jack / power-button / NFC-keyboard nodes.
        if evdev.ecodes.EV_ABS in dev.capabilities():
            devs[dev.fd] = dev
    return devs


def main():
    bl = find_backlight()
    if not bl:
        raise SystemExit("No backlight device under /sys/class/backlight")
    log.info("Backlight: %s", bl)

    touch = open_touch_devices()
    for dev in touch.values():
        log.info("Watching touch device: %s (%s)", dev.name, dev.path)
    if not touch:
        log.warning("No touchscreen found — waking on NFC taps only")

    os.makedirs(os.path.dirname(TAP_FILE), exist_ok=True)
    if not os.path.exists(TAP_FILE):
        open(TAP_FILE, "w").close()
    last_tap_mtime = os.path.getmtime(TAP_FILE)

    # Start awake so the terminal is visible after boot; the idle timer then runs.
    set_power(bl, True)
    screen_on = True
    last_activity = time.monotonic()
    last_rescan = time.monotonic()

    log.info("Screen manager ready — panel sleeps after %ds of inactivity", SLEEP_AFTER)

    while True:
        active = False

        # --- wait for touch input (or POLL timeout so we can check NFC + idle) ---
        try:
            readable, _, _ = select.select(list(touch), [], [], POLL)
        except OSError:
            readable = []                      # a device vanished; rescan below
            touch = {}

        for fd in readable:
            dev = touch.get(fd)
            if dev is None:
                continue
            try:
                for _ in dev.read():           # drain all pending events
                    active = True
            except OSError:
                dev.close()
                touch.pop(fd, None)            # device error — drop, rescan later

        # --- NFC badge taps come in via the tap file the NFC daemon touches ---
        try:
            mtime = os.path.getmtime(TAP_FILE)
            if mtime != last_tap_mtime:
                last_tap_mtime = mtime
                active = True
        except OSError:
            pass

        # --- periodically rescan so a re-plugged/re-probed touchscreen is picked up ---
        now = time.monotonic()
        if now - last_rescan >= RESCAN_EVERY:
            last_rescan = now
            watched = {d.path for d in touch.values()}
            for fd, dev in open_touch_devices().items():
                if dev.path in watched:
                    dev.close()                # already watching it — no re-log
                else:
                    touch[fd] = dev
                    log.info("Watching touch device: %s (%s)", dev.name, dev.path)

        # --- apply wake / sleep ---
        if active:
            last_activity = now
            if not screen_on:
                set_power(bl, True)
                screen_on = True

        if screen_on and (now - last_activity) >= SLEEP_AFTER:
            set_power(bl, False)
            screen_on = False


if __name__ == "__main__":
    main()

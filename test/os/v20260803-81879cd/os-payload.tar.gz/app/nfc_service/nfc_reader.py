#!/usr/bin/env python3
"""
NFC badge reader daemon for the ACS ACR1252U-M1 (PC/SC CCID reader).

The Zytbox Terminal web app (served on localhost:8080) reads badges as a USB
keyboard-wedge would: it listens at the window level for the card UID typed as
characters followed by Enter (see the app's src/lib/cardReader.ts). The ACR1252U
is a PC/SC reader, not a keyboard-wedge one, so this daemon bridges the two:

- Polls for card presence via pyscard and reads the UID.
- Debounces repeated taps of the same card.
- "Types" the UID + Enter into a virtual keyboard (/dev/uinput) so the focused
  Chromium kiosk receives it exactly as a keyboard-wedge reader would.

There is no backend call and no local queue here — the web app talks to the
backend directly (POST /api/v1/terminal/punch with X-Device-Key) and owns its
own connectivity/offline handling. This daemon's only job is UID -> keystrokes.

Run under systemd (see systemd/timetracking-nfc.service). Needs the pcscd socket
(for pyscard) and /dev/uinput (for the virtual keyboard), so it runs as root.
"""

import logging
import os
import time

from evdev import UInput, ecodes as e
from smartcard.CardMonitoring import CardMonitor, CardObserver
from smartcard.util import toHexString

DEBOUNCE_SECONDS = 2.0
# GET UID APDU — standard for PC/SC contactless readers (returns the card UID).
GET_UID_APDU = [0xFF, 0xCA, 0x00, 0x00, 0x00]

# Touched on every card tap so the screen manager daemon wakes the display.
NFC_TAP_FILE = "/run/timetracking/last_nfc_tap"

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("nfc-reader")


def _signal_screen_wake():
    """Touch NFC_TAP_FILE so the screen manager daemon wakes the display."""
    try:
        os.makedirs(os.path.dirname(NFC_TAP_FILE), exist_ok=True)
        with open(NFC_TAP_FILE, "w"):
            pass
    except OSError as exc:
        log.warning("Could not signal screen wake: %s", exc)


# Map the hex characters a UID can contain to evdev key codes. toHexString gives
# uppercase hex ("04A1B2C3"), and the web app upper-cases anyway, so this covers
# every character we will ever emit.
_KEYMAP = {
    "0": e.KEY_0, "1": e.KEY_1, "2": e.KEY_2, "3": e.KEY_3, "4": e.KEY_4,
    "5": e.KEY_5, "6": e.KEY_6, "7": e.KEY_7, "8": e.KEY_8, "9": e.KEY_9,
    "A": e.KEY_A, "B": e.KEY_B, "C": e.KEY_C, "D": e.KEY_D, "E": e.KEY_E,
    "F": e.KEY_F,
}


class VirtualKeyboard:
    """A /dev/uinput keyboard that types a UID string followed by Enter."""

    def __init__(self):
        keys = sorted(set(_KEYMAP.values()) | {e.KEY_ENTER})
        self._ui = UInput({e.EV_KEY: keys}, name="tt-nfc-keyboard")

    def _tap(self, code: int):
        self._ui.write(e.EV_KEY, code, 1)  # press
        self._ui.write(e.EV_KEY, code, 0)  # release
        self._ui.syn()

    def type_uid(self, uid: str):
        for ch in uid.upper():
            code = _KEYMAP.get(ch)
            if code is None:
                # Unknown character (unusual UID format) — skip it rather than
                # abort; the app tolerates a slightly short UID via MIN_LEN.
                log.warning("Skipping unmappable UID char %r", ch)
                continue
            self._tap(code)
        self._tap(e.KEY_ENTER)

    def close(self):
        self._ui.close()


class BadgeObserver(CardObserver):
    def __init__(self, keyboard: VirtualKeyboard):
        self.keyboard = keyboard
        self._last_uid = None
        self._last_seen = 0.0

    def update(self, observable, actions):
        added_cards, _ = actions
        for card in added_cards:
            try:
                connection = card.createConnection()
                connection.connect()
                data, _sw1, _sw2 = connection.transmit(GET_UID_APDU)
                uid = toHexString(data).replace(" ", "")
            except Exception as ex:
                log.error("Failed to read card UID: %s", ex)
                continue

            if not uid:
                continue

            now = time.time()
            if uid == self._last_uid and (now - self._last_seen) < DEBOUNCE_SECONDS:
                continue  # debounce repeated tap
            self._last_uid = uid
            self._last_seen = now

            log.info("Badge tapped: %s -> typing into kiosk", uid)
            _signal_screen_wake()
            try:
                self.keyboard.type_uid(uid)
            except Exception as ex:
                log.error("Failed to emit keystrokes for UID %s: %s", uid, ex)


def main():
    keyboard = VirtualKeyboard()
    monitor = CardMonitor()
    observer = BadgeObserver(keyboard)
    monitor.addObserver(observer)

    log.info("NFC reader daemon started, waiting for badge taps...")
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        pass
    finally:
        monitor.deleteObserver(observer)
        keyboard.close()


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""
Static file server for the Zytbox Terminal SPA.

The kiosk browser (cage + chromium, see systemd/timetracking-browser.service)
loads http://localhost:8080. This server just serves the prebuilt Vite build
(the app's dist/) from the active release directory. Serving over localhost
gives the SPA a secure context, so its Screen Wake Lock and localStorage work.

The app talks to the backend directly and reads badges as keystrokes injected by
the NFC daemon, so there are no API/SSE routes here — this is a plain file server.

WEB_ROOT points at the built SPA. Defaults to the release symlink used on the
device; override it (e.g. to a local dist/) when testing on a dev machine:

    WEB_ROOT=../../../zytbox-terminal/dist python3 app.py
"""

import os
from pathlib import Path

from flask import Flask, send_from_directory, abort

WEB_ROOT = Path(os.environ.get("WEB_ROOT", "/opt/timetracking/current/web")).resolve()

app = Flask(__name__)


@app.route("/", defaults={"path": ""})
@app.route("/<path:path>")
def serve(path: str):
    # Serve the requested file if it exists, otherwise fall back to index.html.
    # The SPA has no client-side router, so the fallback is just a safety net.
    target = (WEB_ROOT / path).resolve()
    if path and target.is_file() and WEB_ROOT in target.parents:
        return send_from_directory(WEB_ROOT, path)
    index = WEB_ROOT / "index.html"
    if not index.is_file():
        abort(404, description=f"SPA build not found at {WEB_ROOT}")
    return send_from_directory(WEB_ROOT, "index.html")


if __name__ == "__main__":
    # Dev server only. In production systemd runs this via waitress-serve,
    # see systemd/timetracking-kiosk.service.
    app.run(host="127.0.0.1", port=8080)

#!/bin/bash
# Web SPA OTA — PREPARE step. Fetches the latest signed SPA bundle, verifies its
# signature (fail-closed) and that it is strictly newer than what's installed,
# and STAGES it (extracted) onto the persistent mount. It does NOT mutate the
# locked root and does NOT touch the overlay — scripts/update-all.sh decides
# whether to apply now (overlay off) or on a writable boot (overlay on), and
# scripts/apply-on-boot.sh / lib-update.sh apply_web does the actual switch.
#
# Bundles are produced + signed off-device by scripts/release.sh:
#   ${RELEASE_BASE_URL}/latest                   -> plaintext version tag
#   ${RELEASE_BASE_URL}/<tag>/web.tar.gz         -> built dist/, tarred
#   ${RELEASE_BASE_URL}/<tag>/web.tar.gz.minisig -> its minisign signature
#
# Exit 0 = up to date or staged OK; non-zero = error. "Staged something" is
# signalled by the presence of $TT_STAGE_DIR/web afterwards.
set -euo pipefail

LOG_TAG="tt-update"
TT_ROOT="/opt/timetracking"
CONFIG_FILE="$TT_ROOT/config/update-config.env"
# shellcheck source=lib-update.sh
. "$TT_ROOT/scripts/lib-update.sh"
log() { llog "$1"; }

RELEASE_BASE_URL=""
# shellcheck source=/dev/null
[ -f "$CONFIG_FILE" ] && . "$CONFIG_FILE"
if [ -z "$RELEASE_BASE_URL" ] || [ "$RELEASE_BASE_URL" = "__REPLACE_WITH_YOUR_RELEASE_BASE_URL__" ]; then
  log "RELEASE_BASE_URL not configured - edit ${CONFIG_FILE} to enable auto-update."
  exit 0
fi
RELEASE_BASE_URL="${RELEASE_BASE_URL%/}"

LATEST_TAG=$(curl -fsS "${RELEASE_BASE_URL}/latest" | tr -d '[:space:]' || echo "")
if [ -z "$LATEST_TAG" ]; then
  log "Could not determine latest web tag from ${RELEASE_BASE_URL}/latest - skipping"
  exit 0
fi
# Unsigned input that becomes a URL + a path under releases/: check it first.
valid_tag "$LATEST_TAG" || { log "Refusing malformed web tag '${LATEST_TAG}'"; exit 1; }
if [ -d "$TT_ROOT/releases/$LATEST_TAG" ]; then
  log "Web ${LATEST_TAG} already installed"
  exit 0
fi

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

log "Fetching web ${LATEST_TAG}..."
curl -fsS -o "$TMP/web.tar.gz"         "${RELEASE_BASE_URL}/${LATEST_TAG}/web.tar.gz"         || { log "web download failed"; exit 1; }
curl -fsS -o "$TMP/web.tar.gz.minisig" "${RELEASE_BASE_URL}/${LATEST_TAG}/web.tar.gz.minisig" || { log "web signature download failed"; exit 1; }

NEW_BUILD="$(verify_artifact "$TMP/web.tar.gz" "$TMP/web.tar.gz.minisig" web "$LATEST_TAG")" || {
  log "SIGNATURE VERIFICATION FAILED for web ${LATEST_TAG} - refusing"
  exit 1
}
CUR_BUILD="$(current_build web)"
if [ "$NEW_BUILD" -eq "$CUR_BUILD" ]; then
  log "Web ${LATEST_TAG} already current"
  exit 0
fi
if [ "$NEW_BUILD" -lt "$CUR_BUILD" ]; then
  log "Refusing web downgrade: offered build ${NEW_BUILD} < installed ${CUR_BUILD} (${LATEST_TAG})"
  exit 1
fi

# Stage the verified bundle onto the persistent mount (survives the overlay).
STAGE="$TT_STAGE_DIR/web"
rm -rf "$STAGE"; mkdir -p "$STAGE"
tar -xzf "$TMP/web.tar.gz" -C "$STAGE"
printf '%s\n' "$LATEST_TAG" > "$TT_STAGE_DIR/web.tag"
printf '%s\n' "$NEW_BUILD"  > "$TT_STAGE_DIR/web.build"
log "Web ${LATEST_TAG} verified and staged"

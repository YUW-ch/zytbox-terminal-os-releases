#!/bin/bash
# OTA orchestrator, run daily by timetracking-update.timer.
#
# 1. PREPARE: update-os.sh + update-app.sh download, verify, and stage any new
#    signed payloads onto the persistent mount (safe with the overlay on).
# 2. APPLY:
#      - overlay OFF -> root is writable, apply the staged payloads inline now.
#      - overlay ON  -> request a writable boot; apply-on-boot.sh applies them on
#        the next boot (when root is writable), then re-locks and reboots back.
#
# Not 'set -e': a failure in one step must not skip the other or the apply.
set -uo pipefail

LOG_TAG="tt-update-all"
TT_ROOT="/opt/timetracking"
# shellcheck source=lib-update.sh
. "$TT_ROOT/scripts/lib-update.sh"

# Staged payloads are trusted only because the persistent dir is root-only.
# timetracking-harden.service enforces that at boot; re-check before relying on it.
persist_lockdown

# --- prepare (verify + stage) ---
"$TT_ROOT/scripts/update-os.sh"  || llog "update-os.sh exited non-zero (see its log)"
"$TT_ROOT/scripts/update-app.sh" || llog "update-app.sh exited non-zero (see its log)"

staged_os=false;  [ -d "$TT_STAGE_DIR/os" ]  && staged_os=true
staged_web=false; [ -d "$TT_STAGE_DIR/web" ] && staged_web=true

if ! $staged_os && ! $staged_web; then
  llog "Nothing new to apply"
  exit 0
fi

# Fail closed on a mis-provisioned overlay device: if the root is the read-only
# overlay but there is no persistent mount, neither path below can keep the
# result — inline apply and the writable-boot's staged payloads both live on the
# tmpfs and vanish on reboot. Refuse loudly instead of "succeeding" then losing it.
overlay_persist_guard || exit 1

if overlay_on; then
  # Defer to a writable boot; apply-on-boot.sh will apply the staged payloads.
  llog "Updates staged; overlay is on -> requesting writable boot"
  request_writable_boot     # disables overlay + reboots; does not return
  exit 0
fi

# Overlay off: apply right here.
llog "Updates staged; overlay off -> applying inline"
os_applied=false
if $staged_os; then
  if apply_os "$TT_STAGE_DIR/os" "$(cat "$TT_STAGE_DIR/os.build")"; then
    os_applied=true
  else
    llog "os apply failed (rolled back)"
  fi
  rm -rf "$TT_STAGE_DIR/os" "$TT_STAGE_DIR/os.tag" "$TT_STAGE_DIR/os.build"
fi
if $staged_web; then
  apply_web "$TT_STAGE_DIR/web" "$(cat "$TT_STAGE_DIR/web.tag")" "$(cat "$TT_STAGE_DIR/web.build")" || llog "web apply failed (rolled back)"
  rm -rf "$TT_STAGE_DIR/web" "$TT_STAGE_DIR/web.tag" "$TT_STAGE_DIR/web.build"
fi
llog "Inline apply complete"

# A successful OS payload swaps daemon code + systemd units, but apply_os only
# restarts the health-critical services (RUNTIME_SERVICES) in place — a changed
# daemon like the screen manager, or a brand-new unit, would otherwise keep
# running the old code until the next boot. Reboot once so everything comes up on
# the new code, matching the overlay-on path (which also reboots to apply). This
# fires only when an OS payload was actually applied AND passed apply_os's health
# check + rollback; a web-only update needs no reboot (apply_web restarts the
# kiosk in place), and a rolled-back OS update leaves the old code already
# running.
if $os_applied; then
  llog "OS payload applied inline -> rebooting to bring up the new code"
  systemctl reboot
fi

#!/bin/bash
# Every-boot hardening, run as root by timetracking-harden.service before the
# kiosk, the agents and the update/maintenance units start. Idempotent and cheap.
#
#   - persist_lockdown:       /var/lib/timetracking root-only; ttkiosk gets just
#                             the Chromium profile (blocks ttkiosk -> root via
#                             planted OTA payloads/markers).
#   - ensure_chromium_policy: managed Chromium policy (kiosk lockdown).
#   - ensure_apt_origins:     let unattended-upgrades patch Chromium + kernel.
#   - ensure_ssh_lockdown:    SSH as ttadmin with a key only (app/ssh/).
#
# The /etc parts land on tmpfs under the read-only overlay; that's fine, they're
# re-applied from /opt on every boot (and persist on writable/overlay-off boots).
# All of it ships in the OS payload, so devices in the field get it via OTA.
set -uo pipefail

LOG_TAG="tt-harden"
TT_ROOT="/opt/timetracking"
# shellcheck source=lib-update.sh
. "$TT_ROOT/scripts/lib-update.sh"

rc=0
persist_lockdown       || { llog "persist lockdown failed"; rc=1; }
ensure_chromium_policy || { llog "Chromium policy install failed"; rc=1; }
ensure_apt_origins     || { llog "apt origins update failed"; rc=1; }
ensure_ssh_lockdown    || { llog "SSH lockdown not applied"; rc=1; }
exit $rc

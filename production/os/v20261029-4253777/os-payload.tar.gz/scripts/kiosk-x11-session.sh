#!/bin/sh
# X11 kiosk session — launched by timetracking-browser.service via
#   startx /opt/timetracking/scripts/kiosk-x11-session.sh -- :0 vt1 -nocursor -keeptty
# xinit sets DISPLAY and runs this as the X client; when it exits, X tears down and
# systemd (Restart=always) relaunches the whole stack.
#
# We moved from cage/Wayland to Xorg so NinjaOne Remote can capture the screen —
# NinjaOne refuses Wayland "login screen" capture (unattended kiosk, no logged-in
# desktop user) and only supports X11. Everything else (screen_manager backlight,
# NFC uinput keystrokes, kiosk_server) is display-server agnostic and unchanged.
set -e

# --- Rotation. On the Pi 5, Xorg's modesetting driver auto-selects the connected
#     DSI panel (enumerated as DSI-1 or DSI-2 depending on the unit — resolved at
#     runtime below) and does NOT inherit any KMS panel-orientation the way wlroots
#     did, so rotation is owned here. ROT is set by the service ("inverted" on these
#     upside-down-mounted units). When inverted, a matching 180° touch Coordinate
#     Transformation Matrix is applied so taps stay aligned with the flipped image.
CONN="$(xrandr --query | awk '/ connected/{print $1; exit}')"
xrandr --output "$CONN" --rotate "${ROT:-normal}" || true
if [ "${ROT:-normal}" = "inverted" ]; then
  # 180° CTM: maps (x,y) -> (1-x, 1-y) in normalized device coords. Apply ONLY to the
  # physical touchscreen(s) — matched by name. It MUST NOT hit the "Virtual core XTEST
  # pointer": that is the device NinjaOne Remote injects synthetic clicks through, and
  # flipping it sends every remote click to the opposite corner (the screen capture is
  # already rotated, so XTEST needs no transform). Same reason we skip the virtual core
  # pointer and the disconnected HDMI pointers — only the real panel gets the matrix.
  for id in $(xinput --list --id-only 2>/dev/null); do
    case "$(xinput --list --name-only "$id" 2>/dev/null)" in
      *[Tt]ouch[Ss]creen*|*[Tt]ouchscreen*|*TouchScreen*)
        xinput set-prop "$id" "Coordinate Transformation Matrix" -1 0 1 0 -1 1 0 0 1 2>/dev/null || true ;;
    esac
  done
fi

# Never blank/DPMS from X — screen_manager owns panel power via bl_power sysfs.
xset s off -dpms || true

# Tiny WM guarantees the Chromium window is mapped, focused, and fullscreen.
matchbox-window-manager -use_titlebar no &

# All kiosk-hardening flags preserved from the former cage ExecStart. Only changes vs
# Wayland: --ozone-platform=x11 (was wayland); + --start-fullscreen (belt-and-suspenders
# with --kiosk under matchbox); + software GL selection (--use-gl=angle
# --use-angle=swiftshader) because the DSI scanout card has no render node — the X11
# analogue of the old WLR_RENDERER=pixman. The SPA uses no WebGL, so software GL is fine.
# Cache dirs use $CACHE_DIR (= the unit's %t/chromium-cache RuntimeDirectory on tmpfs).
exec /usr/bin/chromium-browser \
  --kiosk \
  --noerrdialogs \
  --disable-infobars \
  --no-first-run \
  --no-default-browser-check \
  --ozone-platform=x11 \
  --start-fullscreen \
  --use-gl=angle \
  --use-angle=swiftshader \
  --overscroll-history-navigation=0 \
  --disable-pinch \
  --disable-session-crashed-bubble \
  --disable-extensions \
  --disable-background-timer-throttling \
  --disable-renderer-backgrounding \
  --disable-backgrounding-occluded-windows \
  --user-data-dir=/var/lib/timetracking/chromium-profile \
  --disk-cache-dir="${CACHE_DIR:-/run/chromium-cache}" \
  --disk-cache-size=1 \
  --media-cache-dir="${CACHE_DIR:-/run/chromium-cache}" \
  --media-cache-size=1 \
  --check-for-update-interval=31536000 \
  --disable-background-networking \
  --disable-component-update \
  --disable-domain-reliability \
  --disable-sync \
  --disable-breakpad \
  --disable-crash-reporter \
  --disable-client-side-phishing-detection \
  --no-pings \
  --metrics-recording-only \
  --password-store=basic \
  --disable-translate \
  --disable-features=Translate,TranslateUI,MediaRouter,DialMediaRouteProvider,OptimizationHints,AutofillServerCommunication,InterestFeedContentSuggestions \
  http://localhost:8080

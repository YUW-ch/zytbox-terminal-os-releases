#!/bin/bash
# OS app-layer OTA (Level 1) — PREPARE step. Fetches the latest signed os-payload,
# verifies it (fail-closed) and that it is strictly newer than what's installed,
# and STAGES it onto the persistent mount. Like update-app.sh it does NOT mutate
# the locked root or touch the overlay; lib-update.sh apply_os performs the
# backup + rsync + rollback, driven by update-all.sh (overlay off) or
# apply-on-boot.sh (overlay on).
#
# The payload updates only the on-device code this repo installs —
# /opt/timetracking/{app,scripts} and the systemd units. It never touches the
# kernel, apt packages, bootloader, boot config, or /opt/timetracking/config.
#
#   ${RELEASE_BASE_URL}/os/latest                          -> plaintext tag
#   ${RELEASE_BASE_URL}/os/<tag>/os-payload.tar.gz         -> app/ scripts/ systemd/
#   ${RELEASE_BASE_URL}/os/<tag>/os-payload.tar.gz.minisig -> signature
set -euo pipefail

LOG_TAG="tt-update-os"
TT_ROOT="/opt/timetracking"
CONFIG_FILE="$TT_ROOT/config/update-config.env"
# shellcheck source=lib-update.sh
. "$TT_ROOT/scripts/lib-update.sh"
log() { llog "$1"; }

RELEASE_BASE_URL=""
# shellcheck source=/dev/null
[ -f "$CONFIG_FILE" ] && . "$CONFIG_FILE"
if [ -z "$RELEASE_BASE_URL" ] || [ "$RELEASE_BASE_URL" = "__REPLACE_WITH_YOUR_RELEASE_BASE_URL__" ]; then
  log "RELEASE_BASE_URL not configured - OS auto-update disabled."
  exit 0
fi
RELEASE_BASE_URL="${RELEASE_BASE_URL%/}"
OS_BASE="${RELEASE_BASE_URL}/os"

LATEST_TAG=$(curl -fsS "${OS_BASE}/latest" | tr -d '[:space:]' || echo "")
if [ -z "$LATEST_TAG" ]; then
  log "No OS payload published yet (${OS_BASE}/latest) - nothing to do"
  exit 0
fi
# Unsigned input that becomes a URL: check it first.
valid_tag "$LATEST_TAG" || { log "Refusing malformed OS tag '${LATEST_TAG}'"; exit 1; }

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

log "Fetching OS payload ${LATEST_TAG}..."
curl -fsS -o "$TMP/os.tar.gz"         "${OS_BASE}/${LATEST_TAG}/os-payload.tar.gz"         || { log "os download failed"; exit 1; }
curl -fsS -o "$TMP/os.tar.gz.minisig" "${OS_BASE}/${LATEST_TAG}/os-payload.tar.gz.minisig" || { log "os signature download failed"; exit 1; }

NEW_BUILD="$(verify_artifact "$TMP/os.tar.gz" "$TMP/os.tar.gz.minisig" os "$LATEST_TAG")" || {
  log "SIGNATURE VERIFICATION FAILED for OS ${LATEST_TAG} - refusing"
  exit 1
}
CUR_BUILD="$(current_build os)"
if [ "$NEW_BUILD" -eq "$CUR_BUILD" ]; then
  log "OS ${LATEST_TAG} already current"
  exit 0
fi
if [ "$NEW_BUILD" -lt "$CUR_BUILD" ]; then
  log "Refusing OS downgrade: offered build ${NEW_BUILD} < installed ${CUR_BUILD} (${LATEST_TAG})"
  exit 1
fi

STAGE="$TT_STAGE_DIR/os"
rm -rf "$STAGE"; mkdir -p "$STAGE"
tar -xzf "$TMP/os.tar.gz" -C "$STAGE"
[ -d "$STAGE/app" ] && [ -d "$STAGE/scripts" ] || { log "payload missing app/ or scripts/ - refusing"; rm -rf "$STAGE"; exit 1; }
printf '%s\n' "$LATEST_TAG" > "$TT_STAGE_DIR/os.tag"
printf '%s\n' "$NEW_BUILD"  > "$TT_STAGE_DIR/os.build"
log "OS ${LATEST_TAG} verified and staged"

#!/bin/bash
# Shared helpers for the on-device OTA + maintenance flow. Sourced, not executed.
#
# Persistence model (this is the crux): with the read-only overlay enabled, / is
# RAM-backed and the raspi-config overlay toggle only takes effect on the NEXT
# boot. So we NEVER mutate the locked root in-place. Instead:
#   1. "prepare" (update-app.sh / update-os.sh) downloads + verifies + stages the
#      payload under /var/lib/timetracking (a separate PERSISTENT mount that stays
#      writable even under the overlay);
#   2. if the overlay is off we apply immediately; if it's on we request a
#      "writable boot" (marker + disable overlay + reboot);
#   3. apply-on-boot.sh applies the staged payloads on that writable boot, then
#      re-locks the overlay and reboots back.
#
# Security model: every artifact ships a minisign signature whose *trusted*
# (signed) comment carries "tag=<tag> build=<epoch> channel=<web|os> env=<env>".
# We verify against the baked-in public key (fail-closed) and refuse anything not
# validly signed, not signed for this tag/channel/environment, or not strictly
# newer than what's installed (anti-downgrade). Staged payloads are only trusted
# because $TT_PERSIST is root-only (persist_lockdown).

TT_ROOT="${TT_ROOT:-/opt/timetracking}"
TT_PUBKEY="${TT_PUBKEY:-$TT_ROOT/config/minisign.pub}"
TT_PERSIST="${TT_PERSIST:-/var/lib/timetracking}"
TT_STATE_DIR="${TT_STATE_DIR:-$TT_PERSIST/update-state}"
TT_BAKED_BUILD_FILE="${TT_BAKED_BUILD_FILE:-$TT_ROOT/config/baked-build}"
TT_STAGE_DIR="${TT_STAGE_DIR:-$TT_PERSIST/staged}"      # verified payloads (persistent)
TT_MAINT_DIR="${TT_MAINT_DIR:-$TT_PERSIST/maintenance}"
TT_PENDING="${TT_PENDING:-$TT_MAINT_DIR/pending}"        # a writable boot is requested
TT_APT_FLAG="${TT_APT_FLAG:-$TT_MAINT_DIR/apt}"          # run apt security upgrade on it
UNIT_DIR="${UNIT_DIR:-/etc/systemd/system}"
# Restarted in place by apply_os. Only kiosk + nfc are health-checked
# (health-check.sh); network and ble are restarted but never gate an update — a
# terminal without a Bluetooth adapter must not roll back every OS release.
RUNTIME_SERVICES="${RUNTIME_SERVICES:-timetracking-nfc.service timetracking-kiosk.service timetracking-network.service timetracking-ble.service}"

llog() { logger -t "${LOG_TAG:-tt-update}" "$1"; echo "$1"; }

# --- signature verification + build tracking -------------------------------

# valid_tag <tag>: release tags are "v<YYYYMMDD>-<git short sha>" (release.sh).
# The tag comes from the unsigned "latest" file and becomes a URL and a path
# under $TT_ROOT/releases (rm -rf'd on rollback), so nothing else gets through —
# no "/", no "..".
valid_tag() { printf '%s' "$1" | grep -Eqx 'v[0-9]{8}-[0-9A-Za-z]{1,40}'; }

# device_env: the environment this image was built for (build-image.sh stamps
# it). Same default as first-boot provisioning for images without the stamp.
device_env() {
  local e; e="$(tr -d '[:space:]' < "$TT_ROOT/ENVIRONMENT" 2>/dev/null || true)"
  printf '%s\n' "${e:-production}"
}

# tc_field <trusted comment> <key> -> value of "key=value" in the signed comment.
tc_field() { printf '%s\n' "$1" | tr ' ' '\n' | sed -n "s/^$2=//p" | head -n1; }

# verify_artifact <file> <sigfile> <channel> <tag> -> prints signed build epoch
# on success (0), else prints a reason to stderr and returns non-zero.
# Fail-closed. The signed (trusted) comment must name exactly this channel
# (web|os), this tag and this device's environment, so a validly signed bundle
# can't be replayed under another tag, into the other channel, or onto the
# other environment's fleet (test and prod may share a signing key).
verify_artifact() {
  local file="$1" sig="$2" channel="$3" tag="$4" out tc build env
  command -v minisign >/dev/null 2>&1 || { echo "minisign not installed" >&2; return 1; }
  [ -f "$TT_PUBKEY" ] || { echo "no public key at $TT_PUBKEY (fail-closed)" >&2; return 1; }
  [ -f "$file" ] && [ -f "$sig" ] || { echo "artifact or signature missing" >&2; return 1; }
  out="$(minisign -Vm "$file" -x "$sig" -p "$TT_PUBKEY" 2>&1)" \
    || { echo "signature INVALID: $out" >&2; return 1; }
  tc="$(printf '%s\n' "$out" | sed -n 's/^[Tt]rusted comment: //p' | head -n1)"
  [ "$(tc_field "$tc" channel)" = "$channel" ] \
    || { echo "signed channel '$(tc_field "$tc" channel)' is not '$channel'" >&2; return 1; }
  [ "$(tc_field "$tc" tag)" = "$tag" ] \
    || { echo "signed tag '$(tc_field "$tc" tag)' is not '$tag'" >&2; return 1; }
  env="$(device_env)"
  [ "$(tc_field "$tc" env)" = "$env" ] \
    || { echo "signed env '$(tc_field "$tc" env)' is not this device's '$env'" >&2; return 1; }
  build="$(tc_field "$tc" build)"
  printf '%s' "$build" | grep -Eqx '[0-9]+' || { echo "no build number in signed comment" >&2; return 1; }
  printf '%s\n' "$build"
}

current_build() {  # <channel: web|os>
  local f="$TT_STATE_DIR/$1.build"
  if [ -f "$f" ]; then cat "$f"; return; fi
  [ -f "$TT_BAKED_BUILD_FILE" ] && cat "$TT_BAKED_BUILD_FILE" || echo 0
}
set_build() { mkdir -p "$TT_STATE_DIR"; printf '%s\n' "$2" > "$TT_STATE_DIR/$1.build"; }

# --- overlay / writable-boot request ---------------------------------------

# overlay_on: true when the RUNNING root is the read-only overlay, i.e. writes to
# / are RAM-backed (tmpfs) and discarded on reboot. We read the LIVE kernel
# cmdline — the real state of this boot — because raspi-config enable/disable
# _overlayfs work by adding/removing exactly this `overlayroot=tmpfs` token in
# /boot/firmware/cmdline.txt.
#
# NB: do NOT go back to `raspi-config nonint get_overlay_now | grep -q 1`. That
# helper prints 0 when the overlay is ENABLED and 1 when DISABLED, so matching on
# "1" was inverted: it reported the overlay OFF while it was on (updates got
# applied to the ephemeral root and vanished on reboot) and ON while it was off
# (a needless writable boot that re-locked a device we had just unlocked).
overlay_on() { grep -qw "overlayroot=tmpfs" /proc/cmdline; }

# persist_ok: true when the persistent data dir is a genuine separate mountpoint.
# Under the overlay everything on / is tmpfs-backed; only $TT_PERSIST survives a
# reboot, so staged payloads AND the Chromium profile (pairing key + offline
# queue) must live on a real mount there.
persist_ok() { mountpoint -q "$TT_PERSIST"; }

# overlay_persist_guard: when the overlay is on, refuse (non-zero) unless the
# persistent mount is real. Applying anything otherwise is silently lost on the
# next reboot — OTA payloads, the pairing key, and queued offline punches alike.
# No-op when the overlay is off (root is writable and persistent). Callers MUST
# exit on a non-zero return.
overlay_persist_guard() {
  overlay_on || return 0
  persist_ok && return 0
  llog "REFUSING: read-only overlay is active but $TT_PERSIST is not a persistent mount"
  llog "  writes (OTA payloads, pairing key, offline punches) are RAM-backed and lost on reboot."
  llog "  Reprovision with scripts/03-enable-readonly-overlay.sh (it requires a persistent"
  llog "  $TT_PERSIST mount) or turn the overlay off with scripts/disable-readonly-overlay.sh."
  return 1
}

# request_writable_boot: mark that a writable boot is needed, disable the overlay
# (effective next boot), and reboot. apply-on-boot.sh takes over on that boot.
request_writable_boot() {
  mkdir -p "$TT_MAINT_DIR"
  : > "$TT_PENDING"
  raspi-config nonint disable_overlayfs
  llog "Requesting writable boot (overlay off + reboot)"
  systemctl reboot
}

# --- apply (mutates the root; caller must ensure it is writable) ------------

# apply_web <staged_web_dir> <tag> <build>  — install a staged SPA build, flip the
# symlink, health-check, roll back on failure. Returns 0 on success.
apply_web() {
  local staged="$1" tag="$2" build="$3"
  local versions="$TT_ROOT/releases" cur="$TT_ROOT/current" newdir
  valid_tag "$tag" || { llog "invalid web tag '$tag' - refusing"; return 1; }
  newdir="$versions/$tag"
  mkdir -p "$versions"
  rm -rf "$newdir"; mkdir -p "$newdir/web"
  cp -a "$staged/." "$newdir/web/"
  if ! "$TT_ROOT/scripts/health-check.sh" "$newdir"; then
    llog "web pre-switch health check failed for $tag - discarding"
    rm -rf "$newdir"; return 1
  fi
  local prev; prev="$(readlink -f "$cur" 2>/dev/null || echo "")"
  ln -sfn "$newdir" "$cur"
  systemctl restart timetracking-kiosk.service
  sleep 5
  if "$TT_ROOT/scripts/health-check.sh"; then
    set_build web "$build"
    llog "web update $tag applied"
    ls -1dt "$versions"/v*/ 2>/dev/null | tail -n +4 | xargs -r rm -rf
    return 0
  fi
  llog "web post-switch health check failed - rolling back"
  [ -n "$prev" ] && { ln -sfn "$prev" "$cur"; systemctl restart timetracking-kiosk.service; }
  rm -rf "$newdir"; return 1
}

# apply_os <staged_os_dir> <build>  — install a staged OS payload (app/scripts +
# systemd units) with backup + rollback. Returns 0 on success.
apply_os() {
  local staged="$1" build="$2" bdir units s u
  [ -d "$staged/app" ] && [ -d "$staged/scripts" ] || { llog "bad os payload - skipping"; return 1; }
  for s in "$staged/scripts/"*.sh; do
    bash -n "$s" || { llog "syntax error in $(basename "$s") - refusing os apply"; return 1; }
  done
  bdir="$(mktemp -d)"
  tar -czf "$bdir/tt.tgz" -C "$TT_ROOT" app scripts
  units="$(cd "$UNIT_DIR" && ls timetracking-*.service timetracking-*.timer 2>/dev/null || true)"
  # shellcheck disable=SC2086
  [ -n "$units" ] && tar -czf "$bdir/units.tgz" -C "$UNIT_DIR" $units
  # rsync replaces each file via temp+rename, safe even for the running scripts.
  rsync -a "$staged/app/"     "$TT_ROOT/app/"
  rsync -a "$staged/scripts/" "$TT_ROOT/scripts/"
  chmod +x "$TT_ROOT/scripts/"*.sh 2>/dev/null || true
  if [ -d "$staged/systemd" ]; then
    cp "$staged/systemd/"*.service "$UNIT_DIR/" 2>/dev/null || true
    cp "$staged/systemd/"*.timer   "$UNIT_DIR/" 2>/dev/null || true
  fi
  systemctl daemon-reload
  if [ -d "$staged/systemd" ]; then
    for u in $(cd "$staged/systemd" && ls ./*.service ./*.timer 2>/dev/null | sed 's#^\./##'); do
      systemctl enable "$u" >/dev/null 2>&1 || true
    done
  fi
  # shellcheck disable=SC2086
  systemctl restart $RUNTIME_SERVICES || true
  sleep 5
  if "$TT_ROOT/scripts/health-check.sh"; then
    set_build os "$build"; llog "os update applied"; rm -rf "$bdir"; return 0
  fi
  llog "os post-apply health check failed - rolling back"
  tar -xzf "$bdir/tt.tgz" -C "$TT_ROOT"
  [ -f "$bdir/units.tgz" ] && tar -xzf "$bdir/units.tgz" -C "$UNIT_DIR"
  systemctl daemon-reload
  # shellcheck disable=SC2086
  systemctl restart $RUNTIME_SERVICES || true
  rm -rf "$bdir"; return 1
}

# --- runtime hardening (harden-on-boot.sh, every boot, as root) -------------
# These repair devices in the field too: an OS payload can't change /etc or
# re-run provisioning, but it ships this code and the unit that runs it.

TT_PROFILE_DIR="${TT_PROFILE_DIR:-$TT_PERSIST/chromium-profile}"

# persist_lockdown: $TT_PERSIST holds state root trusts (staged OTA payloads,
# writable-boot markers, build numbers, Wi-Fi/BLE agent state), so only root may
# own it. ttkiosk (Chromium + the file server) gets the Chromium profile and
# nothing else. Images before this fix chowned the whole dir to ttkiosk, which
# let it plant a "verified" payload for root to install. So: anything in it not
# owned by root (or a symlink) was planted and goes, and on the first
# locked-down boot the staged payloads + markers go too — they're re-fetched and
# re-verified on the next run, and are never legitimately pending at that point
# (an OS payload that brings this fix is applied before the reboot that runs it).
persist_lockdown() {
  local owner
  mkdir -p "$TT_PERSIST"
  owner="$(stat -c %u "$TT_PERSIST")"
  if [ "$owner" != 0 ]; then
    llog "$TT_PERSIST was owned by uid $owner - locking down to root, discarding staged payloads + markers"
    rm -rf "$TT_STAGE_DIR" "$TT_PENDING" "$TT_APT_FLAG"
  fi
  chown root:root "$TT_PERSIST"
  chmod 0755 "$TT_PERSIST"
  find "$TT_PERSIST" -mindepth 1 -maxdepth 1 ! -path "$TT_PROFILE_DIR" \
    \( -type l -o ! -user root \) -print -exec rm -rf {} + \
    | while IFS= read -r p; do llog "removed non-root entry $p"; done
  if [ -L "$TT_PROFILE_DIR" ] || { [ -e "$TT_PROFILE_DIR" ] && [ ! -d "$TT_PROFILE_DIR" ]; }; then
    llog "removed bogus $TT_PROFILE_DIR"
    rm -f "$TT_PROFILE_DIR"
  fi
  if id -u ttkiosk >/dev/null 2>&1; then
    install -d -o ttkiosk -g ttkiosk -m 0700 "$TT_PROFILE_DIR"
  fi
}

# install_if_changed <src> <dest>: copy as root 0644 only when the content
# differs (no needless SD writes when the root is writable).
install_if_changed() {
  cmp -s "$1" "$2" 2>/dev/null && return 0
  install -D -o root -g root -m 0644 "$1" "$2"
}

# ensure_apt_origins: what unattended-upgrades may install. Debian -security
# alone isn't enough on Raspberry Pi OS: chromium-browser (the kiosk's biggest
# attack surface), the kernel and the firmware come from the Raspberry Pi
# archive, so without its origin they'd never be patched. Still no auto-reboot
# (os-maintenance.sh owns reboots).
TT_APT_CONF="${TT_APT_CONF:-/etc/apt/apt.conf.d/51unattended-upgrades-timetracking}"
ensure_apt_origins() {
  local tmp; tmp="$(mktemp)"
  cat > "$tmp" <<'CONF'
// Managed by /opt/timetracking/scripts/lib-update.sh (ensure_apt_origins).
Unattended-Upgrade::Allowed-Origins {
    "${distro_id}:${distro_codename}-security";
};
// chromium-browser, the kernel and the firmware come from the Raspberry Pi archive.
Unattended-Upgrade::Origins-Pattern {
    "origin=Raspberry Pi Foundation,codename=${distro_codename}";
};
Unattended-Upgrade::Automatic-Reboot "false";
CONF
  install_if_changed "$tmp" "$TT_APT_CONF"
  rm -f "$tmp"
}

# ensure_chromium_policy: the managed Chromium policy (no DevTools, no
# navigation off the kiosk app, no file dialogs/downloads/printing). Installed
# to both dirs the chromium-browser build may read. Under the read-only overlay
# /etc is RAM-backed, so this re-applies it from the persistent /opt every boot.
TT_CHROMIUM_POLICY="${TT_CHROMIUM_POLICY:-$TT_ROOT/app/chromium/timetracking-kiosk.json}"
ensure_chromium_policy() {
  local d
  [ -f "$TT_CHROMIUM_POLICY" ] || { llog "no Chromium policy at $TT_CHROMIUM_POLICY"; return 1; }
  for d in /etc/chromium/policies/managed /etc/chromium-browser/policies/managed; do
    install_if_changed "$TT_CHROMIUM_POLICY" "$d/timetracking-kiosk.json"
  done
}

# ensure_ssh_lockdown [--no-validate]: SSH for the admin user with a key only.
# Installs app/ssh/admin_authorized_keys as ttadmin's authorized_keys (replacing
# it, so OTA adds and revokes keys fleet-wide) and an sshd drop-in that turns
# password logins off and admits only ttadmin. The ttadmin password stays for
# sudo and the local console. Refuses (leaves password logins on) when the key
# file holds no valid key, so a bad payload can't lock everyone out; NinjaOne
# stays as the way in either way. 00- so it wins: sshd keeps the first value.
TT_SSH_KEYS="${TT_SSH_KEYS:-$TT_ROOT/app/ssh/admin_authorized_keys}"
TT_SSH_USER="${TT_SSH_USER:-ttadmin}"
TT_SSHD_DROPIN="${TT_SSHD_DROPIN:-/etc/ssh/sshd_config.d/00-timetracking.conf}"
ensure_ssh_lockdown() {
  local home keys tmp changed=0
  id -u "$TT_SSH_USER" >/dev/null 2>&1 || { llog "no $TT_SSH_USER user - SSH lockdown skipped"; return 1; }
  [ -f "$TT_SSH_KEYS" ] || { llog "no $TT_SSH_KEYS - SSH lockdown skipped"; return 1; }
  keys="$(grep -E '^(ssh-|ecdsa-|sk-)' "$TT_SSH_KEYS" || true)"
  if [ -z "$keys" ] || ! printf '%s\n' "$keys" | ssh-keygen -lf /dev/stdin >/dev/null 2>&1; then
    llog "no valid key in $TT_SSH_KEYS - leaving SSH password logins on"
    return 1
  fi
  home="$(getent passwd "$TT_SSH_USER" | cut -d: -f6)"
  install -d -o "$TT_SSH_USER" -g "$TT_SSH_USER" -m 0700 "$home/.ssh"
  tmp="$(mktemp)"
  printf '%s\n' "$keys" > "$tmp"
  if ! cmp -s "$tmp" "$home/.ssh/authorized_keys"; then
    install -o "$TT_SSH_USER" -g "$TT_SSH_USER" -m 0600 "$tmp" "$home/.ssh/authorized_keys"
  fi
  cat > "$tmp" <<CONF
# Managed by /opt/timetracking/scripts/lib-update.sh (ensure_ssh_lockdown).
PasswordAuthentication no
KbdInteractiveAuthentication no
PubkeyAuthentication yes
PermitRootLogin no
AllowUsers $TT_SSH_USER
CONF
  cmp -s "$tmp" "$TT_SSHD_DROPIN" || { install -D -o root -g root -m 0644 "$tmp" "$TT_SSHD_DROPIN"; changed=1; }
  rm -f "$tmp"
  # Validate against the real host keys; skipped in the image build, which has none.
  if [ "${1:-}" != "--no-validate" ] && ls /etc/ssh/ssh_host_*_key >/dev/null 2>&1 \
     && ! sshd -t 2>/dev/null; then
    llog "sshd rejects the config with $TT_SSHD_DROPIN - removing it"
    rm -f "$TT_SSHD_DROPIN"
    return 1
  fi
  [ "$changed" = 1 ] && { systemctl try-reload-or-restart ssh.service 2>/dev/null || true; }
  return 0
}

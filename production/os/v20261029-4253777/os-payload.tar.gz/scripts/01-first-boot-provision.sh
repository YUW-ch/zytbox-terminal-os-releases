#!/bin/bash
# Runs once on first boot via timetracking-firstboot.service.
set -euo pipefail

LOG_TAG="tt-provision"
log() { logger -t "$LOG_TAG" "$1"; echo "$1"; }

# NOTE: SSH host keys are handled separately by timetracking-sshkeys.service,
# which runs before sshd on every boot (no network dependency), not here — this
# provisioning service waits for network-online and runs only once, which is too
# late and too fragile for something sshd needs to start at all.

# --- Expand root filesystem to fill the SD card ---
# do_expand_rootfs grows the PARTITION, but the resize2fs that grows the ext4
# filesystem into it does NOT fire reliably on this headless image (the stock
# Raspberry Pi init_resize hook isn't wired up) — leaving a full 3.1G filesystem
# on a 59G partition, which then breaks sshd, deploys and everything else. So
# grow the filesystem explicitly here too. timetracking-rootfs-grow.service is an
# every-boot safety net for the case where the kernel only sees the enlarged
# partition after a reboot. Both steps are idempotent.
raspi-config nonint do_expand_rootfs 2>/dev/null || true
resize2fs "$(findmnt -no SOURCE /)" 2>/dev/null || true
log "Root filesystem expanded"

# --- Create the dedicated kiosk service user if it doesn't exist ---
# The 'input' group lets Xorg/libinput read the NFC daemon's virtual keyboard
# (/dev/uinput -> /dev/input/event*); video+render are for the DSI panel/DRM.
if ! id -u ttkiosk >/dev/null 2>&1; then
  useradd --system --create-home --shell /usr/sbin/nologin \
    --groups video,input,render ttkiosk
  log "Created ttkiosk service user"
fi

# --- Ensure writable data dir exists (persists outside the overlay root) ---
# Root-only: it also holds state root trusts (staged OTA payloads, writable-boot
# markers, agent state). ttkiosk only gets the Chromium profile. Same rule as
# persist_lockdown (lib-update.sh), which re-applies it on every boot.
install -d -o root -g root -m 0755 /var/lib/timetracking
install -d -o ttkiosk -g ttkiosk -m 0700 /var/lib/timetracking/chromium-profile

# --- Hostname based on the Pi's unique CPU serial for easy identification in
#     NinjaOne. Test images get a 'test' prefix so they're obvious in the fleet.
#     Backend pairing is done in-app (device key on the Setup screen), so there
#     is no API token to provision here. ---
ENV_NAME=$(cat /opt/timetracking/ENVIRONMENT 2>/dev/null || echo production)
PREFIX="tt-kiosk"
[ "$ENV_NAME" = "test" ] && PREFIX="tt-kiosk-test"
SERIAL=$(awk '/Serial/ {print $3}' /proc/cpuinfo)
NEW_HOSTNAME="${PREFIX}-${SERIAL: -6}"
hostnamectl set-hostname "$NEW_HOSTNAME" || true
# Keep /etc/hosts in sync with the new hostname so loopback name resolution works
# — otherwise every sudo prints "unable to resolve host <name>" and blocks briefly
# on the failed lookup. Update the existing 127.0.1.1 line or add one.
if grep -q '^127\.0\.1\.1' /etc/hosts; then
  sed -i "s/^127\.0\.1\.1.*/127.0.1.1\t${NEW_HOSTNAME}/" /etc/hosts
else
  printf '127.0.1.1\t%s\n' "$NEW_HOSTNAME" >> /etc/hosts
fi
log "Set hostname to ${NEW_HOSTNAME} (env: ${ENV_NAME})"

log "First-boot provisioning complete"

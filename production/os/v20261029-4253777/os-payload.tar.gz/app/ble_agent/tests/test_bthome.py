import ctypes.util
import os
import sys
import unittest

import bthome
import crypto
from tests.helpers import HAS_AESCCM, encrypted, plain

# Official example from https://bthome.io/encryption/ (BTHome v2).
SPEC_KEY = bytes.fromhex("231d39c1d7cc1ab1aee224cd096db932")
SPEC_MAC = bytes.fromhex("5448E68F80A5")
SPEC_NONCE = bytes.fromhex("5448e68f80a5d2fc4133221100")
SPEC_CIPHERTEXT = bytes.fromhex("e445f3c9962b")
SPEC_MIC = bytes.fromhex("6c7c4519")
SPEC_SERVICE_DATA = bytes.fromhex("d2fc41e445f3c9962b332211006c7c4519")
SPEC_PLAINTEXT = bytes.fromhex("02ca0903bf13")  # temperature 25.06 C, humidity 50.55 %


@unittest.skipUnless(crypto.SUPPORTED, "no AES-CCM backend on this machine")
class SpecVectorTest(unittest.TestCase):
    def test_raw_decrypt(self):
        self.assertEqual(crypto.decrypt(SPEC_KEY, SPEC_NONCE, SPEC_CIPHERTEXT, SPEC_MIC), SPEC_PLAINTEXT)

    def test_decode_service_data(self):
        adv = bthome.decode(SPEC_MAC, SPEC_SERVICE_DATA, SPEC_KEY)
        self.assertTrue(adv.encrypted)
        self.assertTrue(adv.ok)
        self.assertEqual(adv.counter, 0x00112233)
        self.assertEqual(adv.objects, [(0x02, 2506), (0x03, 5055)])

    def test_wrong_key_fails_closed(self):
        adv = bthome.decode(SPEC_MAC, SPEC_SERVICE_DATA, bytes(16))
        self.assertTrue(adv.encrypted)
        self.assertFalse(adv.ok)
        self.assertEqual(adv.objects, [])

    def test_tampered_mic_fails(self):
        bad = SPEC_SERVICE_DATA[:-1] + bytes([SPEC_SERVICE_DATA[-1] ^ 1])
        self.assertFalse(bthome.decode(SPEC_MAC, bad, SPEC_KEY).ok)

    def test_wrong_mac_fails(self):
        # The MAC is part of the nonce: a copied advert from another address fails.
        self.assertFalse(bthome.decode(bytes(6), SPEC_SERVICE_DATA, SPEC_KEY).ok)

    def test_no_key(self):
        adv = bthome.decode(SPEC_MAC, SPEC_SERVICE_DATA, None)
        self.assertTrue(adv.encrypted)
        self.assertFalse(adv.ok)
        self.assertEqual(adv.counter, 0x00112233)


class LibcryptoShimTest(unittest.TestCase):
    """The ctypes fallback used on OTA-updated terminals without python3-cryptography."""

    def setUp(self):
        linux = sys.platform.startswith("linux") and ctypes.util.find_library("crypto")
        if not (linux or os.environ.get("TT_LIBCRYPTO")):
            self.skipTest("no loadable libcrypto (set TT_LIBCRYPTO on macOS)")
        self.shim = crypto._load_libcrypto()
        if self.shim is None:
            self.skipTest("libcrypto failed to load")

    def test_spec_vector(self):
        self.assertEqual(self.shim.decrypt(SPEC_KEY, SPEC_NONCE, SPEC_CIPHERTEXT, SPEC_MIC), SPEC_PLAINTEXT)

    def test_bad_mic(self):
        self.assertIsNone(self.shim.decrypt(SPEC_KEY, SPEC_NONCE, SPEC_CIPHERTEXT, b"\0\0\0\0"))


class PlainParseTest(unittest.TestCase):
    MAC = bytes.fromhex("7CC6B6A1B2C3")

    def test_shelly_button_press(self):
        adv = bthome.decode(self.MAC, plain(packet_id=7, battery=100, button=1))
        self.assertFalse(adv.encrypted)
        self.assertTrue(adv.ok)
        self.assertEqual(adv.packet_id, 7)
        self.assertEqual(adv.battery, 100)
        self.assertEqual(adv.button, 1)

    def test_beacon_without_press(self):
        adv = bthome.decode(self.MAC, plain(battery=55, button=0))
        self.assertEqual(adv.battery, 55)
        self.assertEqual(adv.button, 0)

    def test_unknown_object_stops_parsing(self):
        data = bytes([0xD2, 0xFC, 0x40, 0x00, 0x02, 0x01, 0x50, 0xEE, 0x01, 0x3A, 0x01])
        adv = bthome.decode(self.MAC, data)
        self.assertEqual(adv.objects, [(0x00, 2), (0x01, 0x50)])
        self.assertIsNone(adv.button)

    def test_truncated_object(self):
        adv = bthome.decode(self.MAC, bytes([0xD2, 0xFC, 0x40, 0x01, 0x40, 0x02, 0x01]))
        self.assertEqual(adv.objects, [(0x01, 0x40)])

    def test_signed_and_multibyte(self):
        # temperature 0x02 is sint16 * 0.01: -1.00 C = -100 = 0xff9c
        adv = bthome.decode(self.MAC, bytes([0xD2, 0xFC, 0x40, 0x02, 0x9C, 0xFF]))
        self.assertEqual(adv.objects, [(0x02, -100)])

    def test_not_bthome(self):
        self.assertIsNone(bthome.decode(self.MAC, bytes([0x95, 0xFE, 0x40, 0x01])))
        # BTHome v1 device info (version bits != 2)
        self.assertIsNone(bthome.decode(self.MAC, bytes([0xD2, 0xFC, 0x20, 0x01, 0x40])))

    @unittest.skipUnless(HAS_AESCCM and crypto.SUPPORTED, "needs cryptography")
    def test_encrypted_round_trip(self):
        key = "00112233445566778899aabbccddeeff"
        data = encrypted("7CC6B6A1B2C3", key, counter=42, battery=80, button=1)
        adv = bthome.decode(self.MAC, data, bytes.fromhex(key))
        self.assertTrue(adv.ok)
        self.assertEqual((adv.counter, adv.battery, adv.button), (42, 80, 1))


if __name__ == "__main__":
    unittest.main()


class EncryptedCounterTest(unittest.TestCase):
    def test_plain_has_no_counter(self):
        self.assertIsNone(bthome.encrypted_counter(plain()))

    def test_reads_counter_without_key(self):
        body = bytes(6) + (1234).to_bytes(4, "little") + bytes(4)
        self.assertEqual(bthome.encrypted_counter(bytes([0xD2, 0xFC, 0x45]) + body), 1234)

    def test_too_short(self):
        self.assertIsNone(bthome.encrypted_counter(bytes([0xD2, 0xFC, 0x45]) + bytes(8)))

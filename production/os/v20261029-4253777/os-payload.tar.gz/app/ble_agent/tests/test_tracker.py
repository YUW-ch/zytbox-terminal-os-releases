import json
import os
import stat
import tempfile
import unittest

import crypto
import tracker as T
from tests.helpers import HAS_AESCCM, FakeClock, encrypted, plain
from tracker import Tracker, iso

MAC = "7CC6B6A1B2C3"
MAC2 = "7CC6B6000002"
KEY = "00112233445566778899aabbccddeeff"


class Base(unittest.TestCase):
    def setUp(self):
        self.dir = tempfile.TemporaryDirectory()
        self.path = os.path.join(self.dir.name, "ble", "state.json")
        self.clock = FakeClock()
        self.arrived = []
        self.t = self.make()

    def tearDown(self):
        self.dir.cleanup()

    def make(self):
        return Tracker(self.path, wall=self.clock.wall, mono=self.clock.mono,
                       on_arrived=self.arrived.append)

    def watch(self, buttons=None, timeout=300, rssi=-85, enabled=True, t=None):
        (t or self.t).set_watch(enabled, "v1", timeout, rssi, buttons if buttons is not None else {MAC: None})

    def see(self, rssi=-60, mac=MAC, data=None, **kw):
        self.t.on_advert(mac, rssi, data if data is not None else plain(**kw))

    def kinds(self, t=None):
        evs, _ = (t or self.t).events()
        return [(e["mac"], e["kind"], e["at"]) for e in evs]

    def run_for(self, seconds, step=1.0):
        n = int(seconds / step)
        for _ in range(n):
            self.clock.advance(step)
            self.t.tick()

    def button(self, mac=MAC):
        return next(b for b in self.t.status()["buttons"] if b["mac"] == mac)


class ArrivalTest(Base):
    def setUp(self):
        super().setUp()
        self.watch()

    def test_two_sightings_three_seconds_apart(self):
        t0 = self.clock.w
        self.see()
        self.clock.advance(3)
        self.see()
        self.assertEqual(self.kinds(), [(MAC, "ARRIVED", iso(t0))])
        self.assertTrue(self.button()["present"])
        self.assertEqual(self.arrived, [MAC])

    def test_single_sighting_is_not_enough(self):
        self.see()
        self.run_for(120)
        self.assertEqual(self.kinds(), [])
        self.assertFalse(self.button()["present"])

    def test_burst_copies_under_three_seconds(self):
        for _ in range(10):
            self.see()
            self.clock.advance(0.2)
        self.assertEqual(self.kinds(), [])

    def test_weak_sightings_do_not_arrive(self):
        self.see(rssi=-90)
        self.clock.advance(10)
        self.see(rssi=-86)
        self.assertEqual(self.kinds(), [])
        self.clock.advance(10)
        self.see(rssi=-85)  # threshold is inclusive
        self.clock.advance(5)
        self.see(rssi=-80)
        self.assertEqual([k for _, k, _ in self.kinds()], ["ARRIVED"])

    def test_sightings_more_than_60s_apart(self):
        # Normal-mode button: one advert every 15 min never arrives.
        for _ in range(4):
            self.see()
            self.clock.advance(900)
        self.assertEqual(self.kinds(), [])

    def test_arrival_at_first_sighting_in_window(self):
        self.see()
        self.clock.advance(61)
        t1 = self.clock.w
        self.see()  # first one aged out; this one starts the window
        self.clock.advance(10)
        self.see()
        self.assertEqual(self.kinds(), [(MAC, "ARRIVED", iso(t1))])

    def test_unwatched_mac_ignored(self):
        self.see(mac=MAC2)
        self.clock.advance(5)
        self.see(mac=MAC2)
        self.assertEqual(self.kinds(), [])

    def test_disabled_watches_nothing(self):
        self.watch(enabled=False)
        self.see()
        self.clock.advance(5)
        self.see()
        self.assertEqual(self.kinds(), [])
        self.assertEqual(self.t.status()["buttons"], [])
        self.assertFalse(self.t.wants_scan())


class DepartureTest(Base):
    def setUp(self):
        super().setUp()
        self.watch(timeout=300)
        self.see()
        self.clock.advance(5)
        self.see()

    def test_left_after_timeout_at_last_sighting(self):
        self.run_for(100, step=10)
        last = self.clock.w
        self.see(rssi=-95)  # weak sightings still keep a present button present
        self.run_for(300)
        self.assertEqual([k for _, k, _ in self.kinds()], ["ARRIVED"])
        self.run_for(2)
        evs = self.kinds()
        self.assertEqual(evs[-1], (MAC, "LEFT", iso(last)))
        self.assertFalse(self.button()["present"])

    def test_wall_clock_jump_does_not_fake_departure(self):
        self.clock.w += 3600  # NTP step forward: monotonic unaffected
        self.clock.advance(100)
        self.t.tick()
        self.assertTrue(self.button()["present"])

    def test_rearrive_after_leaving(self):
        self.run_for(302)
        self.see()
        self.clock.advance(4)
        self.see()
        self.assertEqual([k for _, k, _ in self.kinds()], ["ARRIVED", "LEFT", "ARRIVED"])


class BeaconModeTest(Base):
    def setUp(self):
        super().setUp()
        self.watch()

    def test_unknown_until_enough_samples(self):
        self.see()
        self.assertIsNone(self.button()["beaconMode"])

    def test_beacon_interval(self):
        for _ in range(5):
            self.see()
            self.clock.advance(0.05)
            self.see()  # duplicate copy of the same advert
            self.clock.advance(10)
        self.assertIs(self.button()["beaconMode"], True)

    def test_normal_mode(self):
        for _ in range(4):
            self.see()
            self.clock.advance(900)
        self.assertIs(self.button()["beaconMode"], False)


@unittest.skipUnless(HAS_AESCCM and crypto.SUPPORTED, "needs cryptography")
class KeyedButtonTest(Base):
    def setUp(self):
        super().setUp()
        self.watch({MAC: KEY})

    def enc(self, counter, **kw):
        return encrypted(MAC, KEY, counter, **kw)

    def test_decrypted_with_increasing_counter_arrives(self):
        self.see(data=self.enc(10, battery=66))
        self.clock.advance(5)
        self.see(data=self.enc(11, battery=65))
        self.assertEqual([k for _, k, _ in self.kinds()], ["ARRIVED"])
        b = self.button()
        self.assertIs(b["decryptOk"], True)
        self.assertEqual(b["battery"], 65)

    def test_replayed_counter_dropped(self):
        adv = self.enc(10)
        self.see(data=adv)
        self.clock.advance(5)
        self.see(data=adv)  # attacker replays the captured advert
        self.clock.advance(5)
        self.see(data=self.enc(9))
        self.assertEqual(self.kinds(), [])

    def test_plaintext_from_keyed_button_dropped(self):
        self.see()
        self.clock.advance(5)
        self.see()
        self.assertEqual(self.kinds(), [])
        self.assertIs(self.button()["decryptOk"], False)

    def test_wrong_key_dropped(self):
        other = encrypted(MAC, "ff" * 16, 10)
        self.see(data=other)
        self.clock.advance(5)
        self.see(data=encrypted(MAC, "ff" * 16, 11))
        self.assertEqual(self.kinds(), [])
        self.assertIs(self.button()["decryptOk"], False)

    def test_replay_cannot_keep_button_present(self):
        last = self.enc(11)
        self.see(data=self.enc(10))
        self.clock.advance(5)
        self.see(data=last)
        for _ in range(40):
            self.clock.advance(10)
            self.see(data=last)
            self.t.tick()
        self.assertEqual([k for _, k, _ in self.kinds()], ["ARRIVED", "LEFT"])

    def test_unkeyed_button_sending_encrypted(self):
        self.watch({MAC: None})
        self.see(data=self.enc(1))
        self.assertIs(self.button()["decryptOk"], False)

    def test_key_change_resets_counter(self):
        self.see(data=self.enc(100))
        self.watch({MAC: "aa" * 16})
        self.see(data=encrypted(MAC, "aa" * 16, 1))
        self.assertIs(self.button()["decryptOk"], True)


class OutboxTest(Base):
    def setUp(self):
        super().setUp()
        self.watch({MAC: None, MAC2: None})
        for mac in (MAC, MAC2):
            self.see(mac=mac)
        self.clock.advance(4)
        for mac in (MAC, MAC2):
            self.see(mac=mac)

    def test_events_after_and_ack(self):
        evs, last = self.t.events()
        self.assertEqual([e["seq"] for e in evs], [1, 2])
        self.assertEqual(last, 2)
        self.assertEqual(set(evs[0]), {"id", "seq", "mac", "kind", "at", "rssi", "battery"})
        evs, last = self.t.events(after=1)
        self.assertEqual([e["seq"] for e in evs], [2])
        self.t.ack(1)
        evs, _ = self.t.events()
        self.assertEqual([e["seq"] for e in evs], [2])
        self.t.ack(2)
        evs, last = self.t.events()
        self.assertEqual(evs, [])
        self.assertEqual(last, 2)  # cursor stays put when the outbox is empty

    def test_unacked_events_survive_restart(self):
        self.t.ack(1)
        t2 = self.make()
        evs, _ = t2.events()
        self.assertEqual([e["seq"] for e in evs], [2])

    def test_seq_keeps_counting_after_reset(self):
        self.t.reset()
        self.assertEqual(self.t.events(), ([], 2))
        self.assertEqual(self.t.status()["buttons"], [])
        self.watch()
        self.see()
        self.clock.advance(4)
        self.see()
        evs, _ = self.t.events()
        self.assertEqual([e["seq"] for e in evs], [3])


class PersistenceTest(Base):
    def test_state_file_private_and_atomic(self):
        self.watch({MAC: KEY})
        st = os.stat(self.path)
        self.assertEqual(stat.S_IMODE(st.st_mode), 0o600)
        self.assertFalse(os.path.exists(self.path + ".tmp"))
        with open(self.path) as f:
            data = json.load(f)
        self.assertEqual(data["buttons"][MAC]["bindKey"], KEY)
        self.assertEqual(data["watch"]["version"], "v1")

    def test_watch_list_survives_restart(self):
        self.watch({MAC: KEY}, timeout=120, rssi=-80)
        t2 = self.make()
        self.assertEqual(t2.status()["watchVersion"], "v1")
        self.assertEqual(t2.absence_timeout_s, 120)
        self.assertEqual(t2.arrive_rssi, -80)
        self.assertEqual([b["mac"] for b in t2.status()["buttons"]], [MAC])

    @unittest.skipUnless(HAS_AESCCM and crypto.SUPPORTED, "needs cryptography")
    def test_counter_checkpointed_at_most_every_10_min(self):
        self.watch({MAC: KEY})
        self.see(data=encrypted(MAC, KEY, 5))  # absent, no transition
        self.run_for(T.SEEN_FLUSH_S + 5)

        def saved():
            with open(self.path) as f:
                return json.load(f)["buttons"][MAC]["lastCounter"]

        self.assertIsNone(saved())
        self.run_for(T.COUNTER_PERSIST_S, step=10)
        self.assertEqual(saved(), 5)
        # Transitions write the counter immediately.
        self.see(data=encrypted(MAC, KEY, 6))
        self.clock.advance(5)
        self.see(data=encrypted(MAC, KEY, 7))
        self.assertEqual(saved(), 7)
        self.assertEqual([k for _, k, _ in self.kinds()], ["ARRIVED"])

    def test_corrupt_state_starts_empty(self):
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        with open(self.path, "w") as f:
            f.write("{not json")
        t2 = self.make()
        self.assertEqual(t2.status()["buttons"], [])


class RestartReconciliationTest(Base):
    def setUp(self):
        super().setUp()
        self.watch(timeout=300)
        self.see()
        self.clock.advance(5)
        self.last = self.clock.w
        self.see()  # ARRIVED (state saved on the transition)

    def restart_after(self, downtime):
        self.clock.w += downtime
        self.clock.m = 50.0  # monotonic restarts with the process/boot
        self.t = self.make()

    def test_short_restart_continues(self):
        self.restart_after(60)
        self.assertTrue(self.button()["present"])
        self.see()
        self.run_for(200)
        self.assertEqual([k for _, k, _ in self.kinds()], ["ARRIVED"])

    def test_short_restart_then_gone_leaves_at_last_sighting(self):
        self.restart_after(200)
        self.run_for(99)
        self.assertEqual([k for _, k, _ in self.kinds()], ["ARRIVED"])
        self.run_for(3)
        self.assertEqual(self.kinds()[-1], (MAC, "LEFT", iso(self.last)))

    def test_long_downtime_emits_left_then_rearrives(self):
        self.restart_after(3600)  # e.g. power cut over lunch
        self.assertEqual(self.kinds()[-1], (MAC, "LEFT", iso(self.last)))
        self.assertFalse(self.button()["present"])
        t_back = self.clock.w
        self.see()
        self.clock.advance(4)
        self.see()
        self.assertEqual(self.kinds()[-1], (MAC, "ARRIVED", iso(t_back)))
        # The reconciliation LEFT was persisted right away.
        self.assertEqual([k for _, k, _ in self.kinds(self.make())], ["ARRIVED", "LEFT", "ARRIVED"])

    def test_clock_went_backwards(self):
        self.restart_after(-500)
        self.assertTrue(self.button()["present"])

    def test_last_seen_flushed_while_present(self):
        self.run_for(30)
        self.see()
        seen = self.clock.w
        self.run_for(T.SEEN_FLUSH_S)
        self.restart_after(10000)
        self.assertEqual(self.kinds()[-1], (MAC, "LEFT", iso(seen)))


class EnrollTest(Base):
    def test_strongest_press_in_window_newest_first(self):
        self.assertFalse(self.t.wants_scan())
        self.assertTrue(self.t.set_enroll(True))
        self.assertTrue(self.t.wants_scan())
        self.see(mac=MAC, rssi=-65, button=1, battery=50)
        self.clock.advance(0.3)
        self.see(mac=MAC2, rssi=-55, button=1, battery=40)  # same press window, stronger
        self.clock.advance(0.3)
        self.see(mac=MAC, rssi=-60, button=1)
        active, cands = self.t.enroll_state()
        self.assertTrue(active)
        self.assertEqual([(c["mac"], c["rssi"], c["battery"]) for c in cands], [(MAC2, -55, 40)])
        self.clock.advance(5)
        self.see(mac=MAC, rssi=-68, button=1, battery=50)
        _, cands = self.t.enroll_state()
        self.assertEqual([c["mac"] for c in cands], [MAC, MAC2])

    def test_filters(self):
        self.t.set_enroll(True)
        self.see(rssi=-71, button=1)  # too far away
        self.clock.advance(3)
        self.see(rssi=-50, button=0)  # beacon advert, not a press
        self.assertEqual(self.t.enroll_state()[1], [])

    @unittest.skipUnless(HAS_AESCCM and crypto.SUPPORTED, "needs cryptography")
    def test_encrypted_press_not_a_candidate(self):
        self.t.set_enroll(True)
        self.see(rssi=-50, data=encrypted(MAC, KEY, 1, button=1))
        self.assertEqual(self.t.enroll_state()[1], [])

    def test_candidates_expire_after_30s(self):
        self.t.set_enroll(True)
        self.see(rssi=-50, button=1)
        self.clock.advance(31)
        self.assertEqual(self.t.enroll_state()[1], [])

    def test_inactive_collects_nothing(self):
        self.see(rssi=-50, button=1)
        self.t.set_enroll(True)
        self.assertEqual(self.t.enroll_state()[1], [])

    def test_auto_off_after_10_min(self):
        self.t.set_enroll(True)
        self.run_for(T.ENROLL_TTL_S - 2, step=2)
        self.assertTrue(self.t.enroll_state()[0])
        self.run_for(4)
        self.assertEqual(self.t.enroll_state(), (False, []))

    def test_turn_off(self):
        self.t.set_enroll(True)
        self.see(rssi=-50, button=1)
        self.assertFalse(self.t.set_enroll(False))
        self.assertEqual(self.t.enroll_state(), (False, []))


if __name__ == "__main__":
    unittest.main()


class EnergyTest(Base):
    """Nothing polls: tick() says when it's next due and changes wake it up."""

    def setUp(self):
        super().setUp()
        self.changes = 0

        def changed():
            self.changes += 1
        self.t.on_change = changed

    def test_idle_tracker_schedules_nothing(self):
        self.assertIsNone(self.t.tick())
        self.watch()
        self.assertEqual(self.changes, 1)
        self.assertIsNone(self.t.tick())  # watched but nobody present yet

    def test_next_due_is_departure_or_flush(self):
        self.watch(timeout=300)
        self.see()
        self.clock.advance(3)
        self.see()
        self.assertEqual(self.changes, 2)  # watch + arrival
        self.assertAlmostEqual(self.t.tick(), 300.01, places=2)
        self.clock.advance(10)
        self.see()  # first sighting while present: a flush is now due
        self.assertEqual(self.changes, 3)
        self.see()
        self.assertEqual(self.changes, 3)  # already dirty: no further wakeups
        self.assertLessEqual(self.t.tick(), T.SEEN_FLUSH_S)

    def test_departure_fires_at_returned_delay(self):
        self.watch(timeout=300)
        self.see()
        self.clock.advance(3)
        self.see()
        self.clock.advance(self.t.tick())
        self.t.tick()
        self.assertEqual([k for _, k, _ in self.kinds()], ["ARRIVED", "LEFT"])

    def test_enroll_schedules_auto_off_and_wakes_on_timeout(self):
        self.t.set_enroll(True)
        self.assertEqual(self.changes, 1)
        self.assertAlmostEqual(self.t.tick(), T.ENROLL_TTL_S)
        self.clock.advance(T.ENROLL_TTL_S)
        self.t.tick()
        self.assertEqual(self.changes, 2)
        self.assertFalse(self.t.wants_scan())

    def test_unwatched_advert_is_not_decoded(self):
        self.watch()
        orig = T.bthome.decode
        calls = []
        T.bthome.decode = lambda *a: calls.append(a) or orig(*a)
        try:
            self.see(mac=MAC2)
            self.assertEqual(calls, [])
            self.t.set_enroll(True)
            self.see(mac=MAC2)
            self.assertEqual(len(calls), 1)  # enroll mode looks at every button
        finally:
            T.bthome.decode = orig

    @unittest.skipUnless(HAS_AESCCM and crypto.SUPPORTED, "no AES-CCM")
    def test_copies_of_accepted_advert_skip_decryption(self):
        self.watch({MAC: KEY})
        self.see(data=encrypted(MAC, KEY, 5))
        orig = crypto.decrypt
        calls = []
        crypto.decrypt = lambda *a: calls.append(a) or orig(*a)
        try:
            self.see(data=encrypted(MAC, KEY, 5))  # same advert, other channel
            self.see(data=encrypted(MAC, KEY, 4))  # replay
            self.assertEqual(calls, [])
            self.see(data=encrypted(MAC, KEY, 6))
            self.assertEqual(len(calls), 1)
        finally:
            crypto.decrypt = orig

    def test_events_long_poll_returns_on_new_event(self):
        import threading
        self.watch()
        out = []
        th = threading.Thread(target=lambda: out.append(self.t.events(wait=5)))
        th.start()
        self.see()
        self.clock.advance(3)
        self.see()
        th.join(2)
        self.assertFalse(th.is_alive())
        self.assertEqual(out[0][0][0]["kind"], "ARRIVED")

    def test_events_wait_times_out_empty(self):
        self.assertEqual(self.t.events(wait=0.05), ([], 0))


class DiskFallbackTest(unittest.TestCase):
    """RAM always; the microSD only while the backend is unreachable."""

    def setUp(self):
        self.dir = tempfile.TemporaryDirectory()
        self.ram = os.path.join(self.dir.name, "run", "state.json")
        self.disk = os.path.join(self.dir.name, "disk", "state.json")
        self.clock = FakeClock()
        self.t = self.make()
        self.t.set_watch(True, "v1", 300, -85, {MAC: None})

    def tearDown(self):
        self.dir.cleanup()

    def make(self):
        return Tracker(self.ram, wall=self.clock.wall, mono=self.clock.mono, disk_path=self.disk)

    def arrive(self):
        self.t.on_advert(MAC, -60, plain())
        self.clock.advance(3)
        self.t.on_advert(MAC, -60, plain())

    def heartbeat_for(self, seconds, every=60):
        """Present all along, the SPA syncing (acking) every `every` s."""
        for _ in range(int(seconds / every)):
            self.clock.advance(every)
            self.t.on_advert(MAC, -60, plain())
            _, last = self.t.events()
            self.t.ack(last)
            self.t.tick()

    def test_online_never_touches_the_disk(self):
        self.arrive()
        self.heartbeat_for(8 * 3600)
        self.assertTrue(os.path.exists(self.ram))
        self.assertFalse(os.path.exists(os.path.dirname(self.disk)))

    def test_backend_unreachable_writes_disk_then_ack_removes_it(self):
        self.arrive()  # ARRIVED never acked: the SPA can't reach the backend
        self.clock.advance(T.OFFLINE_AFTER_S - 5)  # the arrival itself took 3 s
        self.t.tick()
        self.assertFalse(os.path.exists(self.disk))
        self.clock.advance(3)
        self.t.tick()
        self.assertTrue(os.path.exists(self.disk))
        self.assertEqual(stat.S_IMODE(os.stat(self.disk).st_mode), 0o600)
        _, last = self.t.events()
        self.t.ack(last)
        self.assertFalse(os.path.exists(self.disk))

    def test_offline_last_seen_flushed_only_every_offline_flush(self):
        self.arrive()
        self.clock.advance(T.OFFLINE_AFTER_S + 1)
        self.t.tick()
        first = os.stat(self.disk).st_mtime_ns
        writes = []
        orig = self.t._save_disk
        self.t._save_disk = lambda *a: writes.append(1) or orig(*a)
        for _ in range(int(T.OFFLINE_FLUSH_S / 10) - 1):
            self.clock.advance(10)
            self.t.on_advert(MAC, -60, plain())
            self.t.tick()
        self.assertEqual(writes, [])
        self.clock.advance(20)
        self.t.on_advert(MAC, -60, plain())
        self.t.tick()
        self.assertEqual(len(writes), 1)
        self.assertGreaterEqual(os.stat(self.disk).st_mtime_ns, first)

    def test_reboot_restores_unsynced_disk_state(self):
        self.arrive()
        self.clock.advance(T.OFFLINE_AFTER_S + 1)
        self.t.tick()
        os.remove(self.ram)  # reboot: tmpfs gone
        t2 = self.make()
        self.assertEqual([e["kind"] for e in t2.events()[0]], ["ARRIVED"])
        self.assertTrue(t2.status()["buttons"][0]["present"])

    def test_agent_restart_keeps_ram_state(self):
        self.arrive()
        t2 = self.make()
        self.assertTrue(t2.status()["buttons"][0]["present"])

    def test_reboot_seeds_presence_from_backend(self):
        os.remove(self.ram)
        t2 = self.make()
        gone = self.clock.w - 3600     # left during the reboot
        here = self.clock.w - 30       # still around
        t2.set_watch(True, "v1", 300, -85, {MAC: None, MAC2: None}, seeds={MAC: gone, MAC2: here})
        t2.tick()
        evs, _ = t2.events()
        self.assertEqual([(e["mac"], e["kind"], e["at"]) for e in evs], [(MAC, "LEFT", iso(gone))])
        self.assertTrue(next(b for b in t2.status()["buttons"] if b["mac"] == MAC2)["present"])

    def test_seed_never_overrides_own_sightings(self):
        self.t.on_advert(MAC, -95, plain())  # seen (too weak to arrive), so known
        self.t.set_watch(True, "v1", 300, -85, {MAC: None}, seeds={MAC: self.clock.w - 3600})
        self.t.tick()
        self.assertEqual(self.t.events()[0], [])
        self.assertFalse(self.t.status()["buttons"][0]["present"])

    def test_same_watch_list_is_not_rewritten(self):
        saves = []
        orig = self.t._save
        self.t._save = lambda: saves.append(1) or orig()
        self.t.set_watch(True, "v1", 300, -85, {MAC: None})
        self.assertEqual(saves, [])
        self.t.set_watch(True, "v2", 300, -85, {MAC: None})
        self.assertEqual(saves, [1])

    def test_undelivered_event_goes_to_disk_despite_heartbeats(self):
        self.arrive()  # ARRIVED; the punch upload keeps failing
        for _ in range(4):
            self.clock.advance(60)
            self.t.ack(0)  # heartbeat: backend reachable, nothing delivered
            self.t.tick()
        self.assertEqual(len(self.t.events()[0]), 1)  # ack(0) dropped nothing
        self.assertTrue(os.path.exists(self.disk))
        self.t.ack(0)
        self.assertTrue(os.path.exists(self.disk))  # still undelivered: keep it
        _, last = self.t.events()
        self.t.ack(last)
        self.assertFalse(os.path.exists(self.disk))

    def test_next_due_includes_delivery_deadline(self):
        self.t.ack(0)
        self.arrive()
        self.assertLessEqual(self.t.tick(), T.OFFLINE_AFTER_S)

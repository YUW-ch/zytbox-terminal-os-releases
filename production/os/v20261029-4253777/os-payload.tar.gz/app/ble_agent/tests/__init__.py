import logging

# Keep test output readable: the agent logs every ARRIVED/LEFT at INFO.
logging.disable(logging.WARNING)

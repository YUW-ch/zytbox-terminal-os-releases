"""Route shapes against the cross-repo contract (Flask test client, fake clock)."""

import os
import tempfile
import unittest

os.environ["TT_BLE_AGENT_TEST"] = "1"  # don't boot the scanner/ticker on import

try:
    import agent  # noqa: E402
except ImportError:  # no Flask on this machine (it's always there on the device)
    agent = None
from tests.helpers import FakeClock, plain  # noqa: E402
from tracker import Tracker  # noqa: E402

MAC = "7CC6B6A1B2C3"
HDR = {"Content-Type": "application/json"}


class FakeScanner:
    adapter = True
    scanning = False


@unittest.skipIf(agent is None, "Flask not installed")
class AgentRoutesTest(unittest.TestCase):
    def setUp(self):
        self.dir = tempfile.TemporaryDirectory()
        self.clock = FakeClock()
        self.tracker = Tracker(os.path.join(self.dir.name, "state.json"),
                               wall=self.clock.wall, mono=self.clock.mono)
        self.client = agent.create_app(self.tracker, FakeScanner()).test_client()

    def tearDown(self):
        self.dir.cleanup()

    def put_watch(self, **over):
        body = {"enabled": True, "version": "abc", "absenceTimeoutS": 300, "arriveRssi": -85,
                "buttons": [{"mac": "7c:c6:b6:a1:b2:c3", "bindKey": None}]}
        body.update(over)
        return self.client.put("/watch", json=body)

    def test_status_shape(self):
        r = self.client.get("/status")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(set(r.json), {"adapter", "scanning", "enabled", "encryptionSupported",
                                       "watchVersion", "enroll", "buttons"})
        self.assertEqual(r.json["buttons"], [])

    def test_watch_normalises_and_reports(self):
        r = self.put_watch()
        self.assertEqual(r.json, {"ok": True, "watchVersion": "abc"})
        st = self.client.get("/status").json
        self.assertTrue(st["enabled"])
        self.assertEqual(st["buttons"], [{"mac": MAC, "present": False, "lastSeenAt": None, "rssi": None,
                                          "battery": None, "beaconMode": None, "decryptOk": None}])

    def test_watch_validation(self):
        self.assertEqual(self.put_watch(buttons=[{"mac": "nope", "bindKey": None}]).json, {"error": "invalid_mac"})
        self.assertEqual(self.put_watch(buttons=[{"mac": MAC, "bindKey": "12"}]).status_code, 400)
        self.assertEqual(self.put_watch(arriveRssi="x").status_code, 400)
        self.assertEqual(self.client.put("/watch", data="[]", headers=HDR).status_code, 400)
        self.assertEqual(self.put_watch(buttons=[{"mac": MAC, "bindKey": "AB" * 16}]).status_code, 200)

    def test_watch_seeds_presence_from_backend(self):
        from tracker import iso
        gone = iso(self.clock.w - 3600)
        r = self.put_watch(buttons=[{"mac": MAC, "bindKey": None, "present": True, "lastSeenAt": gone}])
        self.assertEqual(r.status_code, 200)
        self.tracker.tick()
        evs = self.client.get("/events?after=0").json["events"]
        self.assertEqual([(e["kind"], e["at"]) for e in evs], [("LEFT", gone)])
        self.assertEqual(self.put_watch(buttons=[{"mac": MAC, "bindKey": None, "present": "yes"}]).status_code, 400)

    def test_events_and_ack(self):
        self.put_watch()
        self.tracker.on_advert(MAC, -60, plain())
        self.clock.advance(4)
        self.tracker.on_advert(MAC, -60, plain(battery=80))
        r = self.client.get("/events?after=0")
        self.assertEqual(r.json["lastSeq"], 1)
        ev = r.json["events"][0]
        self.assertEqual((ev["mac"], ev["kind"], ev["seq"], ev["battery"]), (MAC, "ARRIVED", 1, 80))
        self.assertTrue(ev["at"].endswith("Z"))
        self.assertEqual(self.client.get("/events?after=1").json["events"], [])
        self.assertEqual(self.client.get("/events?after=x").status_code, 400)
        self.assertEqual(self.client.post("/ack", json={"upTo": 1}).json, {"ok": True})
        self.assertEqual(self.client.get("/events").json, {"events": [], "lastSeq": 1})
        self.assertEqual(self.client.post("/ack", json={"upTo": "1"}).status_code, 400)

    def test_enroll(self):
        self.assertEqual(self.client.post("/enroll", json={"active": True}).json, {"active": True})
        self.tracker.on_advert(MAC, -50, plain(button=1, battery=99))
        r = self.client.get("/enroll").json
        self.assertTrue(r["active"])
        self.assertEqual([(c["mac"], c["rssi"], c["battery"]) for c in r["candidates"]], [(MAC, -50, 99)])
        self.assertEqual(self.client.post("/enroll", json={"active": False}).json, {"active": False})
        self.assertEqual(self.client.post("/enroll", json={}).status_code, 400)

    def test_reset(self):
        self.put_watch()
        self.assertEqual(self.client.post("/reset").json, {"ok": True})
        st = self.client.get("/status").json
        self.assertEqual((st["enabled"], st["watchVersion"], st["buttons"]), (False, None, []))

    def test_unknown_route_is_json(self):
        r = self.client.get("/nope")
        self.assertEqual((r.status_code, r.json), (404, {"error": "not_found"}))


if __name__ == "__main__":
    unittest.main()

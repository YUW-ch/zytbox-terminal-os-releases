import struct
import unittest

import hci
from tests.helpers import plain

MAC = "7CC6B6A1B2C3"
ADDR_LE = bytes(reversed(bytes.fromhex(MAC)))


def ad_with_bthome(svc):
    flags = bytes([0x02, 0x01, 0x06])
    return flags + bytes([len(svc) + 1, 0x16]) + svc


def legacy_event(ad, rssi=-60):
    report = bytes([0x00, 0x00]) + ADDR_LE + bytes([len(ad)]) + ad + struct.pack("b", rssi)
    params = bytes([hci.LE_ADV_REPORT, 1]) + report
    return bytes([hci.HCI_EVENT_PKT, hci.EVT_LE_META, len(params)]) + params


def extended_event(ad, rssi=-70):
    report = (struct.pack("<H", 0x0010) + bytes([0x00]) + ADDR_LE + bytes([1, 0, 0xFF, 0x7F])
              + struct.pack("b", rssi) + struct.pack("<H", 0) + bytes([0]) + bytes(6)
              + bytes([len(ad)]) + ad)
    params = bytes([hci.LE_EXT_ADV_REPORT, 1]) + report
    return bytes([hci.HCI_EVENT_PKT, hci.EVT_LE_META, len(params)]) + params


class HciParseTest(unittest.TestCase):
    def test_legacy_report(self):
        svc = plain(battery=77, button=1)
        self.assertEqual(hci.bthome_from_event(legacy_event(ad_with_bthome(svc), -61)), [(MAC, -61, svc)])

    def test_extended_report(self):
        svc = plain(battery=12)
        self.assertEqual(hci.bthome_from_event(extended_event(ad_with_bthome(svc), -88)), [(MAC, -88, svc)])

    def test_non_bthome_ignored(self):
        ad = bytes([0x02, 0x01, 0x06, 0x05, 0x16, 0x95, 0xFE, 0x01, 0x02])
        self.assertEqual(hci.bthome_from_event(legacy_event(ad)), [])

    def test_truncated_event(self):
        pkt = legacy_event(ad_with_bthome(plain()))
        self.assertEqual(hci.bthome_from_event(pkt[:12]), [])

    def test_other_event_ignored(self):
        self.assertEqual(hci.bthome_from_event(bytes([0x04, 0x0E, 0x04, 0x01, 0x0C, 0x20, 0x00])), [])


if __name__ == "__main__":
    unittest.main()


class DispatchTest(unittest.TestCase):
    def setUp(self):
        self.seen = []
        self.s = hci.Scanner(lambda *a: self.seen.append(a), lambda: False)

    def test_bthome_report_is_handed_on(self):
        self.assertTrue(self.s._dispatch(legacy_event(ad_with_bthome(plain()))))
        self.assertEqual(len(self.seen), 1)

    def test_other_adverts_skip_parsing_but_count_for_watchdog(self):
        orig = hci.bthome_from_event
        hci.bthome_from_event = lambda pkt: self.fail("parsed a non-BTHome advert")
        try:
            self.assertTrue(self.s._dispatch(legacy_event(bytes([0x02, 0x01, 0x06]))))
        finally:
            hci.bthome_from_event = orig
        self.assertEqual(self.seen, [])

    def test_notify_is_coalesced_and_drained(self):
        for _ in range(3):
            self.s.notify()
        self.s._drain_wake()
        import select
        self.assertEqual(select.select([self.s._wake_r], [], [], 0)[0], [])

"""Shared test helpers: a controllable clock and BTHome advert builders."""

import struct

try:
    from cryptography.hazmat.primitives.ciphers.aead import AESCCM
except ImportError:  # the encrypted tests skip without it
    AESCCM = None

HAS_AESCCM = AESCCM is not None


class FakeClock:
    """Wall + monotonic clocks advanced together (or independently, for jumps)."""

    def __init__(self, wall=1_800_000_000.0, mono=1000.0):
        self.w = wall
        self.m = mono

    def wall(self):
        return self.w

    def mono(self):
        return self.m

    def advance(self, s):
        self.w += s
        self.m += s


def plain(packet_id=1, battery=90, button=0):
    """Plaintext BTHome v2 service data (trigger-based, like the Shelly BLU)."""
    return bytes([0xD2, 0xFC, 0x44, 0x00, packet_id, 0x01, battery, 0x3A, button])


def encrypted(mac, key_hex, counter, packet_id=1, battery=90, button=0):
    """Encrypted BTHome v2 service data for `mac` (12 hex) under `key_hex`."""
    info = 0x45
    objects = bytes([0x00, packet_id, 0x01, battery, 0x3A, button])
    ctr = struct.pack("<I", counter)
    nonce = bytes.fromhex(mac) + b"\xd2\xfc" + bytes([info]) + ctr
    sealed = AESCCM(bytes.fromhex(key_hex), tag_length=4).encrypt(nonce, objects, None)
    return bytes([0xD2, 0xFC, info]) + sealed[:-4] + ctr + sealed[-4:]

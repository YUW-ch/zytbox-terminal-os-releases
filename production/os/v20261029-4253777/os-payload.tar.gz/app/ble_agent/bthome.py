"""
BTHome v2 service-data parsing and decryption (https://bthome.io/format/).

A BTHome advert carries an AD structure of type 0x16 (service data, 16-bit
UUID) whose payload is:

    d2 fc            UUID 0xFCD2, little-endian
    <device info>    bit 0 = encrypted, bit 2 = trigger-based, bits 5-7 = version (2)
    <objects...>     object id + fixed-size little-endian value, repeated

Encrypted (bit 0 set), the objects are AES-128-CCM ciphertext followed by a
4-byte little-endian counter and a 4-byte MIC. The nonce is

    MAC (6 bytes, as printed) + d2 fc + device info byte + counter (4 bytes LE)

Shelly BLU buttons send packet id (0x00), battery (0x01) and button event (0x3A).
Everything else is parsed only far enough to step over it; an unknown object id
ends parsing (its size is unknown), keeping what came before.
"""

import crypto

UUID_BYTES = b"\xd2\xfc"

OBJ_PACKET_ID = 0x00
OBJ_BATTERY = 0x01
OBJ_BUTTON = 0x3A

# object id -> (size in bytes, signed). From the BTHome v2 format table.
_SIZES = {
    0x00: (1, False), 0x01: (1, False), 0x02: (2, True), 0x03: (2, False),
    0x04: (3, False), 0x05: (3, False), 0x06: (2, False), 0x07: (2, False),
    0x08: (2, True), 0x09: (1, False), 0x0A: (3, False), 0x0B: (3, False),
    0x0C: (2, False), 0x0D: (2, False), 0x0E: (2, False), 0x12: (2, False),
    0x13: (2, False), 0x14: (2, False), 0x2E: (1, False), 0x2F: (1, False),
    0x3A: (1, False), 0x3C: (2, False), 0x3D: (2, False), 0x3E: (4, False),
    0x3F: (2, True), 0x40: (2, False), 0x41: (2, False), 0x42: (3, False),
    0x43: (2, False), 0x44: (2, False), 0x45: (2, True), 0x46: (1, False),
    0x47: (2, False), 0x48: (2, False), 0x49: (2, False), 0x4A: (2, False),
    0x4B: (3, False), 0x4C: (4, False), 0x4D: (4, False), 0x4E: (4, False),
    0x4F: (4, False), 0x50: (4, False), 0x51: (2, False), 0x52: (2, False),
    0x55: (4, False), 0x56: (2, False), 0x57: (1, True), 0x58: (1, True),
    0x59: (1, True), 0x5A: (2, True), 0x5B: (4, True), 0x5C: (4, True),
    0x5D: (2, True), 0x5E: (2, False), 0x5F: (2, False), 0x60: (1, False),
    0x61: (2, False), 0xF0: (2, False), 0xF1: (4, False), 0xF2: (3, False),
}
# 0x0F-0x2D are binary sensors: one byte each.
for _oid in range(0x0F, 0x2E):
    _SIZES.setdefault(_oid, (1, False))
# Variable length (first byte = length): text, raw.
_VARIABLE = (0x53, 0x54)


class Advert:
    """One decoded BTHome advert. `ok` is False when it couldn't be read at all
    (encrypted without a key, or the MIC didn't verify)."""

    def __init__(self, encrypted, ok, counter=None, objects=None):
        self.encrypted = encrypted
        self.ok = ok
        self.counter = counter
        self.objects = objects or []  # [(object id, int value or bytes)]

    def first(self, oid):
        for k, v in self.objects:
            if k == oid:
                return v
        return None

    @property
    def packet_id(self):
        return self.first(OBJ_PACKET_ID)

    @property
    def battery(self):
        v = self.first(OBJ_BATTERY)
        return v if isinstance(v, int) and 0 <= v <= 100 else None

    @property
    def button(self):
        """First non-zero button event (1 press, 2 double, 3 triple, 4 long, ...), else 0/None."""
        vals = [v for k, v in self.objects if k == OBJ_BUTTON]
        for v in vals:
            if v:
                return v
        return vals[0] if vals else None


def parse_objects(data):
    """Decode a run of BTHome objects; stops at the first unknown/truncated one."""
    out, i = [], 0
    while i < len(data):
        oid = data[i]
        i += 1
        if oid in _VARIABLE:
            if i >= len(data) or i + 1 + data[i] > len(data):
                break
            n = data[i]
            out.append((oid, bytes(data[i + 1:i + 1 + n])))
            i += 1 + n
            continue
        spec = _SIZES.get(oid)
        if spec is None or i + spec[0] > len(data):
            break
        size, signed = spec
        out.append((oid, int.from_bytes(data[i:i + size], "little", signed=signed)))
        i += size
    return out


def is_bthome(service_data):
    return len(service_data) >= 3 and service_data[:2] == UUID_BYTES


def encrypted_counter(service_data):
    """The counter of an encrypted BTHome v2 advert, read WITHOUT decrypting (so
    copies of an already accepted advert can be dropped before the AES), else None.
    Unauthenticated: only ever use it to skip work, never to accept an advert."""
    if not is_bthome(service_data) or len(service_data) < 3 + 9:
        return None
    info = service_data[2]
    if (info >> 5) & 0x07 != 2 or not info & 0x01:
        return None
    return int.from_bytes(service_data[-8:-4], "little")


def decode(mac_be, service_data, key=None):
    """Decode the payload of a 0x16 AD structure (starting with the d2 fc UUID).

    mac_be: the 6 MAC bytes in printed (big-endian) order. key: 16-byte bind key
    or None. Returns an Advert, or None if this isn't BTHome v2.
    """
    if not is_bthome(service_data):
        return None
    info = service_data[2]
    if (info >> 5) & 0x07 != 2:
        return None  # BTHome v1 or garbage
    body = service_data[3:]
    if not info & 0x01:
        return Advert(encrypted=False, ok=True, objects=parse_objects(body))
    if len(body) < 8 + 1:
        return Advert(encrypted=True, ok=False)
    ciphertext, counter_b, mic = body[:-8], body[-8:-4], body[-4:]
    counter = int.from_bytes(counter_b, "little")
    if key is None:
        return Advert(encrypted=True, ok=False, counter=counter)
    nonce = bytes(mac_be) + UUID_BYTES + bytes([info]) + bytes(counter_b)
    plain = crypto.decrypt(key, nonce, ciphertext, mic)
    if plain is None:
        return Advert(encrypted=True, ok=False, counter=counter)
    return Advert(encrypted=True, ok=True, counter=counter, objects=parse_objects(plain))

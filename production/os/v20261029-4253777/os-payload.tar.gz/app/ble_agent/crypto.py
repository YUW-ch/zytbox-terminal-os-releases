"""
AES-128-CCM decryption for encrypted BTHome adverts (4-byte MIC, 13-byte nonce).

Two backends, picked once at import:
  1. `cryptography` (apt: python3-cryptography, baked into images that ship BLE).
  2. A ctypes shim over the system libcrypto (OpenSSL 3 / 1.1). Terminals that got
     the BLE agent from an OS OTA update can't install apt packages, but every
     Raspberry Pi OS image already carries libssl3, so the shim covers them.

If neither works, SUPPORTED is False: the agent reports encryptionSupported:false
and keyed buttons are never accepted (fail-closed, never "accept unverified").

Only versioned Linux sonames are tried for the shim. On macOS an unversioned
libcrypto.dylib aborts the whole process on load; set TT_LIBCRYPTO to a real
library path (e.g. Homebrew's libcrypto.3.dylib) to exercise the shim there.
"""

import ctypes
import ctypes.util
import logging
import os

log = logging.getLogger("tt-ble")

MIC_LEN = 4

# OpenSSL EVP_CIPHER_CTX_ctrl codes (stable across 1.1 and 3.x).
_EVP_CTRL_AEAD_SET_IVLEN = 0x9
_EVP_CTRL_AEAD_SET_TAG = 0x11


class _CryptographyBackend:
    name = "cryptography"

    def __init__(self):
        from cryptography.exceptions import InvalidTag
        from cryptography.hazmat.primitives.ciphers.aead import AESCCM
        self._aesccm = AESCCM
        self._invalid = InvalidTag

    def decrypt(self, key, nonce, ciphertext, mic):
        try:
            return self._aesccm(key, tag_length=len(mic)).decrypt(nonce, ciphertext + mic, None)
        except (self._invalid, ValueError):
            return None


class _LibcryptoBackend:
    name = "libcrypto"

    def __init__(self, lib):
        c = ctypes
        lib.EVP_CIPHER_CTX_new.restype = c.c_void_p
        lib.EVP_CIPHER_CTX_new.argtypes = []
        lib.EVP_CIPHER_CTX_free.restype = None
        lib.EVP_CIPHER_CTX_free.argtypes = [c.c_void_p]
        lib.EVP_aes_128_ccm.restype = c.c_void_p
        lib.EVP_aes_128_ccm.argtypes = []
        lib.EVP_DecryptInit_ex.restype = c.c_int
        lib.EVP_DecryptInit_ex.argtypes = [c.c_void_p, c.c_void_p, c.c_void_p, c.c_char_p, c.c_char_p]
        lib.EVP_DecryptUpdate.restype = c.c_int
        lib.EVP_DecryptUpdate.argtypes = [c.c_void_p, c.c_void_p, c.POINTER(c.c_int), c.c_char_p, c.c_int]
        lib.EVP_CIPHER_CTX_ctrl.restype = c.c_int
        lib.EVP_CIPHER_CTX_ctrl.argtypes = [c.c_void_p, c.c_int, c.c_int, c.c_void_p]
        self._lib = lib

    def decrypt(self, key, nonce, ciphertext, mic):
        c, lib = ctypes, self._lib
        ctx = lib.EVP_CIPHER_CTX_new()
        if not ctx:
            return None
        try:
            if lib.EVP_DecryptInit_ex(ctx, lib.EVP_aes_128_ccm(), None, None, None) != 1:
                return None
            if lib.EVP_CIPHER_CTX_ctrl(ctx, _EVP_CTRL_AEAD_SET_IVLEN, len(nonce), None) != 1:
                return None
            tag = c.create_string_buffer(bytes(mic), len(mic))
            if lib.EVP_CIPHER_CTX_ctrl(ctx, _EVP_CTRL_AEAD_SET_TAG, len(mic), tag) != 1:
                return None
            if lib.EVP_DecryptInit_ex(ctx, None, None, bytes(key), bytes(nonce)) != 1:
                return None
            outl = c.c_int(0)
            # CCM needs the total length up front (it's part of the first block).
            if lib.EVP_DecryptUpdate(ctx, None, c.byref(outl), None, len(ciphertext)) != 1:
                return None
            out = c.create_string_buffer(max(1, len(ciphertext)))
            # In CCM mode the MIC is verified inside this single update call.
            if lib.EVP_DecryptUpdate(ctx, out, c.byref(outl), bytes(ciphertext), len(ciphertext)) <= 0:
                return None
            return out.raw[:outl.value]
        finally:
            lib.EVP_CIPHER_CTX_free(ctx)


def _load_libcrypto():
    candidates = []
    if os.environ.get("TT_LIBCRYPTO"):
        candidates.append(os.environ["TT_LIBCRYPTO"])
    candidates += ["libcrypto.so.3", "libcrypto.so.1.1"]
    found = ctypes.util.find_library("crypto") if os.name == "posix" and os.uname().sysname == "Linux" else None
    if found:
        candidates.append(found)
    for name in candidates:
        try:
            return _LibcryptoBackend(ctypes.CDLL(name))
        except (OSError, AttributeError):
            continue
    return None


def _pick():
    try:
        return _CryptographyBackend()
    except ImportError:
        pass
    shim = _load_libcrypto()
    if shim is not None:
        return shim
    log.warning("no AES-CCM backend (python3-cryptography / libcrypto) - encrypted buttons unsupported")
    return None


_backend = _pick()
SUPPORTED = _backend is not None
BACKEND = _backend.name if _backend else None


def decrypt(key, nonce, ciphertext, mic):
    """Plaintext bytes, or None when the MIC doesn't verify (or no backend)."""
    if _backend is None or len(key) != 16 or len(nonce) != 13 or len(mic) != MIC_LEN:
        return None
    return _backend.decrypt(bytes(key), bytes(nonce), bytes(ciphertext), bytes(mic))

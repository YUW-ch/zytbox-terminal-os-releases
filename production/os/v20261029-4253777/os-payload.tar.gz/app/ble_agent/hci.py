"""
Passive BLE scanner on a raw HCI socket (Linux only, Python stdlib).

bluetoothd stays masked on the kiosk, so nothing else drives the controller.
We open a raw HCI socket on hci0, bring the device up (HCIDEVUP), and run a
PASSIVE LE scan (we never transmit scan requests, so the buttons' batteries are
untouched) at 100 % duty with duplicate filtering OFF — a beacon-mode button
re-sends the same payload every ~10 s and every copy is a sighting.

Reports arrive as HCI LE Meta events:
  0x02  LE Advertising Report           (legacy scan commands — what we use)
  0x0D  LE Extended Advertising Report  (only if something enabled extended
                                         scanning; parsed too because it's cheap)
Only adverts carrying BTHome service data (UUID 0xFCD2) are handed on.

Energy: the scanner only runs while something is watched (or enroll mode is on).
Otherwise the socket is closed, hci0 is powered down and the thread blocks with
no timeout until the tracker signals a change (notify()). While scanning, the
loop sleeps in select() and wakes only for a packet, a notify() or the stall
watchdog; the kernel only passes it LE Meta + command events, and packets that
can't hold BTHome data are dropped by a C-level byte search before any parsing.

Resilience: any socket/command error closes everything and reopens with backoff
(5 s doubling to 60 s). A stall watchdog re-arms the scan when no advertising
report at all arrived for STALL_S while scanning (controller reset, kernel
re-init, a firmware hiccup) and reopens the socket if re-arming fails.

AF_BLUETOOTH only exists on Linux, so the socket module's Bluetooth constants are
looked up lazily inside open() — the parsers below import and test fine on macOS.
"""

import errno
import fcntl
import logging
import os
import select
import shutil
import socket
import struct
import subprocess
import threading
import time

log = logging.getLogger("tt-ble")

HCI_COMMAND_PKT = 0x01
HCI_EVENT_PKT = 0x04
EVT_CMD_COMPLETE = 0x0E
EVT_CMD_STATUS = 0x0F
EVT_LE_META = 0x3E
LE_ADV_REPORT = 0x02
LE_EXT_ADV_REPORT = 0x0D
BTHOME_UUID_LE = b"\xd2\xfc"

OGF_LE = 0x08
OCF_LE_SET_SCAN_PARAMETERS = 0x000B
OCF_LE_SET_SCAN_ENABLE = 0x000C

# _IOW('H', 201, int) / _IOW('H', 202, int) from <bluetooth/hci.h>.
HCIDEVUP = 0x400448C9
HCIDEVDOWN = 0x400448CA
ERFKILL = 132
SOL_HCI = 0
HCI_FILTER = 2
BTPROTO_HCI = 1

# Scan interval == window -> 100 % duty (units of 0.625 ms; 0x0060 = 60 ms).
SCAN_INTERVAL = 0x0060
SCAN_WINDOW = 0x0060
CMD_TIMEOUT_S = 2.0
# No advertising report at all for this long while scanning -> re-arm the scan.
# Any office has other BLE noise (phones, laptops), so silence this long means
# the controller stopped reporting, not that the room is empty.
STALL_S = 120
BACKOFF_MIN_S = 5
BACKOFF_MAX_S = 60
# Kernel-side event filter: only Command Complete/Status (our own commands) and
# LE Meta (advertising reports) ever wake the process.
EVENT_MASK = (1 << EVT_CMD_COMPLETE) | (1 << EVT_CMD_STATUS) | (1 << EVT_LE_META)


# --- pure parsers (unit-tested) ----------------------------------------------

def mac_str(addr_le):
    """HCI carries addresses little-endian; return 12 uppercase hex, printed order."""
    return bytes(reversed(addr_le)).hex().upper()


def service_data_16(ad):
    """All (uuid16, payload_incl_uuid) pairs from 0x16 AD structures."""
    out, i = [], 0
    while i < len(ad):
        n = ad[i]
        if n == 0 or i + 1 + n > len(ad):
            break
        t = ad[i + 1]
        if t == 0x16 and n >= 3:
            payload = bytes(ad[i + 2:i + 1 + n])
            out.append((int.from_bytes(payload[:2], "little"), payload))
        i += 1 + n
    return out


def parse_le_meta(params):
    """Advertising reports in one LE Meta event's parameters.

    Returns [(mac, rssi, ad_bytes)]. Reports are parsed sequentially, the way
    controllers (and BlueZ) actually lay them out.
    """
    if not params:
        return []
    sub = params[0]
    out = []
    try:
        if sub == LE_ADV_REPORT:
            n, i = params[1], 2
            for _ in range(n):
                addr = params[i + 2:i + 8]
                dlen = params[i + 8]
                data = params[i + 9:i + 9 + dlen]
                rssi = struct.unpack_from("b", params, i + 9 + dlen)[0]
                if len(data) != dlen or len(addr) != 6:
                    break
                out.append((mac_str(addr), rssi, bytes(data)))
                i += 10 + dlen
        elif sub == LE_EXT_ADV_REPORT:
            n, i = params[1], 2
            for _ in range(n):
                addr = params[i + 3:i + 9]
                rssi = struct.unpack_from("b", params, i + 13)[0]
                dlen = params[i + 23]
                data = params[i + 24:i + 24 + dlen]
                if len(data) != dlen or len(addr) != 6:
                    break
                if rssi != 127:  # 127 = RSSI not available
                    out.append((mac_str(addr), rssi, bytes(data)))
                i += 24 + dlen
    except (IndexError, struct.error):
        pass  # truncated event: keep what parsed cleanly
    return out


def bthome_from_event(pkt):
    """(mac, rssi, service_data) for every BTHome advert in a raw HCI event packet."""
    if len(pkt) < 3 or pkt[0] != HCI_EVENT_PKT or pkt[1] != EVT_LE_META:
        return []
    out = []
    for mac, rssi, ad in parse_le_meta(pkt[3:3 + pkt[2]]):
        for uuid, payload in service_data_16(ad):
            if uuid == 0xFCD2:
                out.append((mac, rssi, payload))
    return out


# --- scanner -----------------------------------------------------------------

class HciError(Exception):
    pass


def adapter_present(dev_id=0):
    return os.path.exists(f"/sys/class/bluetooth/hci{dev_id}")


def unblock_radio():
    # Older images ran `rfkill block bluetooth`; systemd-rfkill restores that on
    # every boot, and an OS OTA can't change /etc — so unblock at runtime.
    if shutil.which("rfkill"):
        try:
            subprocess.run(["rfkill", "unblock", "bluetooth"], capture_output=True, timeout=10)
        except (OSError, subprocess.TimeoutExpired):
            pass


class Scanner:
    """Runs forever on its own thread. on_advert(mac, rssi, service_data) is
    called for every BTHome advert; want_scan() says whether to scan at all
    (nothing watched and no enroll -> the radio stays idle)."""

    def __init__(self, on_advert, want_scan, dev_id=0):
        self.on_advert = on_advert
        self.want_scan = want_scan
        self.dev_id = dev_id
        self.scanning = False
        self.last_error = None
        self._sock = None
        self._unblocked = False
        # Self-pipe: notify() makes the blocked select()/idle wait return.
        self._wake_r, self._wake_w = socket.socketpair()
        self._wake_r.setblocking(False)
        self._wake_w.setblocking(False)

    @property
    def adapter(self):
        return self._sock is not None or adapter_present(self.dev_id)

    def notify(self):
        """The watch list or enroll mode changed: re-check want_scan() now."""
        try:
            self._wake_w.send(b"\0")
        except (BlockingIOError, OSError):
            pass  # already pending

    def _drain_wake(self):
        try:
            while self._wake_r.recv(64):
                pass
        except (BlockingIOError, OSError):
            pass

    # -- socket + commands --

    def _open(self):
        af = getattr(socket, "AF_BLUETOOTH", None)
        if af is None:
            raise HciError("no AF_BLUETOOTH on this platform")
        if not adapter_present(self.dev_id):
            raise HciError(f"hci{self.dev_id} not present")
        if not self._unblocked:  # once per process (or after an ERFKILL), not per retry
            unblock_radio()
            self._unblocked = True
        s = socket.socket(af, socket.SOCK_RAW, getattr(socket, "BTPROTO_HCI", BTPROTO_HCI))
        try:
            try:
                fcntl.ioctl(s.fileno(), HCIDEVUP, self.dev_id)
            except OSError as e:
                if e.errno == ERFKILL:
                    self._unblocked = False
                if e.errno != errno.EALREADY:
                    raise
            s.bind((self.dev_id,))
            # Event packets only; just the event codes in EVENT_MASK; any opcode.
            flt = struct.pack("<IIIH2x", 1 << HCI_EVENT_PKT, EVENT_MASK & 0xFFFFFFFF, EVENT_MASK >> 32, 0)
            s.setsockopt(getattr(socket, "SOL_HCI", SOL_HCI), getattr(socket, "HCI_FILTER", HCI_FILTER), flt)
            s.settimeout(1.0)
        except Exception:
            s.close()
            raise
        self._sock = s

    def _close(self):
        if self._sock is not None:
            try:
                self._send_scan_enable(False, wait=False)
            except Exception:
                pass
            try:
                # Power the controller down while idle; _open() brings it back.
                fcntl.ioctl(self._sock.fileno(), HCIDEVDOWN, self.dev_id)
            except OSError:
                pass
            try:
                self._sock.close()
            except OSError:
                pass
        self._sock = None
        self.scanning = False

    def _cmd(self, ocf, params, wait=True):
        """Send an LE command; returns the Command Complete status byte."""
        opcode = (OGF_LE << 10) | ocf
        self._sock.send(struct.pack("<BHB", HCI_COMMAND_PKT, opcode, len(params)) + params)
        if not wait:
            return 0
        deadline = time.monotonic() + CMD_TIMEOUT_S
        while time.monotonic() < deadline:
            try:
                pkt = self._sock.recv(1024)
            except socket.timeout:
                continue
            if len(pkt) < 3 or pkt[0] != HCI_EVENT_PKT:
                continue
            if pkt[1] == EVT_CMD_COMPLETE and len(pkt) >= 7:
                if struct.unpack_from("<H", pkt, 4)[0] == opcode:
                    return pkt[6]
            elif pkt[1] == EVT_CMD_STATUS and len(pkt) >= 7:
                if struct.unpack_from("<H", pkt, 5)[0] == opcode and pkt[3] != 0:
                    return pkt[3]
            else:
                self._dispatch(pkt)  # adverts arriving meanwhile still count
        raise HciError(f"timeout waiting for LE command 0x{ocf:04x}")

    def _send_scan_enable(self, on, wait=True):
        return self._cmd(OCF_LE_SET_SCAN_ENABLE, bytes([1 if on else 0, 0]), wait=wait)

    def _arm(self):
        # Disable first: changing parameters while scanning is "command disallowed".
        self._send_scan_enable(False)  # 0x0C when not scanning - fine
        st = self._cmd(OCF_LE_SET_SCAN_PARAMETERS,
                       struct.pack("<BHHBB", 0x00, SCAN_INTERVAL, SCAN_WINDOW, 0x00, 0x00))
        if st != 0:
            raise HciError(f"set scan parameters failed (status 0x{st:02x})")
        # filter_dup = 0: report every copy of every advert.
        st = self._send_scan_enable(True)
        if st != 0:
            raise HciError(f"scan enable failed (status 0x{st:02x})")
        self.scanning = True

    # -- loop --

    def _dispatch(self, pkt):
        is_report = len(pkt) >= 4 and pkt[1] == EVT_LE_META and pkt[3] in (LE_ADV_REPORT, LE_EXT_ADV_REPORT)
        # Nearly every advert in an office (phones, laptops) carries no BTHome
        # UUID: one C-level byte search skips them without any Python parsing.
        if is_report and BTHOME_UUID_LE in pkt:
            for mac, rssi, payload in bthome_from_event(pkt):
                try:
                    self.on_advert(mac, rssi, payload)
                except Exception:
                    log.exception("advert handler failed")
        return is_report

    def _session(self):
        """Scan until nothing is wanted any more (returns) or an error (raises)."""
        self._open()
        self._arm()
        log.info("hci%d open, passive LE scan on", self.dev_id)
        self.last_error = None
        last_report = time.monotonic()
        rearms = 0
        while True:
            timeout = max(0.0, last_report + STALL_S - time.monotonic())
            ready, _, _ = select.select([self._sock, self._wake_r], [], [], timeout)
            if self._wake_r in ready:
                self._drain_wake()
                if not self.want_scan():
                    log.info("LE scan off (nothing to watch)")
                    return
            if self._sock in ready:
                if self._dispatch(self._sock.recv(1024)):
                    last_report = time.monotonic()
                    rearms = 0
            elif not ready:  # watchdog: silence for STALL_S
                rearms += 1
                if rearms > 3:
                    raise HciError("scan stalled after repeated re-arms")
                log.warning("no advertising reports for %ds - re-arming scan", STALL_S)
                self._arm()
                last_report = time.monotonic()

    def run(self):
        backoff = BACKOFF_MIN_S
        while True:
            self._drain_wake()
            if not self.want_scan():
                # Idle: no socket, controller down, no timer. Sleep until notify().
                select.select([self._wake_r], [], [])
                continue
            started = time.monotonic()
            failed = False
            try:
                self._session()
            except Exception as e:  # the scanner must never die
                failed = True
                msg = str(e) or e.__class__.__name__
                if msg != self.last_error:
                    log.warning("scanner: %s", msg)
                self.last_error = msg
            self._close()
            if not failed:
                backoff = BACKOFF_MIN_S
                continue
            # A session that ran a while was healthy: start the backoff over.
            if time.monotonic() - started > BACKOFF_MAX_S:
                backoff = BACKOFF_MIN_S
            time.sleep(backoff)
            backoff = min(backoff * 2, BACKOFF_MAX_S)

    def start(self):
        threading.Thread(target=self.run, name="ble-scanner", daemon=True).start()

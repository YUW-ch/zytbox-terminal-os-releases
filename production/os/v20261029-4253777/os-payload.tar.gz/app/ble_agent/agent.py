#!/usr/bin/env python3
"""
BLE presence agent for the Zytbox Terminal kiosk.

Employees carry a Shelly BLU Button Tough 1 in beacon mode (an advert every
~10 s). This root service listens passively on the Pi's Bluetooth controller
(raw HCI, see hci.py), decides on the terminal when a watched button ARRIVED or
LEFT (tracker.py), and queues those events for the SPA, which forwards them to
the backend like card taps. It never transmits, pairs or connects: bluetoothd
stays masked.

Like the Wi-Fi agent it listens ONLY on a Unix socket
(/run/timetracking-ble/agent.sock, root:ttkiosk 0660 — see
systemd/timetracking-ble.service); the kiosk file server proxies the SPA's
same-origin /ble/* requests to it. Nothing listens on TCP.

    GET  /status          -> adapter/scan state + every watched button
    PUT  /watch           {"enabled", "version", "absenceTimeoutS", "arriveRssi",
                           "buttons": [{"mac", "bindKey", "present"?, "lastSeenAt"?}]}
                          -> replace the watch list; present/lastSeenAt are the
                             backend's view, used to restore presence after a reboot
    GET  /events?after=N[&wait=S]
                          -> unacked ARRIVED/LEFT events with seq > N, ascending;
                             wait (<= 8 s) long-polls when there are none yet
    POST /ack             {"upTo": N} -> the backend has every event <= N; drop them.
                          Sent after EVERY successful backend sync (also with
                          nothing new): it's the "backend reachable" heartbeat
    POST /enroll          {"active"} -> enroll mode on/off (auto-off after 10 min)
    GET  /enroll          -> enroll state + recent button presses (candidates)
    POST /reset           -> forget watch list, presence and outbox (unpair)

The SPA acks events only once the backend accepted them. Errors are
{"error": "<code>"}.

State (watch list incl. bind keys, presence, outbox) lives in RAM
(/run/timetracking-ble-state/state.json, root 0600) — the backend is the durable
store. Only while the backend is unreachable is it also written to the microSD
(/var/lib/timetracking/ble/state.json, survives the read-only overlay); the next
ack deletes it again. See tracker.py.
"""

import logging
import os
import re
import threading
from datetime import datetime

from flask import Flask, jsonify, request

import crypto
import hci
from tracker import Tracker

# Disk fallback (offline only) and the live RAM copy (tmpfs; root-owned, survives
# agent restarts — kept outside the unit's RuntimeDirectory, which a stop wipes).
STATE_DIR = os.environ.get("TT_BLE_STATE_DIR", "/var/lib/timetracking/ble")
DISK_STATE_FILE = os.path.join(STATE_DIR, "state.json")
RAM_STATE_DIR = os.environ.get("TT_BLE_RAM_DIR", "/run/timetracking-ble-state")
RAM_STATE_FILE = os.path.join(RAM_STATE_DIR, "state.json")
# Touching this wakes the panel (the screen manager watches its mtime).
WAKE_FILE = "/run/timetracking/last_nfc_tap"
# Retry delay after a failed tick (normally the tracker says when it's next due).
TICK_RETRY_S = 5.0
# Longest GET /events?wait= (stays below the kiosk proxy's 10 s timeout).
MAX_EVENTS_WAIT_S = 8
MAX_BUTTONS = 1000

MAC_RE = re.compile(r"^[0-9A-F]{12}$")
KEY_RE = re.compile(r"^[0-9a-f]{32}$")

logging.basicConfig(level=logging.INFO, format="tt-ble: %(message)s")
log = logging.getLogger("tt-ble")


def error(code, status=400):
    return jsonify({"error": code}), status


def signal_screen_wake(_mac=None):
    try:
        os.makedirs(os.path.dirname(WAKE_FILE), exist_ok=True)
        with open(WAKE_FILE, "w"):
            pass
    except OSError as e:
        log.warning("could not signal screen wake: %s", e)


def norm_mac(v):
    if not isinstance(v, str):
        return None
    m = re.sub(r"[:\-\s.]", "", v).upper()
    return m if MAC_RE.match(m) else None


def norm_key(v):
    if v is None:
        return None, True
    if not isinstance(v, str):
        return None, False
    k = v.strip().lower()
    return (k, True) if KEY_RE.match(k) else (None, False)


def parse_iso(v):
    """ISO-8601 timestamp -> epoch seconds, or None."""
    if not isinstance(v, str):
        return None
    try:
        dt = datetime.fromisoformat(v.replace("Z", "+00:00"))
    except ValueError:
        return None
    return dt.timestamp() if dt.tzinfo else None


def is_int(v):
    return isinstance(v, int) and not isinstance(v, bool)


def create_app(tracker, scanner):
    app = Flask(__name__)

    @app.errorhandler(Exception)
    def internal_error(e):
        # Always answer JSON (the kiosk proxy forwards bodies as application/json).
        if hasattr(e, "code") and isinstance(e.code, int) and e.code < 500:
            return error("not_found" if e.code == 404 else "bad_request", e.code)
        log.exception("request failed")
        return error("internal", 500)

    @app.get("/status")
    def status():
        st = tracker.status()
        return jsonify({
            "adapter": bool(scanner.adapter) if scanner else False,
            "scanning": bool(scanner.scanning) if scanner else False,
            "enabled": st["enabled"],
            "encryptionSupported": crypto.SUPPORTED,
            "watchVersion": st["watchVersion"],
            "enroll": st["enroll"],
            "buttons": st["buttons"],
        })

    @app.put("/watch")
    def watch():
        body = request.get_json(silent=True)
        if not isinstance(body, dict):
            return error("invalid_request")
        enabled = body.get("enabled")
        version = body.get("version")
        timeout = body.get("absenceTimeoutS")
        rssi = body.get("arriveRssi")
        buttons = body.get("buttons")
        if not isinstance(enabled, bool) or not (version is None or isinstance(version, str)):
            return error("invalid_request")
        if not is_int(timeout) or not 30 <= timeout <= 86400:
            return error("invalid_timeout")
        if not is_int(rssi) or not -127 <= rssi <= 0:
            return error("invalid_rssi")
        if not isinstance(buttons, list) or len(buttons) > MAX_BUTTONS:
            return error("invalid_buttons")
        watched, seeds = {}, {}
        for item in buttons:
            if not isinstance(item, dict):
                return error("invalid_buttons")
            mac = norm_mac(item.get("mac"))
            key, ok = norm_key(item.get("bindKey"))
            if mac is None:
                return error("invalid_mac")
            if not ok:
                return error("invalid_bind_key")
            watched[mac] = key
            present = item.get("present")
            if present is not None and not isinstance(present, bool):
                return error("invalid_buttons")
            if present:
                seen = parse_iso(item.get("lastSeenAt"))
                if seen is not None:
                    seeds[mac] = seen
        v = tracker.set_watch(enabled, version, timeout, rssi, watched, seeds=seeds)
        return jsonify({"ok": True, "watchVersion": v})

    @app.get("/events")
    def events():
        try:
            after = int(request.args.get("after", "0"))
        except ValueError:
            return error("invalid_after")
        try:
            wait = int(request.args.get("wait", "0"))
        except ValueError:
            return error("invalid_wait")
        evs, last = tracker.events(max(0, after), wait=min(max(0, wait), MAX_EVENTS_WAIT_S))
        return jsonify({"events": evs, "lastSeq": last})

    @app.post("/ack")
    def ack():
        body = request.get_json(silent=True)
        up_to = body.get("upTo") if isinstance(body, dict) else None
        if not is_int(up_to) or up_to < 0:
            return error("invalid_request")
        tracker.ack(up_to)
        return jsonify({"ok": True})

    @app.post("/enroll")
    def enroll_set():
        body = request.get_json(silent=True)
        active = body.get("active") if isinstance(body, dict) else None
        if not isinstance(active, bool):
            return error("invalid_request")
        return jsonify({"active": tracker.set_enroll(active)})

    @app.get("/enroll")
    def enroll_get():
        active, candidates = tracker.enroll_state()
        return jsonify({"active": active, "candidates": candidates})

    @app.post("/reset")
    def reset():
        tracker.reset()
        log.info("reset: watch list, presence and outbox cleared")
        return jsonify({"ok": True})

    return app


# --- startup -------------------------------------------------------------------

def _ticker(tracker, wake):
    # Sleeps exactly until the next thing is due (a departure, a flush, enroll
    # auto-off) or until the tracker reports a change; with nothing watched and
    # nothing pending it sleeps indefinitely instead of waking every second.
    while True:
        wake.clear()
        try:
            delay = tracker.tick()
        except Exception:  # the ticker must never die
            log.exception("tick failed")
            delay = TICK_RETRY_S
        wake.wait(delay)


def _boot():
    for d in (STATE_DIR, RAM_STATE_DIR):
        try:
            os.makedirs(d, mode=0o700, exist_ok=True)
        except OSError as e:
            log.warning("state dir %s: %s", d, e)
    tracker = Tracker(RAM_STATE_FILE, disk_path=DISK_STATE_FILE, on_arrived=signal_screen_wake)
    scanner = hci.Scanner(tracker.on_advert, tracker.wants_scan)
    wake = threading.Event()

    def on_change():
        wake.set()
        scanner.notify()

    tracker.on_change = on_change
    scanner.start()
    threading.Thread(target=_ticker, args=(tracker, wake), name="ble-ticker", daemon=True).start()
    log.info("started (AES-CCM backend: %s)", crypto.BACKEND or "none")
    return create_app(tracker, scanner)


# The tests build their own app around a fake-clock tracker.
if os.environ.get("TT_BLE_AGENT_TEST") != "1":
    app = _boot()

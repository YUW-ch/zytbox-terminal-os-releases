"""
Presence state machine for watched BLE buttons, plus the event outbox and the
enroll-candidate list. No I/O except the state file; both clocks are injected so
the tests can drive time.

Per watched MAC:

    absent --(2+ sightings at >= arriveRssi, >= 3 s apart, within 60 s)--> present
           emits ARRIVED at the FIRST qualifying sighting's wall time
    present --(no accepted sighting for > absenceTimeoutS, monotonic)--> absent
           emits LEFT at the last sighting's wall time

While present, any accepted sighting (whatever its RSSI) keeps the button
present. Timeouts use the monotonic clock so a wall-clock jump (NTP, RTC) never
fakes a departure; event timestamps use the wall clock.

Accepting a sighting: a button with a bind key only counts adverts that decrypt
(MIC verified) AND carry a counter strictly greater than the last accepted one —
a replayed advert, or a plaintext one, is dropped. Without a key only plaintext
adverts count.

Beacon mode: a button in beacon mode advertises every ~10 s; in normal mode
every 15 min (plus on presses). The median gap between distinct adverts tells
them apart (< 60 s -> beaconMode true). A normal-mode button never meets the
arrival rule, so the app shows a warning instead.

Persistence — the backend is the store, the microSD only a fallback:
  * Live state (watch list incl. bind keys, presence + last sighting, outbox,
    next sequence number) is kept in RAM: state_path is on /run (tmpfs, root
    0600), written on every transition, outbox and watch change, the last
    sighting of present buttons at most every SEEN_FLUSH_S. It survives an agent
    restart (OTA, crash), not a reboot.
  * The SPA delivers events and last sightings to the backend and then calls
    ack(); that is the "the backend has it" signal. As long as it keeps coming
    (the SPA reports sightings every ~60 s), NOTHING is written to the microSD.
  * Only when the backend is unreachable — an event still unacked after
    OFFLINE_AFTER_S, or a present button and no ack at all for that long — the
    state is also written to disk_path: at once, on every transition/outbox
    change, and the last sightings at most every OFFLINE_FLUSH_S. It is deleted
    again once an ack leaves the outbox empty.
  * After a reboot: a disk file means state the backend never got, so it is
    loaded. Otherwise presence is seeded from the backend via the watch list
    (set_watch(seeds=...)), so a button that left during the reboot still gets
    its LEFT. lastCounter isn't persisted while online: after a reboot the replay
    window re-opens until the button's next advert.

Energy: nothing here polls. tick() returns how long until the next thing is due
(a departure, enroll auto-off, a flush), and every change that could bring that
forward calls on_change, which wakes the ticker and the scanner. With nothing
watched, neither thread wakes at all.

Restart reconciliation: a button that was present when the agent stopped stays
present if its last sighting is within the absence timeout (it continues
seamlessly, or leaves when the remaining time runs out). If the downtime was
longer, LEFT is emitted at once, timestamped at the persisted last sighting; a
later sighting then arrives it again through the normal rule.
"""

import json
import logging
import os
import statistics
import threading
import time
import uuid
from collections import deque
from datetime import datetime, timezone

import bthome

log = logging.getLogger("tt-ble")

DEFAULT_ABSENCE_TIMEOUT_S = 300
# No ack for this long while there is something to protect -> backend unreachable
# (the SPA acks at least on every ~60 s sighting report).
OFFLINE_AFTER_S = 180
# While unreachable: how often changed last sightings go to the microSD.
OFFLINE_FLUSH_S = 900
DEFAULT_ARRIVE_RSSI = -85
# Arrival: two qualifying sightings at least this far apart, within the window.
ARRIVE_MIN_GAP_S = 3
ARRIVE_WINDOW_S = 60
# Median advert gap below this -> beacon mode.
BEACON_INTERVAL_S = 60
# Copies of one advert (filter_dup=0, 3 channels) arrive within milliseconds;
# gaps shorter than this aren't "intervals" for the beacon-mode inference.
MIN_INTERVAL_S = 1.0
# Gaps longer than this are absences (overnight), not the advertising interval.
MAX_INTERVAL_S = 3600
INTERVAL_SAMPLES = 10
# Enroll: auto-off, press threshold, candidate lifetime, and how long the copies
# of one press keep competing for "strongest".
ENROLL_TTL_S = 600
ENROLL_RSSI = -70
CANDIDATE_TTL_S = 30
PRESS_WINDOW_S = 2
# Persistence cadence (see module docstring).
COUNTER_PERSIST_S = 600
SEEN_FLUSH_S = 60
# Hard cap so an SPA that never acks can't grow the file forever (~2 MB).
OUTBOX_MAX = 10000
STATE_VERSION = 1


def iso(ts):
    """Epoch seconds -> ISO 8601 UTC with milliseconds ("2026-10-27T08:00:00.000Z")."""
    if ts is None:
        return None
    return datetime.fromtimestamp(ts, timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


class _Button:
    def __init__(self, mac, key_hex):
        self.mac = mac
        self.key_hex = key_hex
        self.key = bytes.fromhex(key_hex) if key_hex else None
        self.mac_be = bytes.fromhex(mac)
        self.present = False
        self.last_wall = None
        self.last_mono = None
        self.rssi = None
        self.battery = None
        self.decrypt_ok = None
        self.counter = None        # last accepted counter (live)
        self.saved_counter = None  # what goes into the state file
        self.intervals = deque(maxlen=INTERVAL_SAMPLES)
        self.iv_mono = None        # start of the last distinct advert
        self.window = []           # qualifying sightings while absent: (wall, mono)

    def beacon_mode(self):
        if len(self.intervals) < 2:
            return None
        return statistics.median(self.intervals) < BEACON_INTERVAL_S

    def to_state(self):
        return {
            "bindKey": self.key_hex,
            "present": self.present,
            "lastSeenAt": self.last_wall,
            "rssi": self.rssi,
            "battery": self.battery,
            "decryptOk": self.decrypt_ok,
            "lastCounter": self.saved_counter,
            "intervals": [round(x, 1) for x in self.intervals],
        }


class Tracker:
    def __init__(self, state_path, wall=time.time, mono=time.monotonic, on_arrived=None, on_change=None,
                 disk_path=None):
        self.state_path = state_path  # RAM (/run)
        self.disk_path = disk_path    # microSD fallback, only while the backend is unreachable
        self.wall = wall
        self.mono = mono
        self.on_arrived = on_arrived
        # Called (under the lock, must be cheap) when the watch list, enroll mode
        # or the next tick deadline changed: wakes the ticker and the scanner.
        self.on_change = on_change
        self._lock = threading.RLock()
        self._new_event = threading.Condition(self._lock)
        self.enabled = False
        self.watch_version = None
        self.absence_timeout_s = DEFAULT_ABSENCE_TIMEOUT_S
        self.arrive_rssi = DEFAULT_ARRIVE_RSSI
        self.buttons = {}
        self.outbox = []
        self.next_seq = 1
        self._enroll_until = None
        self._candidates = []  # {mac, rssi, battery, at, mono}
        self._dirty = False
        self._last_save = self.mono()
        self._last_ckpt = self.mono()
        self._last_sync = self.mono()  # boot counts as synced: give the SPA time to start
        self._emitted = {}             # seq -> mono when it entered the outbox
        self._on_disk = False          # disk_path holds state the backend may not have
        self._disk_retry = False       # the last disk write failed
        self._disk_stale = False       # newer last sightings than on disk
        self._last_disk = self.mono()
        with self._lock:
            self._load()

    def _changed(self):
        if self.on_change:
            try:
                self.on_change()
            except Exception:
                log.exception("on_change failed")

    # --- persistence ----------------------------------------------------------

    def _read(self, path):
        try:
            with open(path, encoding="utf-8") as f:
                return json.load(f)
        except FileNotFoundError:
            return None
        except (OSError, ValueError) as e:
            log.warning("state file %s unreadable (%s) - ignoring it", path, e)
            return None

    def _load(self):
        # RAM first (same boot, newest). Otherwise a disk file is state from an
        # offline spell the backend never got. Otherwise start empty: the SPA's
        # watch list brings the buttons and the backend's view of their presence.
        data = self._read(self.state_path)
        if data is None and self.disk_path:
            data = self._read(self.disk_path)
            if data is not None:
                log.info("restoring unsynced state from %s", self.disk_path)
        if self.disk_path and os.path.exists(self.disk_path):
            self._on_disk = True
        if data is None:
            return
        watch = data.get("watch") or {}
        self.enabled = bool(watch.get("enabled"))
        self.watch_version = watch.get("version")
        self.absence_timeout_s = watch.get("absenceTimeoutS") or DEFAULT_ABSENCE_TIMEOUT_S
        self.arrive_rssi = watch.get("arriveRssi", DEFAULT_ARRIVE_RSSI)
        self.outbox = list(data.get("outbox") or [])
        self.next_seq = max(int(data.get("nextSeq") or 1),
                            max((e["seq"] for e in self.outbox), default=0) + 1)
        now_w, now_m = self.wall(), self.mono()
        reconciled = False
        for mac, st in (data.get("buttons") or {}).items():
            b = _Button(mac, st.get("bindKey"))
            b.last_wall = st.get("lastSeenAt")
            b.rssi = st.get("rssi")
            b.battery = st.get("battery")
            b.decrypt_ok = st.get("decryptOk")
            b.counter = b.saved_counter = st.get("lastCounter")
            b.intervals.extend(st.get("intervals") or [])
            if st.get("present") and b.last_wall is not None:
                elapsed = max(0.0, now_w - b.last_wall)  # clamp a clock that went back
                if elapsed > self.absence_timeout_s:
                    b.present = True
                    self._leave(b, save=False)
                    reconciled = True
                else:
                    b.present = True
                    b.last_mono = now_m - elapsed
            self.buttons[mac] = b
        if reconciled:
            self._save()

    def _snapshot(self):
        return {
            "v": STATE_VERSION,
            "watch": {
                "enabled": self.enabled,
                "version": self.watch_version,
                "absenceTimeoutS": self.absence_timeout_s,
                "arriveRssi": self.arrive_rssi,
            },
            "buttons": {mac: b.to_state() for mac, b in self.buttons.items()},
            "outbox": self.outbox,
            "nextSeq": self.next_seq,
        }

    @staticmethod
    def _write(path, payload, durable):
        tmp = f"{path}.tmp"
        os.makedirs(os.path.dirname(path) or ".", mode=0o700, exist_ok=True)
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        try:
            os.fchmod(fd, 0o600)
            os.write(fd, payload)
            if durable:
                os.fsync(fd)
        finally:
            os.close(fd)
        os.replace(tmp, path)
        if durable:
            dfd = os.open(os.path.dirname(path) or ".", os.O_RDONLY)
            try:
                os.fsync(dfd)  # make the rename itself durable
            finally:
                os.close(dfd)

    def _save(self, routine=False):
        """RAM copy always (tmpfs: free); the microSD only while offline, and then
        only for real changes — a routine last-sighting flush (routine=True)
        reaches the disk via the slower OFFLINE_FLUSH_S cadence in tick()."""
        payload = json.dumps(self._snapshot(), separators=(",", ":")).encode("utf-8")
        try:
            self._write(self.state_path, payload, durable=False)
            self._dirty = False
            self._last_save = self.mono()
        except OSError as e:
            self._dirty = True  # retried by the next tick
            log.warning("saving state failed: %s", e)
        if not routine and (self._on_disk or self._offline()):
            self._save_disk(payload)

    def _oldest_unacked(self):
        if not self.outbox:
            return None
        return self._emitted.get(self.outbox[0]["seq"], self._last_sync)

    def _offline(self):
        """Backend unreachable AND something it doesn't have yet."""
        if not self.disk_path:
            return False
        now = self.mono()
        oldest = self._oldest_unacked()
        if oldest is not None and now - oldest >= OFFLINE_AFTER_S:
            return True  # heartbeats may still come, but these never got through
        if now - self._last_sync < OFFLINE_AFTER_S:
            return False
        return any(b.present for b in self.buttons.values())

    def _save_disk(self, payload=None):
        if payload is None:
            payload = json.dumps(self._snapshot(), separators=(",", ":")).encode("utf-8")
        try:
            self._write(self.disk_path, payload, durable=True)
            if not self._on_disk:
                log.info("backend unreachable - keeping state on %s until it's back", self.disk_path)
            self._on_disk = True
            self._disk_retry = self._disk_stale = False
            self._last_disk = self.mono()
        except OSError as e:
            self._disk_retry = True
            log.warning("saving state to disk failed: %s", e)

    def _drop_disk(self):
        if not self._on_disk:
            return
        try:
            os.remove(self.disk_path)
        except FileNotFoundError:
            pass
        except OSError as e:
            log.warning("removing %s failed: %s", self.disk_path, e)
            return
        self._on_disk = False
        log.info("backend reachable again - removed %s", self.disk_path)

    # --- watch list -------------------------------------------------------------

    def set_watch(self, enabled, version, absence_timeout_s, arrive_rssi, buttons, seeds=None):
        """buttons: {MAC: bindKey hex or None}. Disabled -> nothing is watched.

        seeds: {MAC: lastSeenAt epoch} for buttons the BACKEND has as present
        (clocked in by this terminal's ARRIVED). Applied only to a button this
        agent knows nothing about yet (after a reboot): it starts present at that
        sighting, so the normal timeout either keeps it present or emits its LEFT
        at that time. Never overrides what the agent saw itself."""
        seeds = seeds or {}
        with self._lock:
            unchanged = (self.enabled == bool(enabled) and self.watch_version == version
                         and self.absence_timeout_s == absence_timeout_s
                         and self.arrive_rssi == arrive_rssi
                         and {m: b.key_hex for m, b in self.buttons.items()} == (buttons if enabled else {})
                         and not any(m in self.buttons and self.buttons[m].last_wall is None for m in seeds))
            if unchanged:
                return self.watch_version  # the SPA re-pushes the same list: nothing to do
            self.enabled = bool(enabled)
            self.watch_version = version
            self.absence_timeout_s = absence_timeout_s
            self.arrive_rssi = arrive_rssi
            wanted = buttons if self.enabled else {}
            kept = {}
            for mac, key_hex in wanted.items():
                b = self.buttons.get(mac)
                if b is None or b.key_hex != key_hex:
                    nb = _Button(mac, key_hex)
                    if b is not None:  # key changed: keep presence, restart crypto state
                        nb.present, nb.last_wall, nb.last_mono = b.present, b.last_wall, b.last_mono
                        nb.rssi, nb.battery, nb.intervals = b.rssi, b.battery, b.intervals
                    b = nb
                seen = seeds.get(mac)
                if seen is not None and b.last_wall is None and not b.present:
                    b.present = True
                    b.last_wall = seen
                    b.last_mono = self.mono() - max(0.0, self.wall() - seen)
                kept[mac] = b
            # A button that's no longer watched is dropped silently: the backend
            # wouldn't accept events for an unassigned/deactivated credential.
            self.buttons = kept
            self._save()
            self._changed()
            return self.watch_version

    def wants_scan(self):
        with self._lock:
            return bool(self.buttons) or self._enroll_until is not None

    # --- sightings --------------------------------------------------------------

    def on_advert(self, mac, rssi, service_data):
        now_w, now_m = self.wall(), self.mono()
        with self._lock:
            b = self.buttons.get(mac)
            if b is None and self._enroll_until is None:
                return  # someone else's BTHome device: don't even decode it
            if b is not None and b.key is not None and b.counter is not None:
                ctr = bthome.encrypted_counter(service_data)
                if ctr is not None and ctr <= b.counter:
                    return  # another copy of an accepted advert: skip the AES
            try:
                mac_be = b.mac_be if b else bytes.fromhex(mac)
            except ValueError:
                return
            adv = bthome.decode(mac_be, service_data, b.key if b else None)
            if adv is None:
                return
            if self._enroll_until is not None:
                self._enroll_candidate(mac, rssi, adv, now_w, now_m)
            if b is None:
                return
            if b.key is not None:
                if not adv.encrypted or not adv.ok:
                    b.decrypt_ok = False  # plaintext or wrong key: never trusted
                    return
                if b.counter is not None and adv.counter <= b.counter:
                    return  # replay, or another copy of the same advert
                if b.counter == b.saved_counter:
                    self._changed()  # a counter checkpoint is now due
                b.counter = adv.counter
                b.decrypt_ok = True
            else:
                if adv.encrypted:
                    b.decrypt_ok = False  # encrypted, but the app has no key for it
                    return
                b.decrypt_ok = None
            self._sighting(b, rssi, adv.battery, now_w, now_m)

    def _sighting(self, b, rssi, battery, now_w, now_m):
        if b.iv_mono is None or now_m - b.iv_mono >= MIN_INTERVAL_S:
            if b.iv_mono is not None and now_m - b.iv_mono <= MAX_INTERVAL_S:
                b.intervals.append(now_m - b.iv_mono)
            b.iv_mono = now_m
        b.last_wall, b.last_mono, b.rssi = now_w, now_m, rssi
        if battery is not None:
            b.battery = battery
        if b.present:
            self._disk_stale = True
            if not self._dirty:
                self._dirty = True
                self._changed()  # a last-sighting flush is now due
            return
        if rssi < self.arrive_rssi:
            return
        b.window = [s for s in b.window if now_m - s[1] <= ARRIVE_WINDOW_S]
        b.window.append((now_w, now_m))
        first = b.window[0]
        if now_m - first[1] >= ARRIVE_MIN_GAP_S:
            self._arrive(b, first[0])

    def _emit(self, b, kind, at):
        ev = {
            "id": str(uuid.uuid4()),
            "seq": self.next_seq,
            "mac": b.mac,
            "kind": kind,
            "at": iso(at),
            "rssi": b.rssi,
            "battery": b.battery,
        }
        self.next_seq += 1
        self.outbox.append(ev)
        self._emitted[ev["seq"]] = self.mono()
        if len(self.outbox) > OUTBOX_MAX:
            log.warning("outbox full - dropping the oldest unacked event")
            for e in self.outbox[: len(self.outbox) - OUTBOX_MAX]:
                self._emitted.pop(e["seq"], None)
            del self.outbox[: len(self.outbox) - OUTBOX_MAX]
        self._new_event.notify_all()  # answers a waiting GET /events at once
        log.info("%s %s at %s", b.mac, kind, ev["at"])
        return ev

    def _arrive(self, b, at):
        b.present = True
        b.window = []
        b.saved_counter = b.counter
        self._emit(b, "ARRIVED", at)
        self._save()
        self._changed()  # its departure deadline is new
        if self.on_arrived:
            try:
                self.on_arrived(b.mac)
            except Exception:
                log.exception("on_arrived failed")

    def _leave(self, b, save=True):
        b.present = False
        b.window = []
        b.last_mono = None
        b.saved_counter = b.counter
        self._emit(b, "LEFT", b.last_wall)
        if save:
            self._save()

    def tick(self):
        """Departures, enroll auto-off, periodic flushes. Returns the seconds until
        it needs to run again, or None when nothing is scheduled (the caller then
        sleeps until on_change)."""
        now_m = self.mono()
        with self._lock:
            for b in list(self.buttons.values()):
                if b.present and b.last_mono is not None and now_m - b.last_mono > self.absence_timeout_s:
                    self._leave(b)
            if self._enroll_until is not None and now_m >= self._enroll_until:
                log.info("enroll mode timed out")
                self._enroll_until = None
                self._candidates = []
                self._changed()  # the scanner may now stop
            if now_m - self._last_ckpt >= COUNTER_PERSIST_S:
                self._last_ckpt = now_m
                for b in self.buttons.values():
                    if b.saved_counter != b.counter:
                        b.saved_counter = b.counter
                        self._dirty = True
            if self._dirty and now_m - self._last_save >= SEEN_FLUSH_S:
                self._save(routine=True)
            if self._offline() and (not self._on_disk or self._disk_retry or (
                    self._disk_stale and now_m - self._last_disk >= OFFLINE_FLUSH_S)):
                self._save_disk()
            return self._next_due(now_m)

    def _next_due(self, now_m):
        due = []
        for b in self.buttons.values():
            if b.present and b.last_mono is not None:
                # tick() leaves on "> timeout", so aim just past the boundary.
                due.append(b.last_mono + self.absence_timeout_s + 0.01)
            if b.saved_counter != b.counter:
                due.append(self._last_ckpt + COUNTER_PERSIST_S)
        if self._enroll_until is not None:
            due.append(self._enroll_until)
        if self._dirty:
            due.append(self._last_save + SEEN_FLUSH_S)
        if self.disk_path and not self._offline():
            oldest = self._oldest_unacked()
            if oldest is not None:
                due.append(oldest + OFFLINE_AFTER_S)  # event not delivered by then
            if any(b.present for b in self.buttons.values()):
                due.append(self._last_sync + OFFLINE_AFTER_S)  # heartbeat missing by then
        elif self.disk_path:
            if not self._on_disk or self._disk_retry:
                due.append(now_m)
            elif self._disk_stale:
                due.append(self._last_disk + OFFLINE_FLUSH_S)  # periodic offline flush
        return max(0.05, min(due) - now_m) if due else None

    # --- outbox ------------------------------------------------------------------

    def events(self, after=0, limit=500, wait=0):
        """Unacked events with seq > after. With wait > 0 and none pending, block up
        to `wait` seconds for the next one (long poll), so the SPA can ask rarely
        and still hear about an arrival at once."""
        deadline = time.monotonic() + wait
        with self._lock:
            while True:
                evs = [dict(e) for e in self.outbox if e["seq"] > after][:limit]
                remaining = deadline - time.monotonic()
                if evs or remaining <= 0:
                    break
                self._new_event.wait(remaining)
            last = evs[-1]["seq"] if evs else self.next_seq - 1
            return evs, last

    def ack(self, up_to):
        """The SPA reached the backend and it holds every event <= up_to (and the
        current last sightings). Called after each successful sync, also with
        nothing new (upTo 0), so it doubles as the "backend reachable" heartbeat."""
        with self._lock:
            self._last_sync = self.mono()
            before = len(self.outbox)
            self.outbox = [e for e in self.outbox if e["seq"] > up_to]
            self._emitted = {s: m for s, m in self._emitted.items() if s > up_to}
            if len(self.outbox) != before:
                self._save()
            if not self.outbox:  # undelivered events keep their disk copy
                self._drop_disk()
            self._changed()  # the offline deadline moved

    # --- enroll ------------------------------------------------------------------

    def set_enroll(self, active):
        with self._lock:
            self._candidates = []
            self._enroll_until = self.mono() + ENROLL_TTL_S if active else None
            self._changed()
            return self._enroll_until is not None

    def _enroll_candidate(self, mac, rssi, adv, now_w, now_m):
        # Only plaintext presses: an encrypted button's event can't be read
        # without its key (the app takes those by typed MAC).
        if adv.encrypted or not adv.ok or not adv.button or rssi < ENROLL_RSSI:
            return
        last = self._candidates[-1] if self._candidates else None
        if last is not None and now_m - last["mono"] <= PRESS_WINDOW_S:
            if rssi > last["rssi"]:
                last.update(mac=mac, rssi=rssi, battery=adv.battery, at=now_w)
            return
        self._candidates.append({"mac": mac, "rssi": rssi, "battery": adv.battery, "at": now_w, "mono": now_m})
        self._candidates = [c for c in self._candidates if now_m - c["mono"] <= CANDIDATE_TTL_S]

    def enroll_state(self):
        now_m = self.mono()
        with self._lock:
            out, seen = [], set()
            for c in reversed(self._candidates):
                if now_m - c["mono"] > CANDIDATE_TTL_S or c["mac"] in seen:
                    continue
                seen.add(c["mac"])
                out.append({"mac": c["mac"], "rssi": c["rssi"], "battery": c["battery"], "at": iso(c["at"])})
            return self._enroll_until is not None, out

    # --- status / reset ------------------------------------------------------------

    def status(self):
        with self._lock:
            return {
                "enabled": self.enabled,
                "watchVersion": self.watch_version,
                "enroll": self._enroll_until is not None,
                "buttons": [
                    {
                        "mac": b.mac,
                        "present": b.present,
                        "lastSeenAt": iso(b.last_wall),
                        "rssi": b.rssi,
                        "battery": b.battery,
                        "beaconMode": b.beacon_mode(),
                        "decryptOk": b.decrypt_ok,
                    }
                    for b in self.buttons.values()
                ],
            }

    def reset(self):
        """Forget the watch list, presence state and outbox (unpair). The sequence
        number keeps counting so an SPA's cursor never skips a new event."""
        with self._lock:
            self.enabled = False
            self.watch_version = None
            self.absence_timeout_s = DEFAULT_ABSENCE_TIMEOUT_S
            self.arrive_rssi = DEFAULT_ARRIVE_RSSI
            self.buttons = {}
            self.outbox = []
            self._emitted = {}
            self._enroll_until = None
            self._candidates = []
            self._save()
            self._drop_disk()
            self._changed()

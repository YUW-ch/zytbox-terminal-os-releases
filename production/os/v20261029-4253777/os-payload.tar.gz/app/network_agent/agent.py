#!/usr/bin/env python3
"""
Wi-Fi configuration agent for the Zytbox Terminal kiosk.

The SPA runs unprivileged in Chromium and cannot touch the OS, so this small
root service does the NetworkManager work on its behalf. It listens ONLY on a
Unix socket (/run/timetracking-net/agent.sock, root:ttkiosk 0660 — see
systemd/timetracking-network.service); the kiosk file server (ttkiosk) proxies
the SPA's same-origin /net/* requests to it. Nothing listens on TCP.

    GET    /status  -> ethernet + Wi-Fi state, configured SSID, IP, signal
    GET    /scan    -> nearby networks (deduplicated by SSID, strongest first)
    POST   /wifi    {"ssid", "password", "hidden"} -> save + connect (rolls back on failure)
    DELETE /wifi    -> forget the saved network
    POST   /wifi/reconnect -> retry the saved network now (skips the backoff wait)

Posting a new network replaces the saved one (that's also how the password of
the saved network is changed).

Exactly one Wi-Fi network is managed, as the NetworkManager connection "tt-wifi".
Ethernet always stays preferred (Wi-Fi gets the higher route metric), so a wrong
Wi-Fi setting can never cut off a cabled terminal.

Persistence: with the read-only overlay on, /etc is RAM-backed, so the
connection keyfile is kept on the persistent mount (PERSIST_DIR) and restored
into NetworkManager on every start. The keyfile holds the Wi-Fi password, so it
is always root:root 0600 — never readable by the ttkiosk group the socket uses.

Reconnect: the saved network is kept alive two ways. NetworkManager itself
retries forever (autoconnect-retries=0 — its default gives up after 4 tries for
5 minutes, and a password failure blocks it until someone intervenes). On top,
a watchdog thread re-activates it whenever the link is down: first after a 10s
grace (NetworkManager usually wins), then backing off 20s, 40s, ... up to every
5 minutes, until it's back. The SPA shows the countdown and a "reconnect now".

Startup also re-enables the Wi-Fi radio (unmask wpa_supplicant, unblock rfkill,
set the regulatory domain). Images built before Wi-Fi support blocked all of
that, and an OTA payload can't change /etc — so the agent fixes it at runtime.
"""

import logging
import os
import re
import shutil
import subprocess
import threading
import time
import uuid

from flask import Flask, jsonify, request

CON_NAME = "tt-wifi"
COUNTRY = os.environ.get("WIFI_COUNTRY", "CH")
PERSIST_DIR = os.environ.get("TT_NET_PERSIST", "/var/lib/timetracking/network")
NM_DIR = "/etc/NetworkManager/system-connections"
KEYFILE = f"{CON_NAME}.nmconnection"
# Higher metric = less preferred. NetworkManager's Ethernet default is 100.
WIFI_ROUTE_METRIC = 600
CONNECT_TIMEOUT_S = 40
# Watchdog: how often it looks at the link, and the reconnect backoff bounds.
WATCH_INTERVAL_S = 5
RECONNECT_MIN_S = 10
RECONNECT_MAX_S = 300

logging.basicConfig(level=logging.INFO, format="tt-network: %(message)s")
log = logging.getLogger("tt-network")

app = Flask(__name__)
# One NetworkManager mutation at a time (waitress serves requests on threads).
_lock = threading.Lock()


# --- helpers -----------------------------------------------------------------

def run(args, timeout=15):
    """Run a command without a shell; returns (returncode, stdout, stderr)."""
    try:
        p = subprocess.run(args, capture_output=True, text=True, timeout=timeout)
        return p.returncode, p.stdout, p.stderr
    except (OSError, subprocess.TimeoutExpired) as e:
        return 1, "", str(e)


def nmcli(*args, timeout=15):
    return run(["nmcli", *args], timeout=timeout)


def split_terse(line):
    """Split one line of `nmcli -t` output. Values escape ':' and '\\' with '\\'."""
    fields, cur, i = [], [], 0
    while i < len(line):
        c = line[i]
        if c == "\\" and i + 1 < len(line):
            cur.append(line[i + 1])
            i += 2
            continue
        if c == ":":
            fields.append("".join(cur))
            cur = []
        else:
            cur.append(c)
        i += 1
    fields.append("".join(cur))
    return fields


def wifi_device():
    """Name of the first Wi-Fi interface NetworkManager knows (usually wlan0)."""
    rc, out, _ = nmcli("-t", "-f", "DEVICE,TYPE", "device", "status")
    if rc != 0:
        return None
    for line in out.splitlines():
        f = split_terse(line)
        if len(f) >= 2 and f[1] == "wifi":
            return f[0]
    return None


def device_ip(dev):
    rc, out, _ = nmcli("-t", "-g", "IP4.ADDRESS", "device", "show", dev)
    if rc != 0:
        return None
    first = out.strip().split(" | ")[0]
    return first.split("/")[0] or None


def map_state(state):
    if state.startswith("connected"):
        return "connected"
    if state.startswith("connecting"):
        return "connecting"
    if state in ("unavailable", "unmanaged"):
        return "unavailable"
    return "disconnected"


def configured_ssid():
    rc, out, _ = nmcli("-t", "-g", "802-11-wireless.ssid", "connection", "show", CON_NAME)
    return out.strip() if rc == 0 and out.strip() else None


def configured_details():
    """(hidden, secure) of the saved network, for editing it in the SPA."""
    rc, out, _ = nmcli(
        "-t", "-g", "802-11-wireless.hidden,802-11-wireless-security.key-mgmt",
        "connection", "show", CON_NAME,
    )
    lines = out.splitlines() if rc == 0 else []
    hidden = len(lines) > 0 and lines[0].strip() == "yes"
    secure = len(lines) > 1 and lines[1].strip() not in ("", "--")
    return hidden, secure


def wifi_link():
    """(device, state) of the Wi-Fi interface, state as in map_state(); (None, None) if none."""
    rc, out, _ = nmcli("-t", "-f", "DEVICE,TYPE,STATE", "device", "status")
    if rc != 0:
        return None, None
    for line in out.splitlines():
        f = split_terse(line)
        if len(f) >= 3 and f[1] == "wifi":
            return f[0], map_state(f[2])
    return None, None


def error(code, status=400):
    return jsonify({"error": code}), status


# --- keyfile (written by us so the password never appears on a command line) --

def _kf_escape(s):
    """GKeyFile string escaping. A PSK is printable ASCII, so only '\\' and spaces
    need it; every space becomes '\\s' so leading/trailing ones survive parsing."""
    return s.replace("\\", "\\\\").replace(" ", "\\s")


def build_keyfile(dev, ssid, password, hidden, key_mgmt):
    # SSID as a byte list ("104;111;109;101;") — NetworkManager's unambiguous form
    # for arbitrary bytes, so no SSID character needs escaping.
    ssid_bytes = "".join(f"{b};" for b in ssid.encode("utf-8"))
    lines = [
        "[connection]",
        f"id={CON_NAME}",
        f"uuid={uuid.uuid4()}",
        "type=wifi",
        f"interface-name={dev}",
        "autoconnect=true",
        "autoconnect-retries=0",
        "",
        "[wifi]",
        "mode=infrastructure",
        f"ssid={ssid_bytes}",
    ]
    if hidden:
        lines.append("hidden=true")
    if key_mgmt:
        lines += ["", "[wifi-security]", f"key-mgmt={key_mgmt}", f"psk={_kf_escape(password)}"]
    lines += [
        "",
        "[ipv4]",
        "method=auto",
        f"route-metric={WIFI_ROUTE_METRIC}",
        "",
        "[ipv6]",
        "method=auto",
        "addr-gen-mode=default",
        f"route-metric={WIFI_ROUTE_METRIC}",
        "",
    ]
    return "\n".join(lines)


def write_private(path, content):
    """Atomically write a root:root 0600 file (NetworkManager rejects anything looser)."""
    tmp = f"{path}.tmp"
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    try:
        os.fchown(fd, 0, 0)
        os.fchmod(fd, 0o600)
        os.write(fd, content.encode("utf-8"))
        os.fsync(fd)
    finally:
        os.close(fd)
    os.replace(tmp, path)


def ensure_persist_dir():
    os.makedirs(PERSIST_DIR, mode=0o700, exist_ok=True)
    os.chown(PERSIST_DIR, 0, 0)
    os.chmod(PERSIST_DIR, 0o700)


def read_file(path):
    try:
        with open(path, encoding="utf-8") as f:
            return f.read()
    except OSError:
        return None


def install_keyfile(content):
    """Put the keyfile where NetworkManager reads it and (re)load it."""
    path = os.path.join(NM_DIR, KEYFILE)
    os.makedirs(NM_DIR, exist_ok=True)
    write_private(path, content)
    rc, _, err = nmcli("connection", "load", path)
    if rc != 0:
        log.warning("nmcli connection load failed: %s", err.strip())
    return rc == 0


def remove_connection():
    nmcli("connection", "delete", CON_NAME)
    try:
        os.remove(os.path.join(NM_DIR, KEYFILE))
    except FileNotFoundError:
        pass


# --- startup: radio on + restore the saved network ---------------------------

def ensure_radio():
    # Older images masked wpa_supplicant; NetworkManager can't drive Wi-Fi without it.
    rc, out, _ = run(["systemctl", "is-enabled", "wpa_supplicant.service"])
    if out.strip() == "masked":
        log.info("unmasking wpa_supplicant (image predates Wi-Fi support)")
        run(["systemctl", "unmask", "wpa_supplicant.service"])
        run(["systemctl", "start", "wpa_supplicant.service"])
        # NetworkManager gave up on the supplicant at boot; restart it once so it
        # picks it up. Ethernet reconnects within seconds.
        run(["systemctl", "restart", "NetworkManager.service"], timeout=60)
        time.sleep(3)
    if shutil.which("iw"):
        run(["iw", "reg", "set", COUNTRY])
    if shutil.which("rfkill"):
        run(["rfkill", "unblock", "wifi"])
    nmcli("radio", "wifi", "on")


def restore():
    saved = read_file(os.path.join(PERSIST_DIR, KEYFILE))
    live = read_file(os.path.join(NM_DIR, KEYFILE))
    if saved is None:
        if live is not None:
            log.info("no saved Wi-Fi network - removing stale %s", CON_NAME)
            remove_connection()
        return
    if saved != live:
        log.info("restoring saved Wi-Fi network")
        install_keyfile(saved)


def startup():
    try:
        ensure_persist_dir()
        ensure_radio()
        restore()
    except Exception:  # never keep the agent from serving status
        log.exception("startup failed")


startup()


# --- watchdog: keep the saved network connected ------------------------------

_reconnect = {"attempts": 0, "next_at": None}
_reconnect_lock = threading.Lock()  # guards _reconnect
_kick = threading.Event()  # set by /wifi/reconnect to skip the wait


def reset_reconnect():
    with _reconnect_lock:
        _reconnect["attempts"] = 0
        _reconnect["next_at"] = None


def reconnect_info():
    """Backoff state for the SPA: attempts so far and seconds to the next one."""
    with _reconnect_lock:
        nxt = _reconnect["next_at"]
        return {
            "attempts": _reconnect["attempts"],
            "nextInS": max(0, round(nxt - time.monotonic())) if nxt is not None else None,
        }


def watch_once(force=False):
    if not os.path.exists(os.path.join(PERSIST_DIR, KEYFILE)):
        reset_reconnect()  # nothing saved -> nothing to keep alive
        return
    dev, state = wifi_link()
    if dev is None:
        return
    if state == "connected":
        with _reconnect_lock:
            if _reconnect["attempts"]:
                log.info("Wi-Fi reconnected after %d attempt(s)", _reconnect["attempts"])
        reset_reconnect()
        return
    if state == "connecting":
        return
    now = time.monotonic()
    with _reconnect_lock:
        if _reconnect["next_at"] is None and not force:
            # Link just went down: give NetworkManager's own autoconnect a head start.
            _reconnect["next_at"] = now + RECONNECT_MIN_S
            log.info("Wi-Fi link down - reconnecting in %ds", RECONNECT_MIN_S)
            return
        if not force and now < _reconnect["next_at"]:
            return
    # A user-driven connect/forget holds the lock; never fight it.
    if not _lock.acquire(blocking=False):
        return
    try:
        with _reconnect_lock:
            _reconnect["attempts"] += 1
            attempt = _reconnect["attempts"]
            delay = min(RECONNECT_MIN_S * 2 ** attempt, RECONNECT_MAX_S)
            _reconnect["next_at"] = now + delay
        if state == "unavailable":
            # Radio switched off / soft-blocked since startup: switch it back on.
            if shutil.which("rfkill"):
                run(["rfkill", "unblock", "wifi"])
            nmcli("radio", "wifi", "on")
        log.info("Wi-Fi reconnect attempt %d (next in %ds if it fails)", attempt, delay)
        # Asynchronous: the next checks see "connecting" and then the outcome.
        nmcli("--wait", "0", "connection", "up", CON_NAME)
    finally:
        _lock.release()


def watchdog():
    while True:
        forced = _kick.wait(WATCH_INTERVAL_S)
        _kick.clear()
        try:
            watch_once(force=forced)
        except Exception:  # the watchdog must never die
            log.exception("watchdog check failed")


threading.Thread(target=watchdog, name="wifi-watchdog", daemon=True).start()


# --- routes ------------------------------------------------------------------

@app.errorhandler(Exception)
def internal_error(e):
    # Always answer JSON (the kiosk proxy forwards bodies as application/json).
    if hasattr(e, "code") and isinstance(e.code, int) and e.code < 500:
        return error("bad_request", e.code)
    log.exception("request failed")
    return error("internal", 500)


@app.get("/status")
def status():
    rc, out, _ = nmcli("-t", "-f", "DEVICE,TYPE,STATE,CONNECTION", "device", "status")
    if rc != 0:
        return error("nm_unavailable", 503)
    eth = {"connected": False, "ip": None}
    wifi = {
        "available": False,
        "enabled": False,
        "state": "unavailable",
        "ssid": None,
        "configuredSsid": None,
        "configuredHidden": False,
        "configuredSecure": False,
        "reconnect": None,
        "signal": None,
        "ip": None,
    }
    for line in out.splitlines():
        f = split_terse(line)
        if len(f) < 4:
            continue
        dev, typ, state, con = f[:4]
        if typ == "ethernet" and not eth["connected"]:
            if state.startswith("connected"):
                eth = {"connected": True, "ip": device_ip(dev)}
        elif typ == "wifi" and not wifi["available"]:
            wifi["available"] = True
            wifi["state"] = map_state(state)
            if wifi["state"] == "connected":
                wifi["ip"] = device_ip(dev)
                wifi["ssid"] = con if con != CON_NAME else configured_ssid()
    if wifi["available"]:
        _, radio, _ = nmcli("radio", "wifi")
        wifi["enabled"] = radio.strip() == "enabled"
        wifi["configuredSsid"] = configured_ssid()
        if wifi["configuredSsid"]:
            wifi["configuredHidden"], wifi["configuredSecure"] = configured_details()
            if wifi["state"] != "connected":
                wifi["reconnect"] = reconnect_info()
        if wifi["state"] == "connected":
            rc, out, _ = nmcli("-t", "-f", "IN-USE,SIGNAL", "device", "wifi", "list", "--rescan", "no")
            for line in out.splitlines():
                f = split_terse(line)
                if len(f) >= 2 and f[0] == "*" and f[1].isdigit():
                    wifi["signal"] = int(f[1])
                    break
    return jsonify({"ethernet": eth, "wifi": wifi, "country": COUNTRY})


@app.get("/scan")
def scan():
    if not wifi_device():
        return error("no_wifi_device", 503)
    rc, out, err = nmcli(
        "-t", "-f", "IN-USE,SSID,SIGNAL,SECURITY", "device", "wifi", "list", "--rescan", "yes",
        timeout=30,
    )
    if rc != 0:
        log.warning("scan failed: %s", err.strip())
        return error("scan_failed", 502)
    best = {}
    for line in out.splitlines():
        f = split_terse(line)
        if len(f) < 4 or not f[1]:
            continue  # hidden networks have no SSID in a scan
        in_use, ssid, signal, security = f[0] == "*", f[1], f[2], f[3]
        sig = int(signal) if signal.isdigit() else 0
        sec = security.strip()
        entry = {
            "ssid": ssid,
            "signal": sig,
            "secure": sec not in ("", "--"),
            # WPA-Personal / WPA3-SAE only — Enterprise (802.1X) and WEP aren't supported.
            "supported": "802.1X" not in sec and "WEP" not in sec,
            "inUse": in_use,
        }
        prev = best.get(ssid)
        if prev is None or sig > prev["signal"]:
            entry["inUse"] = in_use or (prev is not None and prev["inUse"])
            best[ssid] = entry
        elif in_use:
            prev["inUse"] = True
    networks = sorted(best.values(), key=lambda n: (not n["inUse"], -n["signal"]))
    return jsonify({"networks": networks})


PRINTABLE_ASCII = re.compile(r"^[\x20-\x7e]+$")
HEX64 = re.compile(r"^[0-9a-fA-F]{64}$")


def scanned_security(ssid):
    """Security string of `ssid` from the cached scan, or None if not seen."""
    rc, out, _ = nmcli("-t", "-f", "SSID,SECURITY", "device", "wifi", "list", "--rescan", "no")
    for line in out.splitlines():
        f = split_terse(line)
        if len(f) >= 2 and f[0] == ssid:
            return f[1].strip()
    return None


def classify_failure(err):
    e = err.lower()
    if "secrets were required" in e or "802-1x" in e or "password" in e:
        return "auth_failed"
    if "no network with ssid" in e or "not found" in e:
        return "not_found"
    if "timeout" in e or "timed out" in e:
        return "timeout"
    return "connect_failed"


@app.post("/wifi")
def connect():
    body = request.get_json(silent=True) or {}
    ssid = body.get("ssid")
    password = body.get("password") or ""
    hidden = bool(body.get("hidden"))
    if not isinstance(ssid, str) or not isinstance(password, str):
        return error("invalid_request")
    if not ssid or len(ssid.encode("utf-8")) > 32 or "\x00" in ssid:
        return error("invalid_ssid")

    security = None if hidden else scanned_security(ssid)
    if security and ("802.1X" in security or "WEP" in security):
        return error("unsupported_security")
    if security is not None and security in ("", "--"):
        key_mgmt = None  # open network
    elif security is None and not password:
        key_mgmt = None  # hidden network entered without a password -> open
    else:
        # WPA3-only networks need SAE; WPA2 and WPA2/WPA3 mixed accept WPA-PSK.
        key_mgmt = "sae" if security and "WPA3" in security and "WPA2" not in security else "wpa-psk"

    if key_mgmt:
        valid = (8 <= len(password) <= 63 and PRINTABLE_ASCII.match(password)) or (
            key_mgmt == "wpa-psk" and HEX64.match(password)
        )
        if not valid:
            return error("invalid_password")

    if not _lock.acquire(timeout=1):
        return error("busy", 409)
    try:
        dev = wifi_device()
        if not dev:
            return error("no_wifi_device", 503)
        ensure_persist_dir()
        saved_path = os.path.join(PERSIST_DIR, KEYFILE)
        previous = read_file(saved_path)

        content = build_keyfile(dev, ssid, password, hidden, key_mgmt)
        remove_connection()
        if not install_keyfile(content):
            if previous:
                install_keyfile(previous)
            return error("connect_failed", 500)

        rc, _, err = nmcli("--wait", str(CONNECT_TIMEOUT_S), "connection", "up", CON_NAME,
                           timeout=CONNECT_TIMEOUT_S + 10)
        if rc != 0:
            code = classify_failure(err)
            log.info("connecting to Wi-Fi failed (%s): %s", code, err.strip())
            # Put the previous working network back (or nothing).
            remove_connection()
            if previous:
                install_keyfile(previous)
                nmcli("--wait", "0", "connection", "up", CON_NAME)  # don't block the reply
            reset_reconnect()
            return error(code, 422)

        write_private(saved_path, content)
        reset_reconnect()
        log.info("Wi-Fi network saved and connected")
        return jsonify({"ok": True, "ip": device_ip(dev)})
    finally:
        _lock.release()


@app.delete("/wifi")
def forget():
    if not _lock.acquire(timeout=1):
        return error("busy", 409)
    try:
        remove_connection()
        try:
            os.remove(os.path.join(PERSIST_DIR, KEYFILE))
        except FileNotFoundError:
            pass
        reset_reconnect()
        log.info("Wi-Fi network forgotten")
        return jsonify({"ok": True})
    finally:
        _lock.release()


@app.post("/wifi/reconnect")
def reconnect_now():
    if not os.path.exists(os.path.join(PERSIST_DIR, KEYFILE)):
        return error("not_configured", 409)
    _kick.set()
    return jsonify({"ok": True}), 202

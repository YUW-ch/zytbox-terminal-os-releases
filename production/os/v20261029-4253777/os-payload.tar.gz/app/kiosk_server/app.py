#!/usr/bin/env python3
"""
Static file server for the Zytbox Terminal SPA.

The kiosk browser (Xorg + Chromium, see systemd/timetracking-browser.service)
loads http://localhost:8080. This server just serves the prebuilt Vite build
(the app's dist/) from the active release directory. Serving over localhost
gives the SPA a secure context, so its Screen Wake Lock and localStorage work.

The app talks to the backend directly and reads badges as keystrokes injected by
the NFC daemon, so this is a plain file server — with two exceptions: /net/* is
proxied to the root Wi-Fi agent (app/network_agent) and /ble/* to the BLE
presence agent (app/ble_agent), each over its Unix socket, so the SPA's calls
stay same-origin and the agents never listen on TCP.

WEB_ROOT points at the built SPA. Defaults to the release symlink used on the
device; override it (e.g. to a local dist/) when testing on a dev machine:

    WEB_ROOT=../../../zytbox-terminal/dist python3 app.py
"""

import http.client
import os
import socket
from pathlib import Path

from flask import Flask, Response, abort, jsonify, request, send_from_directory

WEB_ROOT = Path(os.environ.get("WEB_ROOT", "/opt/timetracking/current/web")).resolve()
NET_SOCKET = os.environ.get("NET_SOCKET", "/run/timetracking-net/agent.sock")
# Connecting to Wi-Fi can take the agent ~50s (activation timeout + rollback).
NET_TIMEOUT_S = 75
NET_MAX_BODY = 4096
NET_PATHS = ("status", "scan", "wifi", "wifi/reconnect")
BLE_SOCKET = os.environ.get("BLE_SOCKET", "/run/timetracking-ble/agent.sock")
# Every BLE agent call answers from memory (a state-file write at most).
BLE_TIMEOUT_S = 10
# PUT /ble/watch carries the whole button list (~80 bytes per button with key).
BLE_MAX_BODY = 256 * 1024
BLE_PATHS = ("status", "watch", "events", "ack", "enroll", "reset")

app = Flask(__name__)


class _UnixHTTPConnection(http.client.HTTPConnection):
    def __init__(self, path: str, timeout: float):
        super().__init__("localhost", timeout=timeout)
        self._path = path

    def connect(self):
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sock.settimeout(self.timeout)
        sock.connect(self._path)
        self.sock = sock


def _proxy(sock_path, sub, *, header, allowed, timeout, max_body):
    """Forward this request to a root agent's Unix socket (same method, body and
    query string) and relay its JSON answer.

    CSRF guard: only the SPA itself may drive the agents. The custom header makes
    any cross-origin request a CORS preflight, which we never approve, and
    Sec-Fetch-Site (sent by Chromium) must say the request came from this origin.
    """
    if request.headers.get(header) != "1":
        return jsonify({"error": "forbidden"}), 403
    site = request.headers.get("Sec-Fetch-Site")
    if site is not None and site != "same-origin":
        return jsonify({"error": "forbidden"}), 403
    if sub not in allowed:
        return jsonify({"error": "not_found"}), 404

    body = request.get_data(cache=False)
    if len(body) > max_body:
        return jsonify({"error": "too_large"}), 413
    path = f"/{sub}"
    qs = request.query_string.decode("latin-1")
    if qs:
        path += f"?{qs}"
    conn = _UnixHTTPConnection(sock_path, timeout)
    try:
        conn.request(
            request.method,
            path,
            body=body or None,
            headers={"Content-Type": "application/json"} if body else {},
        )
        resp = conn.getresponse()
        data = resp.read()
        return Response(data, status=resp.status, content_type="application/json")
    except (OSError, http.client.HTTPException):
        # Agent not installed (older OS) or not running: the SPA hides the feature.
        return jsonify({"error": "unavailable"}), 503
    finally:
        conn.close()


@app.route("/net/<path:sub>", methods=["GET", "POST", "DELETE"])
def net_proxy(sub: str):
    return _proxy(NET_SOCKET, sub, header="X-Zytbox-Net", allowed=NET_PATHS,
                  timeout=NET_TIMEOUT_S, max_body=NET_MAX_BODY)


@app.route("/ble/<path:sub>", methods=["GET", "POST", "PUT"])
def ble_proxy(sub: str):
    return _proxy(BLE_SOCKET, sub, header="X-Zytbox-Ble", allowed=BLE_PATHS,
                  timeout=BLE_TIMEOUT_S, max_body=BLE_MAX_BODY)


@app.route("/", defaults={"path": ""})
@app.route("/<path:path>")
def serve(path: str):
    # Serve the requested file if it exists, otherwise fall back to index.html.
    # The SPA has no client-side router, so the fallback is just a safety net.
    target = (WEB_ROOT / path).resolve()
    if path and target.is_file() and WEB_ROOT in target.parents:
        return send_from_directory(WEB_ROOT, path)
    index = WEB_ROOT / "index.html"
    if not index.is_file():
        abort(404, description=f"SPA build not found at {WEB_ROOT}")
    return send_from_directory(WEB_ROOT, "index.html")


if __name__ == "__main__":
    # Dev server only. In production systemd runs this via waitress-serve,
    # see systemd/timetracking-kiosk.service.
    app.run(host="127.0.0.1", port=8080)
